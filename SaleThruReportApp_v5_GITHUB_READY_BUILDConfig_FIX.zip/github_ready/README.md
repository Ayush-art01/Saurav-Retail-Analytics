# Saurav Retail Analytics (SaleThruReportApp v5)

Android retail reporting app with offline-first CSV/XLSX processing, persistent Catalogue/Product/Size masters, sale reports, and product-wise analytics.

## Build

- Open this folder in Android Studio.
- Use JDK 17 and Android SDK 35.
- Application ID: `com.saurav.salethrureport.v5`
- Current version: `versionCode = 1`, `versionName = "1.0"`
- Run **Build → Make Project** before creating a signed APK.

## GitHub distribution and app updates

See [README_GITHUB_UPDATES.md](README_GITHUB_UPDATES.md) for configuring GitHub Releases and publishing APK updates. The updater is intentionally inactive until the repository owner/name placeholders in `UpdateManager.kt` are replaced.

## Security

Never commit signing keystores, keystore passwords, tokens, or private credentials to the repository. Keep a secure backup of the signing keystore because future APK updates must use the same signing key.
