# Auto File Format Detection

The app now detects the actual selected file format from its file signature instead of trusting the filename extension.

- Real CSV -> streaming CSV reader
- Real XLSX -> streaming worksheet reader using Android XML + ZipInputStream
- XLSX content renamed with `.csv` -> still detected as XLSX automatically
- Details and SOH both use the same auto-detection path
- Existing report, catalogue, product mapping, size master, staff and SQB logic is unchanged

The XLSX reader scans the first worksheet for the real Details/SOH header, so report metadata rows before the header are supported.
