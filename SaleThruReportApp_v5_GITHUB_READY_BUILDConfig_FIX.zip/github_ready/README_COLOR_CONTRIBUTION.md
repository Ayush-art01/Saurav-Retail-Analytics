# Color Contribution

Adds a Color Contribution report below Size Contribution.

- Reads unique Color values from the Sales Detail CSV.
- Groups color names case-insensitively and trims repeated whitespace.
- Calculates sale and quantity totals per color.
- Sorts colors by sale descending, then quantity descending.
- Shows each color's Sale % of total colored sale and Qty % of total colored quantity.
- Uses a recycled ListView with fast scroll so long color lists do not build hundreds of views at once.
- Blank Color rows are excluded from the color report and shown as a small note.
