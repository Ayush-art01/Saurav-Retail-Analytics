# CORE / FASHION Contribution Report

This build adds a second report without removing the existing Sale Thru flow.

## Report
**CORE / FASHION Contribution** uses the selected Sales Detail CSV only.

For each Details row:
- Style key is resolved from `ArticleNumber` first, then `CategoryCode`, matching the current Go Colors export handling.
- The local Catalogue Master determines the Root: `CORE` or `FASHION`.
- `Amount` is accumulated as Sale Value.
- `Quantity` is accumulated as Sale Qty.

Contribution is calculated against Total Sale:
`Root Sale / Total Sale × 100`

If a style is not mapped in Catalogue Master, its sale is shown separately as **UNMAPPED** rather than silently assigning it to CORE or FASHION.

The existing Sale Thru button/report remains unchanged.
