# CORE / FASHION Contribution v2

Fixes the contribution double-counting issue.

UNMAPPED is now calculated only as the residual:
Total Sale - CORE Sale - FASHION Sale

NONE remains excluded from Qty, Amount and Contribution.
