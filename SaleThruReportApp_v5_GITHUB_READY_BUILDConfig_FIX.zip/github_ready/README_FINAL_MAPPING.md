# Final Master Mapping Update

This build keeps the existing package/application ID and adds product-level catalogue overrides.

## Mapping hierarchy
`ProductGroupCode -> ProductName -> Category -> Root`

- Normal codes use the saved code-level mapping.
- Codes with product-level overrides require an exact normalized ProductName match.
- ProductName normalization ignores case, leading/trailing spaces and repeated spaces.
- Unknown products under a multi-product code are left unresolved instead of being guessed.
- `NONE` remains an intentional exclusion from CORE/FASHION contribution.

## Known multi-category mapping
- `LPT8 -> Ladies Jogger Pant -> PANTS -> FASHION`
- `LPT8 -> Suede Bell Bottom -> WINTER -> FASHION`
- `LPT8 -> Suede Bell Bottom (WINTER) -> WINTER -> FASHION`

## Master editing
- Category: tap to edit; long press to delete with confirmation.
- ProductGroupCode: tap to edit; long press to delete code and its product mappings with confirmation.
- Product Mapping: separate manager under Catalogue; tap to edit, long press to delete with confirmation.
- Size Master: no delete option; uploaded sizes are retained and classified as Normal/Plus Size.

Deleting a master mapping changes future classification only; historical CSV data is not modified.
