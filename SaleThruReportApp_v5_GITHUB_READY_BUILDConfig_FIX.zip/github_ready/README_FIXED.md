# Sale Thru Report App – Fixed CSV + Report Version

## This version fixes
- Go Colors Details CSV metadata lines before the real header.
- Details `Size` extraction from the real CSV header.
- Uses `ArticleNumber` / `CategoryCode` as the style/article key. In the supplied exports these match; `ProductGroupCode` is a numeric division field and is not used as the catalogue key.
- SOH is joined using `ArticleNumber`, so stock-only articles are not dropped.
- Sale Thru report generation is implemented.
- Category totals include Sold Qty, Sale Value, SOH Qty, SOH Value, Plus Size Sold, Plus Size Sale, Plus Size SOH and Sale Thru %.
- Sale Thru formula: Sold Qty / (Sold Qty + SOH Qty) × 100.
- New sizes are detected from the actual Details CSV and default to Normal until confirmed in Size Master.
- Catalogue missing codes are shown as master issues.
- Size extraction runs off the main UI thread.
- Catalogue uses a recycled ListView to avoid the previous ANR caused by creating hundreds of Spinners/CardViews at once.

## Important
The supplied Details export contains report metadata before its CSV header. The app now scans until it finds the actual header instead of assuming line 1 is the header.
