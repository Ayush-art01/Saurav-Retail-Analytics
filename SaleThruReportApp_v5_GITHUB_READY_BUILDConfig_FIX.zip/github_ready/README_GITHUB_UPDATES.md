# GitHub Releases and in-app updates

This project includes an optional GitHub Releases updater. The app checks the latest **public** GitHub release after the dashboard opens. If the release version is newer, it shows an **Update available** dialog. Tapping **Update** downloads the APK and opens Android's package installer. Android still requires the user to approve the installation; the app cannot silently install APKs.

## 1. Configure the repository

Open `app/src/main/java/com/saurav/salethrureport/UpdateManager.kt` and replace:

```kotlin
private const val GITHUB_OWNER = "YOUR_GITHUB_USERNAME"
private const val GITHUB_REPO = "YOUR_REPOSITORY_NAME"
```

with the GitHub account/organization and public repository name. Do not use a private repository unless you implement authenticated access; this updater deliberately uses the public GitHub Releases API without a token.

## 2. Publish the first release

1. Create a GitHub repository and upload the project source (do not upload passwords, API keys, or signing keystore files).
2. In Android Studio, create a **signed APK** using **Build → Generate Signed Bundle / APK → APK**.
3. Create a GitHub Release with a tag such as `v1.1` and attach the APK asset, for example `SauravRetailAnalytics.apk`.
4. Put these exact metadata lines in the release description, with values matching the APK:

```text
versionCode: 2
versionName: 1.1

Changes:
- Describe the improvements in this release.
```

The updater reads `versionCode` and `versionName` from the release description and chooses the first `.apk` release asset. The remote `versionCode` must be greater than the app's installed versionCode.

## 3. Publish future updates

For each future update:

1. Increment `versionCode` in `app/build.gradle.kts` (must always increase).
2. Update `versionName` in `app/build.gradle.kts`.
3. Build a new signed APK with the **same signing key/keystore** used for the previously distributed APK.
4. Publish a new GitHub Release with matching `versionCode: N` and `versionName: X.Y` metadata and attach the new APK.

Users with an older version will see the update dialog the next time they open the app while online. They tap **Update**, then confirm Android's installer. If Android asks to allow installs from this app, enable it in system settings and reopen the app to tap Update again.

## Important limitations

- Repository must be public for the unauthenticated GitHub API request and APK download.
- APK updates require the same Android application ID (`com.saurav.salethrureport.v5`) and the same signing key as the installed app.
- Android displays its own install confirmation; apps cannot silently install themselves.
- The project ZIP can be prepared here, but the actual APK build/signing and GitHub release publishing must be done by you in Android Studio/GitHub.
