# Master Learning + MOH Update

## Product Master learning from SOH
- SOH upload scans unique ProductCode/ArticleNumber + ProductName combinations.
- Existing Product Master mappings are preserved.
- Only new product combinations are added as unmapped entries for the user to categorize.
- Re-uploading an old or overlapping SOH file does not erase previous mappings.
- Details Quick Mapping edits are also persisted back into Product Master so the same product is not repeatedly flagged as new.

## Current Details Mapping
- After a Details upload, only products present in that Details file are loaded into Quick Mapping.
- Their categories are initialized from the persistent Product Master.
- User edits in Quick Mapping are saved to Product Master and the current-file layer.

## MOH
- Uses both Details and SOH.
- Finds the first and last valid BillDate actually present in Details.
- Period is converted to a 30-day month-equivalent, with a minimum of one month.
- Average Monthly Sold Qty = Sold Qty / period-months.
- MOH = SOH Qty / Average Monthly Sold Qty.
- NON-MERCHANDISE / NONE products remain excluded because the same central product mapping is used by the report processing.

## App name
Saurav Retail Analytics

### Size Master source update
Size Master now reads unique sizes from the current **SOH / Stock Value** file instead of the Details sales file. This makes the master represent the actual size assortment physically available in the store. New SOH sizes appear as NEW/default Normal until confirmed. Master Update Required also checks SOH sizes.
