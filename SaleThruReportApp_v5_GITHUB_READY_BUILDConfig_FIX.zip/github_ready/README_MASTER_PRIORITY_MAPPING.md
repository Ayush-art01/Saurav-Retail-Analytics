# Master Priority + Current Sheet Mapping

- Product Master is the permanent product-name mapping source.
- Catalogue stores only code-level root: CORE / FASHION / NONE.
- When a Details file is selected, the app scans the actual sheet and creates a fresh current-sheet mapping containing only code + ProductName combinations present in that file.
- Each current-sheet mapping is initialized from Product Master by exact normalized Code + ProductName matching.
- If the product is new/unmapped, it remains without a category and is shown as NEW/UNMAPPED in Product Mapping.
- Editing Product Mapping changes only the current-sheet working layer; it does not overwrite Product Master.
- Reports use the current-sheet working mapping (with a fallback to Product Master if no current mapping exists).
- NON-MERCHANDISE is excluded from report calculations; Catalogue root NONE is also excluded from eligible CORE/FASHION reporting.
