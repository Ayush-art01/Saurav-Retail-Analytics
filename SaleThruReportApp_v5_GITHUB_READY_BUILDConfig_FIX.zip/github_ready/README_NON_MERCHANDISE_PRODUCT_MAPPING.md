# Product Mapping + NON-MERCHANDISE architecture

## Catalogue Master
Catalogue is now ROOT-only:
- CORE
- FASHION
- NONE

The old code-level Category value is no longer used to classify report rows.

## Product Mapping
Classification is based on:
`ProductGroupCode + normalized ProductName`

The Quick Mapping screen reads only products actually present in the selected Details file. Existing saved product mappings are shown with their category; new combinations are marked as NEW/unmapped and can be assigned immediately.

## NON-MERCHANDISE
If a product is mapped to `NON-MERCHANDISE`, its quantity and value are excluded from:
- Sale Thru
- CORE/FASHION Contribution
- Size Contribution
- Color Contribution
- Staff Report
- SQB Report

Catalogue ROOT `NONE` is also excluded from report totals.

## Important
A ProductGroupCode may have multiple ProductName values and those products may belong to different categories. Reports must resolve the exact ProductName mapping rather than assuming one category per code.
