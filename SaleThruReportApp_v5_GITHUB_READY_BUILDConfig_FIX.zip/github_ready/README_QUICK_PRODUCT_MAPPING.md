# Quick Product Mapping

The Product Mapping screen is a lightweight, recycled ListView view of the existing Catalogue/Product Mapping data.

## Quick edit
- Every visible mapping has a compact category dropdown.
- Product-level mappings update `product_mappings`.
- Normal code-only mappings update the existing Catalogue mapping.
- Root is kept consistent: CORE -> CORE, NON-MERCHANDISE -> NONE, other categories -> FASHION.
- Changes are saved immediately and the list is rebuilt so the item moves under its new category.
- Existing Catalogue, Category and Size Master screens remain unchanged.
- No heavy nested ScrollView/CardView list is used for this screen.
