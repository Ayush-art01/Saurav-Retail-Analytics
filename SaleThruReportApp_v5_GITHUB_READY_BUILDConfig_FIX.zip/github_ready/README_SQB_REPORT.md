# SQB Report

Single Quantity Bill (SQB) report added below Staff Report.

## Logic
- A bill is an SQB when the bill-level eligible quantity is exactly 1.
- Exchange bills are excluded completely using ExchangeBillNumber/ExchangeBillDate; SR-series exchange bills such as SR199 are covered.
- Carry Bag (`P-CB` / Carry bag - Paper) quantity is excluded from the bill quantity before deciding SQB.
- Store section shows total SQB, total eligible bills, and SQB percentage.
- Staff section shows each staff's SQB, their total eligible bills, SQB contribution to store SQB, and SQB percentage within their own bills.
- Staff IDs are detected dynamically from the Details report.
