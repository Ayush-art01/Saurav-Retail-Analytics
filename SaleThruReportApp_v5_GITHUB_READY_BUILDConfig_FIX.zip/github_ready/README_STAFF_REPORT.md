# Staff Report – Final Exchange Logic

## Staff display
- Main Staff Report shows only staff with positive final sale.
- Staff IDs whose own net sale is negative are treated as Other Store / Exchange Staff and hidden from the main table.
- A collapsible `OTHER STORE / EXCHANGE STAFF` section shows those negative staff and their exchange/negative amount.

## Exchange handling
1. Same-store exchange: exchange rows are excluded as fresh sale and their absolute amount is deducted from that same staff's regular sale.
2. Other-store exchange: when a negative-only staff is found, the app looks for a positive, non-exchange purchase with the same Customer ID on the same Bill Date.
3. The exchange amount is NOT required to equal the purchase amount. It is never used as a matching condition.
4. If the same-day customer purchase belongs to one unique staff, that staff receives the exchange deduction.
5. If several staff are candidates, bill time is used only as a tie-breaker; amount is never compared.
6. If no unique match can be established, the exchange is not silently assigned and the report shows an unresolved-match warning.

## Bill count
- Bills are counted from unique, positive, non-exchange BillNumbers.
- Multiple product rows inside one bill count as one bill.
- Exchange bills are excluded.
- Carry bags are excluded from quantity, but do not create extra bills.

## KPI
- ATV = Net Sale / Bills
- ASP = Net Sale / Qty
- UPT = Qty / Bills
