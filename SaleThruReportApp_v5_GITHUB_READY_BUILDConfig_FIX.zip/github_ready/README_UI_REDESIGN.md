# UI Redesign (look only - engine untouched)

- Theme forced to LIGHT (Material3.Light) - hardcoded dark text can no longer land on a dark background.
- New palette in res/values/colors.xml (navy header, corporate blue actions, WCAG-AA text colors).
- Home screen: navy header band, white outlined cards, grouped ANALYSIS REPORTS (2-column) and MASTERS sections, STATUS box.
- Disabled "Generate" button now clearly looks disabled (grey), enabled = navy.
- Report tables: navy header row, zebra rows, tinted TOTAL row.
- Popups: rounded white dialogs with blue action buttons.
- All view IDs unchanged. Only color values + makeTableRow() styling touched in MainActivity.kt.
