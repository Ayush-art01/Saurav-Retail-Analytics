
package com.saurav.salethrureport

import android.content.Context
import android.content.SharedPreferences
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.ContextThemeWrapper
import android.view.View
import android.util.Xml
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.*
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.io.InputStream
import java.util.zip.ZipInputStream
import org.xmlpull.v1.XmlPullParser
import java.util.Locale
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.time.format.DateTimeParseException
import java.time.format.DateTimeFormatterBuilder
import kotlin.math.roundToInt

private data class Mapping(val code: String, val category: String, val root: String)
private data class ProductMapping(val code: String, val productName: String, val category: String, val root: String)
private data class SizeEntry(val size: String, val type: String, val confirmed: Boolean)

data class SaleRow(val group: String, val size: String, val qty: Double, val value: Double)
data class SohRow(val group: String, val size: String, val qty: Double, val value: Double)

class MainActivity : AppCompatActivity() {
    private var detailUri: Uri? = null
    private var sohUri: Uri? = null
    private lateinit var detailStatus: TextView
    private lateinit var sohStatus: TextView
    private lateinit var generate: Button
    private lateinit var coreFashionButton: Button
    private lateinit var sizeContributionButton: Button
    private lateinit var colorContributionButton: Button
    private lateinit var staffReportButton: Button
    private lateinit var sqbReportButton: Button
    private lateinit var mohReportButton: Button
    private lateinit var bigBillReportButton: Button
    private lateinit var newProductSaleButton: Button
    private lateinit var productWiseSaleButton: Button
    private lateinit var result: TextView
    private lateinit var catalogueAlert: TextView
    private lateinit var prefs: SharedPreferences
    private lateinit var progressBar: ProgressBar
    private lateinit var processingStatus: TextView
    private var pendingCsvContent: String = ""

    private val exportCsvLauncher = registerForActivityResult(ActivityResultContracts.CreateDocument("text/csv")) { uri ->
        if (uri == null) return@registerForActivityResult
        try {
            contentResolver.openOutputStream(uri)?.bufferedWriter(Charsets.UTF_8)?.use { writer ->
                writer.write("\uFEFF")
                writer.write(pendingCsvContent)
            }
            Toast.makeText(this, "CSV exported successfully", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            Toast.makeText(this, "CSV export failed: ${e.message ?: "Unknown error"}", Toast.LENGTH_LONG).show()
        }
    }

    companion object {
        private const val PREF_DETAIL_URI = "last_detail_uri"
        private const val PREF_SOH_URI = "last_soh_uri"
        private const val PREF_CURRENT_PRODUCT_MAPPINGS = "current_product_mappings"
    }

    private val detailPicker = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        detailUri = uri
        if (uri != null) {
            persistSelectedUri(PREF_DETAIL_URI, uri)
            detailStatus.text = uri.lastPathSegment ?: "Selected"
            enableDetailReports(true)
            checkMasterIssues(uri)
        } else {
            enableDetailReports(true)
        }
        checkReady()
    }

    private val sohPicker = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        sohUri = uri
        if (uri != null) {
            persistSelectedUri(PREF_SOH_URI, uri)
            sohStatus.text = uri.lastPathSegment ?: "Selected"
            learnProductMasterFromSoh(uri)
            detailUri?.let { checkMasterIssues(it) } ?: checkSizeMasterIssuesFromSoh(uri)
        } else {
            sohStatus.text = "CSV file required"
        }
        checkReady()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        prefs = getSharedPreferences("catalogue", Context.MODE_PRIVATE)
        restoreSelectedFiles()
        seedDefaultCategoriesIfNeeded()
        seedDefaultCatalogueIfNeeded()
        ensureSpecialCatalogueMappings()
        migrateCatalogueAndProductMappings()
        seedDefaultSizesIfNeeded()

        detailStatus = findViewById(R.id.detailStatus)
        sohStatus = findViewById(R.id.sohStatus)
        generate = findViewById(R.id.generateButton)
        coreFashionButton = findViewById(R.id.coreFashionButton)
        sizeContributionButton = findViewById(R.id.sizeContributionButton)
        colorContributionButton = findViewById(R.id.colorContributionButton)
        staffReportButton = findViewById(R.id.staffReportButton)
        sqbReportButton = findViewById(R.id.sqbReportButton)
        mohReportButton = findViewById(R.id.mohReportButton)
        bigBillReportButton = findViewById(R.id.bigBillReportButton)
        newProductSaleButton = findViewById(R.id.newProductSaleButton)
        productWiseSaleButton = findViewById(R.id.productWiseSaleButton)
        result = findViewById(R.id.result)
        catalogueAlert = findViewById(R.id.catalogueAlert)
        progressBar = findViewById(R.id.progressBar)
        processingStatus = findViewById(R.id.processingStatus)
        // Keep report buttons tappable even when no file is currently selected.
        // The click handler shows a clear message instead of silently ignoring the tap.
        enableDetailReports(true)

        findViewById<Button>(R.id.detailButton).setOnClickListener {
            detailPicker.launch(arrayOf("text/csv", "text/comma-separated-values", "*/*"))
        }
        findViewById<Button>(R.id.sohButton).setOnClickListener {
            sohPicker.launch(arrayOf("text/csv", "text/comma-separated-values", "*/*"))
        }
        findViewById<Button>(R.id.catalogueButton).setOnClickListener { showCatalogueManager() }
        findViewById<Button>(R.id.categoryButton).setOnClickListener { showCategoryManager() }
        findViewById<Button>(R.id.sizeButton).setOnClickListener { showSizeManager() }
        findViewById<Button>(R.id.mappingPreviewButton).setOnClickListener { showMappingPreview() }
        findViewById<Button>(R.id.productMasterButton).setOnClickListener { showProductMaster() }
        catalogueAlert.setOnClickListener { showMissingMasterDialog() }
        generate.setOnClickListener { generateReport() }
        coreFashionButton.setOnClickListener { generateCoreFashionReport() }
        sizeContributionButton.setOnClickListener { generateSizeContributionReport() }
        colorContributionButton.setOnClickListener { generateColorContributionReport() }
        staffReportButton.setOnClickListener { generateStaffReport() }
        sqbReportButton.setOnClickListener { generateSqbReport() }
        mohReportButton.setOnClickListener { generateMohReport() }
        bigBillReportButton.setOnClickListener { showBigBillThresholdDialog() }
        newProductSaleButton.setOnClickListener { showNewProductSalePicker() }
        productWiseSaleButton.setOnClickListener { generateProductWiseSaleReport() }

        // Reflect persisted file selections immediately after reopening the app.
        detailStatus.text = detailUri?.lastPathSegment ?: "CSV file required"
        sohStatus.text = sohUri?.lastPathSegment ?: "CSV file required"
        enableDetailReports(true)
        checkReady()

        // Check GitHub Releases after the dashboard has initialized.
        lifecycleScope.launch {
            delay(1_200)
            UpdateManager.checkAndPrompt(this@MainActivity)
        }
    }

    private fun persistSelectedUri(key: String, uri: Uri) {
        try {
            contentResolver.takePersistableUriPermission(
                uri,
                android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION
            )
        } catch (_: Exception) {
            // Some providers do not expose persistable permissions; the URI may still work for this session.
        }
        prefs.edit().putString(key, uri.toString()).apply()
    }

    private fun restoreSelectedFiles() {
        detailUri = prefs.getString(PREF_DETAIL_URI, null)?.let { runCatching { Uri.parse(it) }.getOrNull() }
        sohUri = prefs.getString(PREF_SOH_URI, null)?.let { runCatching { Uri.parse(it) }.getOrNull() }

        // If a provider revoked access, clear only that stale URI.
        detailUri?.let { uri ->
            try {
                contentResolver.openAssetFileDescriptor(uri, "r")?.use { }
            } catch (_: Exception) {
                detailUri = null
                prefs.edit().remove(PREF_DETAIL_URI).apply()
            }
        }
        sohUri?.let { uri ->
            try {
                contentResolver.openAssetFileDescriptor(uri, "r")?.use { }
            } catch (_: Exception) {
                sohUri = null
                prefs.edit().remove(PREF_SOH_URI).apply()
            }
        }
    }

    private fun enableDetailReports(enabled: Boolean) {
        coreFashionButton.isEnabled = enabled
        sizeContributionButton.isEnabled = enabled
        colorContributionButton.isEnabled = enabled
        staffReportButton.isEnabled = enabled
        sqbReportButton.isEnabled = enabled
        mohReportButton.isEnabled = enabled
        bigBillReportButton.isEnabled = enabled
        newProductSaleButton.isEnabled = enabled
        productWiseSaleButton.isEnabled = enabled
    }

    private fun checkReady() { generate.isEnabled = detailUri != null && sohUri != null }

    private fun lightDialogBuilder(): AlertDialog.Builder =
        AlertDialog.Builder(ContextThemeWrapper(this, R.style.Theme_SaleThru_Dialog))

    private fun dp(value: Int): Int =
        (value * resources.displayMetrics.density).roundToInt()

    private class SimpleItemSelectedListener(
        private val action: (Int) -> Unit
    ) : AdapterView.OnItemSelectedListener {
        override fun onItemSelected(
            parent: AdapterView<*>?,
            view: View?,
            position: Int,
            id: Long
        ) {
            action(position)
        }

        override fun onNothingSelected(parent: AdapterView<*>?) = Unit
    }

    // ---------------- Validation / Alerts ----------------

    private data class MasterIssues(val catalogue: List<String>, val sizes: List<String>)

    private fun checkMasterIssues(uri: Uri) {
        lifecycleScope.launch(Dispatchers.IO) {
            try {
                // A newly uploaded Details file gets a fresh working mapping.
                // The permanent Product Master remains untouched.
                saveCurrentProductMappings(emptyList())
                val mappedCodes = loadCatalogue().map { it.code }.toSet()
                val savedSizes = loadSizeMaster().associateBy { it.size }
                val missingCodes = mutableSetOf<String>()
                val unconfirmedSizes = mutableSetOf<String>()
                val uniqueProducts = linkedMapOf<String, Pair<String, String>>()
                streamCsv(uri) { headers, values, rowNumber ->
                    val code = resolveDetailsCode(headers, values, mappedCodes)
                    val productName = field(values, fieldIndex(headers, "ProductName")).trim()
                    if (code.isNotBlank() && code !in mappedCodes) missingCodes += code
                    if (code.isNotBlank() && productName.isNotBlank()) {
                        uniqueProducts["$code|${normalizeProductName(productName)}"] = code to productName
                    }
                    if (rowNumber % 2500 == 0) updateProcessing("Scanning Products… $rowNumber rows")
                }

                // Build the working mapping for THIS uploaded file from the permanent
                // Product Master. Only products actually present in the sheet are copied.
                val master = loadProductMappings().associateBy {
                    "${it.code.uppercase(Locale.ROOT)}|${normalizeProductName(it.productName)}"
                }
                val catalogue = loadCatalogue().associateBy { it.code.uppercase(Locale.ROOT) }
                val current = uniqueProducts.values.map { (code, productName) ->
                    val key = "${code.uppercase(Locale.ROOT)}|${normalizeProductName(productName)}"
                    val saved = master[key]
                    val root = when {
                        saved?.category?.equals("NON-MERCHANDISE", true) == true -> "NONE"
                        saved != null -> saved.root
                        catalogue[code.uppercase(Locale.ROOT)]?.root?.uppercase(Locale.ROOT) == "NONE" -> "NONE"
                        catalogue[code.uppercase(Locale.ROOT)]?.root?.uppercase(Locale.ROOT) == "CORE" -> "CORE"
                        else -> "FASHION"
                    }
                    val category = when {
                        saved != null -> saved.category
                        root.equals("NONE", true) -> "NON-MERCHANDISE"
                        else -> ""
                    }
                    ProductMapping(code.uppercase(Locale.ROOT), productName, category, root)
                }
                saveCurrentProductMappings(current)

                // Size Master is learned from SOH because SOH represents the
                // actual size assortment physically present in the store.
                val sohSizes = sohUri?.let { extractUniqueSizes(it) } ?: emptyList()
                sohSizes.forEach { size ->
                    if (size.isNotBlank() && savedSizes[size]?.confirmed != true) unconfirmedSizes += size
                }

                withContext(Dispatchers.Main) { updateMasterAlert(missingCodes.sorted(), unconfirmedSizes.sorted()) }
            } catch (_: Exception) { }
        }
    }

    private fun checkSizeMasterIssuesFromSoh(uri: Uri) {
        lifecycleScope.launch(Dispatchers.IO) {
            try {
                val savedSizes = loadSizeMaster().associateBy { it.size }
                val unconfirmedSizes = extractUniqueSizes(uri)
                    .filter { it.isNotBlank() && savedSizes[it]?.confirmed != true }
                    .distinct()
                    .sorted()
                withContext(Dispatchers.Main) {
                    val existing = catalogueAlert.tag as? MasterIssues
                    updateMasterAlert(existing?.catalogue ?: emptyList(), unconfirmedSizes)
                }
            } catch (_: Exception) { }
        }
    }

    private fun learnProductMasterFromSoh(uri: Uri) {
        lifecycleScope.launch(Dispatchers.IO) {
            try {
                updateProcessing("Learning Product Master from SOH…")
                val existing = loadProductMappings().associateBy {
                    "${it.code.uppercase(Locale.ROOT)}|${normalizeProductName(it.productName)}"
                }.toMutableMap()
                val catalogue = loadCatalogue().associateBy { it.code.uppercase(Locale.ROOT) }
                val newProducts = linkedMapOf<String, ProductMapping>()
                streamCsv(uri) { headers, values, rowNumber ->
                    val code = firstNonBlankField(headers, values, "ArticleNumber", "ProductCode", "CategoryCode")
                        .uppercase(Locale.ROOT)
                    val name = firstNonBlankField(headers, values, "ProductName", "ProductFullName").trim()
                    if (code.isNotBlank() && name.isNotBlank()) {
                        val key = "$code|${normalizeProductName(name)}"
                        if (!existing.containsKey(key)) {
                            val root = when (catalogue[code]?.root?.uppercase(Locale.ROOT)) {
                                "CORE" -> "CORE"
                                "NONE" -> "NONE"
                                else -> "FASHION"
                            }
                            newProducts[key] = ProductMapping(code, name, if (root == "NONE") "NON-MERCHANDISE" else "", root)
                        }
                    }
                    if (rowNumber % 5000 == 0) updateProcessing("Learning Product Master… $rowNumber SOH rows")
                }
                if (newProducts.isNotEmpty()) {
                    val merged = loadProductMappings().toMutableList()
                    merged += newProducts.values
                    saveProductMappings(merged)
                }
                withContext(Dispatchers.Main) {
                    updateProcessing("")
                    if (newProducts.isNotEmpty()) {
                        lightDialogBuilder()
                            .setTitle("SOH Product Master Update")
                            .setMessage("${newProducts.size} new product mapping(s) found in the SOH file. They have been added to Product Master. Please assign their categories there. Existing mappings were kept.")
                            .setNegativeButton("Later", null)
                            .setPositiveButton("Open Product Master") { _, _ -> showProductMaster() }
                            .show()
                    } else {
                        Toast.makeText(this@MainActivity, "SOH scanned • Product Master is already up to date", Toast.LENGTH_SHORT).show()
                    }
                }
            } catch (e: Exception) {
                withContext(Dispatchers.Main) {
                    Toast.makeText(this@MainActivity, "SOH mapping scan failed: ${e.message ?: "Unknown error"}", Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    private fun updateMasterAlert(catalogueMissing: List<String>, sizeMissing: List<String>) {
        if (catalogueMissing.isEmpty() && sizeMissing.isEmpty()) {
            catalogueAlert.visibility = View.GONE; catalogueAlert.tag = null
        } else {
            catalogueAlert.visibility = View.VISIBLE; catalogueAlert.text = "!"
            catalogueAlert.tag = MasterIssues(catalogueMissing, sizeMissing)
        }
    }

    private fun showMissingMasterDialog() {
        val issues = catalogueAlert.tag as? MasterIssues ?: return
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(24, 8, 24, 0) }
        if (issues.catalogue.isNotEmpty()) {
            box.addView(TextView(this).apply { text = "CATALOGUE • ${issues.catalogue.size} missing"; textSize = 12f; setTextColor(0xFFD92D20.toInt()); setTypeface(null, android.graphics.Typeface.BOLD) })
            issues.catalogue.forEach { code ->
                val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
                row.addView(TextView(this).apply { text = code; textSize = 15f }, LinearLayout.LayoutParams(0, 50, 1f))
                row.addView(Button(this).apply { text = "ADD"; setOnClickListener { showMappingEditor(code, null) } })
                box.addView(row)
            }
        }
        if (issues.sizes.isNotEmpty()) {
            box.addView(TextView(this).apply { text = "NEW SIZES • ${issues.sizes.size} need confirmation"; textSize = 12f; setTextColor(0xFFB54708.toInt()); setTypeface(null, android.graphics.Typeface.BOLD); setPadding(0, 14, 0, 0) })
            issues.sizes.forEach { size ->
                val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
                row.addView(TextView(this).apply { text = "$size • default Normal"; textSize = 15f }, LinearLayout.LayoutParams(0, 50, 1f))
                row.addView(Button(this).apply { text = "SET"; setOnClickListener { showSizeManager() } })
                box.addView(row)
            }
        }
        lightDialogBuilder().setTitle("Master Update Required").setView(box).setNegativeButton("Close", null).show()
    }

    private fun firstNonBlankField(headers: List<String>, values: List<String>, vararg names: String): String {
        for (name in names) {
            val value = field(values, fieldIndex(headers, name))
            if (value.isNotBlank()) return value
        }
        return ""
    }

    private fun fieldIndex(headers: List<String>, vararg names: String): Int {
        for (name in names) {
            val idx = headers.indexOfFirst { it.equals(name, ignoreCase = true) }
            if (idx >= 0) return idx
        }
        return -1
    }

    private fun field(values: List<String>, index: Int): String =
        if (index >= 0 && index < values.size) values[index].trim().trim('"') else ""

    private fun splitCsv(line: String): List<String> {
        val out = ArrayList<String>()
        val sb = StringBuilder()
        var quoted = false
        var i = 0
        while (i < line.length) {
            val c = line[i]
            if (c == '"') {
                if (quoted && i + 1 < line.length && line[i + 1] == '"') { sb.append('"'); i++ }
                else quoted = !quoted
            } else if (c == ',' && !quoted) {
                out.add(sb.toString()); sb.setLength(0)
            } else sb.append(c)
            i++
        }
        out.add(sb.toString())
        return out
    }

    // ---------------- Category Master ----------------

    private fun defaultCategories(): List<String> = listOf(
        "Kids", "PANTS", "JEANS", "ATHLEISURE", "Shorts", "TROUSER", "CORE",
        "ETHNIC", "JEGGINGS", "PALAZZO", "LOUNGE WEAR", "WINTER", "GEN Z"
    )

    private fun seedDefaultCategoriesIfNeeded() {
        if (prefs.getBoolean("category_seeded", false)) return
        saveCategories(defaultCategories())
        prefs.edit().putBoolean("category_seeded", true).apply()
    }

    private fun loadCategories(): MutableList<String> =
        JSONArray(prefs.getString("categories", "[]") ?: "[]").let { arr ->
            MutableList(arr.length()) { i -> arr.optString(i).trim() }.filter { it.isNotBlank() }.toMutableList()
        }

    private fun saveCategories(list: List<String>) {
        val arr = JSONArray()
        list.distinctBy { it.uppercase(Locale.ROOT) }.sortedBy { it.uppercase(Locale.ROOT) }.forEach { arr.put(it) }
        prefs.edit().putString("categories", arr.toString()).apply()
    }

    private fun loadRoots(): MutableList<String> {
        val saved = JSONArray(prefs.getString("roots", "[]") ?: "[]")
        val roots = MutableList(saved.length()) { i -> saved.optString(i).trim().uppercase(Locale.ROOT) }
            .filter { it.isNotBlank() }.toMutableList()
        if (roots.isEmpty()) roots.addAll(listOf("CORE", "FASHION", "NONE"))
        return roots
    }

    private fun saveRoots(roots: List<String>) {
        val arr = JSONArray()
        roots.map { it.trim().uppercase(Locale.ROOT) }.filter { it.isNotBlank() }
            .distinctBy { it.uppercase(Locale.ROOT) }.sorted().forEach { arr.put(it) }
        prefs.edit().putString("roots", arr.toString()).apply()
    }

    private fun showCategoryManager() {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(22, 4, 22, 0) }
        val tabs = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val categoryTab = Button(this).apply { text = "Category Master"; setAllCaps(false) }
        val rootTab = Button(this).apply { text = "Root Master"; setAllCaps(false) }
        tabs.addView(categoryTab, LinearLayout.LayoutParams(0, dp(48), 1f))
        tabs.addView(rootTab, LinearLayout.LayoutParams(0, dp(48), 1f))
        box.addView(tabs)
        val scroll = ScrollView(this)
        val rows = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(rows)
        box.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        val add = Button(this).apply { setAllCaps(false) }
        box.addView(add)
        var showingRoots = false
        fun refresh() {
            rows.removeAllViews()
            if (showingRoots) {
                val roots = loadRoots()
                roots.forEach { addRootRow(rows, it, ::refresh) }
                add.text = "+ Add Root"
                categoryTab.alpha = 0.7f; rootTab.alpha = 1f
            } else {
                val categories = loadCategories()
                categories.forEach { addCategoryRow(rows, it) }
                add.text = "+ Add Category"
                categoryTab.alpha = 1f; rootTab.alpha = 0.7f
            }
        }
        categoryTab.setOnClickListener { showingRoots = false; refresh() }
        rootTab.setOnClickListener { showingRoots = true; refresh() }
        add.setOnClickListener { if (showingRoots) showRootEditor("", ::refresh) else showCategoryEditor("", rows) }
        refresh()
        lightDialogBuilder().setTitle("Category / Root Master").setView(box)
            .setNegativeButton("Close", null).show()
    }

    private fun addRootRow(parent: LinearLayout, rootName: String, refresh: () -> Unit) {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(8), dp(4), dp(4), dp(4)); setBackgroundResource(android.R.drawable.list_selector_background)
            setOnClickListener { showRootEditor(rootName, refresh) }
            setOnLongClickListener {
                lightDialogBuilder().setTitle("Delete Root?")
                    .setMessage("Delete root $rootName? Existing catalogue codes and product mappings using this root will be reassigned to FASHION.")
                    .setNegativeButton("Cancel", null)
                    .setPositiveButton("Delete") { _, _ ->
                        saveRoots(loadRoots().filterNot { it.equals(rootName, true) })
                        saveCatalogue(loadCatalogue().map { if (it.root.equals(rootName, true)) it.copy(root = "FASHION") else it })
                        saveProductMappings(loadProductMappings().map { if (it.root.equals(rootName, true)) it.copy(root = "FASHION") else it })
                        refresh()
                        Toast.makeText(this@MainActivity, "$rootName deleted", Toast.LENGTH_SHORT).show()
                    }.show()
                true
            }
        }
        row.addView(TextView(this).apply { text = rootName; textSize = 15f; setTextColor(0xFF0B2545.toInt()) }, LinearLayout.LayoutParams(0, dp(50), 1f))
        row.addView(TextView(this).apply { text = "Edit  •  Long press to delete"; textSize = 10f; setTextColor(0xFF667085.toInt()) })
        parent.addView(row)
    }

    private fun showRootEditor(existing: String, refresh: () -> Unit) {
        val input = EditText(this).apply { hint = "Root name"; setText(existing); isSingleLine = true }
        lightDialogBuilder().setTitle(if (existing.isBlank()) "Add Root" else "Edit Root")
            .setView(input).setNegativeButton("Cancel", null).setPositiveButton("Save") { _, _ ->
                val value = input.text.toString().trim().uppercase(Locale.ROOT)
                if (value.isBlank()) { Toast.makeText(this, "Enter root name", Toast.LENGTH_SHORT).show(); return@setPositiveButton }
                val roots = loadRoots()
                if (roots.any { it.equals(value, true) && !it.equals(existing, true) }) {
                    Toast.makeText(this, "Root already exists", Toast.LENGTH_SHORT).show(); return@setPositiveButton
                }
                if (existing.isNotBlank()) {
                    val index = roots.indexOfFirst { it.equals(existing, true) }
                    if (index >= 0) roots[index] = value
                } else roots += value
                saveRoots(roots)
                if (existing.isNotBlank() && !existing.equals(value, true)) {
                    saveCatalogue(loadCatalogue().map { if (it.root.equals(existing, true)) it.copy(root = value) else it })
                    saveProductMappings(loadProductMappings().map { if (it.root.equals(existing, true)) it.copy(root = value) else it })
                }
                refresh()
                Toast.makeText(this, "$value saved", Toast.LENGTH_SHORT).show()
            }.show()
    }

    private fun addCategoryRow(parent: LinearLayout, category: String) {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(8), dp(4), dp(4), dp(4))
            setBackgroundResource(android.R.drawable.list_selector_background)
            isClickable = true
            setOnClickListener { showCategoryEditor(category, parent) }
            setOnLongClickListener {
                lightDialogBuilder().setTitle("Delete Category?")
                    .setMessage("Delete \"$category\" from Category Master? Existing product/code mappings will be moved to Uncategorised and historical data will not be deleted.")
                    .setNegativeButton("Cancel", null)
                    .setPositiveButton("Delete") { _, _ ->
                        val list = loadCategories().filterNot { it.equals(category, true) }
                        saveCategories(list)
                        val mappings = loadCatalogue().map { if (it.category.equals(category, true)) it.copy(category = "Uncategorised") else it }
                        saveCatalogue(mappings)
                        val products = loadProductMappings().map { if (it.category.equals(category, true)) it.copy(category = "Uncategorised") else it }
                        saveProductMappings(products)
                        parent.removeAllViews(); loadCategories().forEach { addCategoryRow(parent, it) }
                        Toast.makeText(this@MainActivity, "$category deleted", Toast.LENGTH_SHORT).show()
                    }.show()
                true
            }
        }
        row.addView(TextView(this).apply { text = category; textSize = 15f; setTextColor(0xFF0B2545.toInt()) }, LinearLayout.LayoutParams(0, dp(50), 1f))
        row.addView(TextView(this).apply { text = "Edit  •  Long press to delete"; textSize = 10f; setTextColor(0xFF667085.toInt()) })
        parent.addView(row)
    }

    private fun showCategoryEditor(existing: String, parent: LinearLayout? = null) {
        val input = EditText(this).apply { hint = "Category name"; setText(existing); isSingleLine = true }
        lightDialogBuilder().setTitle(if (existing.isBlank()) "Add Category" else "Edit Category")
            .setView(input).setNegativeButton("Cancel", null).setPositiveButton("Save") { _, _ ->
                val value = input.text.toString().trim()
                if (value.isBlank()) return@setPositiveButton
                val list = loadCategories()
                if (existing.isNotBlank()) {
                    val idx = list.indexOfFirst { it.equals(existing, true) }
                    if (idx >= 0) list[idx] = value
                } else list += value
                saveCategories(list)
                Toast.makeText(this@MainActivity, "$value saved", Toast.LENGTH_SHORT).show()
                if (parent != null) { parent.removeAllViews(); loadCategories().forEach { addCategoryRow(parent, it) } }
            }.show()
    }

    // ---------------- Size Master ----------------

    private fun seedDefaultSizesIfNeeded() {
        if (prefs.getBoolean("size_seeded", false)) return
        val defaults = listOf("2X", "2P", "3X", "3P", "4X", "4P", "36", "38")
            .map { SizeEntry(it, "Normal", true) }
        saveSizeMaster(defaults)
        prefs.edit().putBoolean("size_seeded", true).apply()
    }

    private fun loadSizeMaster(): MutableList<SizeEntry> {
        val arr = JSONArray(prefs.getString("sizes", "[]") ?: "[]")
        val list = mutableListOf<SizeEntry>()
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            list += SizeEntry(o.optString("size").uppercase(Locale.ROOT), o.optString("type", "Normal").ifBlank { "Normal" }, o.optBoolean("confirmed", true))
        }
        return list
    }

    private fun saveSizeMaster(list: List<SizeEntry>) {
        val arr = JSONArray()
        list.distinctBy { it.size.uppercase(Locale.ROOT) }.sortedBy { it.size }.forEach {
            arr.put(JSONObject().apply { put("size", it.size.uppercase(Locale.ROOT)); put("type", if (it.type == "Plus Size") "Plus Size" else "Normal"); put("confirmed", it.confirmed) })
        }
        prefs.edit().putString("sizes", arr.toString()).apply()
    }

    private fun showSizeManager() {
        val saved = loadSizeMaster().associateBy { it.size }
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(4), dp(12), 0)
        }

        val info = TextView(this).apply {
            text = if (sohUri != null) {
                "Loading sizes from current SOH file…"
            } else {
                "Saved Size Master"
            }
            textSize = 12f
            setTextColor(0xFF667085.toInt())
            setPadding(dp(8), dp(4), dp(8), dp(8))
        }
        box.addView(info)

        val listView = ListView(this).apply {
            divider = null
            dividerHeight = 0
            clipToPadding = false
            setPadding(0, 0, 0, dp(4))
        }

        val typeChoices = arrayOf("Normal", "Plus Size")
        val spinnerEntries = linkedMapOf<String, Spinner>()
        var currentNames = saved.keys.toList().sorted()

        val adapter = object : BaseAdapter() {
            override fun getCount(): Int = currentNames.size
            override fun getItem(position: Int): String = currentNames[position]
            override fun getItemId(position: Int): Long = position.toLong()

            override fun getView(position: Int, convertView: View?, parent: android.view.ViewGroup): View {
                val sizeName = currentNames[position]
                val entry = saved[sizeName] ?: SizeEntry(sizeName, "Normal", false)

                val row = LinearLayout(this@MainActivity).apply {
                    orientation = LinearLayout.HORIZONTAL
                    gravity = Gravity.CENTER_VERTICAL
                    setPadding(dp(10), dp(5), dp(8), dp(5))
                    setBackgroundColor(0xFFF9FAFB.toInt())
                }

                val name = TextView(this@MainActivity).apply {
                    text = if (entry.confirmed) entry.size else "${entry.size}  • NEW"
                    textSize = 14f
                    setTypeface(null, android.graphics.Typeface.BOLD)
                    setTextColor(if (entry.confirmed) 0xFF0B2545.toInt() else 0xFFB54708.toInt())
                    gravity = Gravity.CENTER_VERTICAL
                }
                row.addView(name, LinearLayout.LayoutParams(0, dp(48), 1f))

                val spinner = Spinner(this@MainActivity).apply {
                    adapter = ArrayAdapter(
                        this@MainActivity,
                        android.R.layout.simple_spinner_dropdown_item,
                        typeChoices
                    )
                    setSelection(if (entry.type == "Plus Size") 1 else 0)
                }
                spinnerEntries[sizeName] = spinner
                row.addView(spinner, LinearLayout.LayoutParams(dp(125), dp(48)))

                val line = View(this@MainActivity).apply {
                    setBackgroundColor(0xFFD5DCE8.toInt())
                }
                val wrapper = LinearLayout(this@MainActivity).apply {
                    orientation = LinearLayout.VERTICAL
                }
                wrapper.addView(row)
                wrapper.addView(line, LinearLayout.LayoutParams(-1, 1))
                return wrapper
            }
        }

        listView.adapter = adapter
        box.addView(
            listView,
            LinearLayout.LayoutParams(-1, dp(390))
        )

        val actions = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(4), 0, dp(4))
        }

        val close = Button(this).apply {
            text = "Close"
            setAllCaps(false)
        }
        val save = Button(this).apply {
            text = "Save All"
            setAllCaps(false)
        }

        actions.addView(close, LinearLayout.LayoutParams(0, dp(48), 1f))
        actions.addView(save, LinearLayout.LayoutParams(0, dp(48), 1f))
        box.addView(actions)

        val dialog = lightDialogBuilder()
            .setTitle("Size Master")
            .setView(box)
            .create()

        close.setOnClickListener { dialog.dismiss() }
        save.setOnClickListener {
            val updated = spinnerEntries.map { (size, spinner) ->
                SizeEntry(size, typeChoices[spinner.selectedItemPosition], true)
            }
            val existing = loadSizeMaster().associateBy { it.size }.toMutableMap()
            updated.forEach { existing[it.size] = it }
            saveSizeMaster(existing.values.toList())
            detailUri?.let { checkMasterIssues(it) } ?: sohUri?.let { checkSizeMasterIssuesFromSoh(it) }
            Toast.makeText(this@MainActivity, "Size Master saved", Toast.LENGTH_SHORT).show()
            dialog.dismiss()
        }

        dialog.show()

        val selectedSoh = sohUri
        if (selectedSoh != null) {
            lifecycleScope.launch(Dispatchers.IO) {
                val names = extractUniqueSizes(selectedSoh)
                withContext(Dispatchers.Main) {
                    if (!isFinishing && !isDestroyed && dialog.isShowing) {
                        currentNames = names.distinct().sorted()
                        spinnerEntries.clear()
                        info.text = "Unique sizes from current SOH file • ${currentNames.size} sizes • New sizes start as Normal"
                        adapter.notifyDataSetChanged()
                    }
                }
            }
        }
    }

    private fun extractUniqueSizes(uri: Uri): List<String> {
        val out = linkedSetOf<String>()
        try {
            streamCsv(uri) { headers, values, _ ->
                val idx = fieldIndex(headers, "Size")
                val size = field(values, idx).uppercase(Locale.ROOT)
                if (size.isNotBlank()) out += size
            }
        } catch (_: Exception) { }
        return out.toList()
    }

    // ---------------- Catalogue Master ----------------

    private fun seedDefaultCatalogueIfNeeded() {
        if (prefs.getBoolean("seeded", false)) return
        val defaults = mutableListOf<Mapping>()
        fun add(root: String, category: String, codes: String) {
            codes.split(",").map { it.trim() }.filter { it.isNotBlank() }.forEach { defaults += Mapping(it.uppercase(Locale.ROOT), category, root) }
        }
        add("FASHION", "Kids", "GCYC,GH,GJ01,GJ02,GJ03,GJ07,GL,GL02,GL03,GLC,GLR,GPT1,GPZ,GSH1,GSH2,GSH3")
        add("FASHION", "PANTS", "LP32,LPT1,LPT2,LPT3,LPT4,LPT7,LPT8,LPT9,LPZ4,LPZ8,LPT5")
        add("FASHION", "JEANS", "LJ11,LJ12,LJ13,LJ14,LJ15,LJ16,LJ17,LJ18,LJ19,LJ20")
        add("FASHION", "ATHLEISURE", "LAT8,LL03,LL04,LA06,LL06,LAC1,LL07")
        add("FASHION", "Shorts", "HS01,HS11,LCYC,LLS3,LSH2,LSH3,LSH4")
        add("FASHION", "TROUSER", "LT01,LT04,LT03,LT06,LT07,LT08,LT09,LTC9")
        add("CORE", "CORE", "LC,LC02,LL,LL02,LLC,LLR")
        add("FASHION", "ETHNIC", "LH01,LH02,LH03,LP02,LSC1,LSW1")
        add("FASHION", "JEGGINGS", "LJ02,LJ03,LJ05,LJ06,LJ07,LJC3")
        add("FASHION", "PALAZZO", "LPZ1,LPZ3,LPZ5,LPZ6,LPZ7")
        add("FASHION", "LOUNGE WEAR", "HP01,HP11,HP21")
        add("FASHION", "WINTER", "LJW1,LJW2,LJW3,LJW7,LLW2,LLW3,LLW4,LPW5,LTW2,LPW1,LPW2,LPW3,LPW4,LPW8,LTW1,LLW5,LPT8")
        add("FASHION", "GEN Z", "ZP01,ZP04,ZD01,ZD11,ZP02")
        saveCatalogue(defaults)
        prefs.edit().putBoolean("seeded", true).apply()
    }

    private fun ensureSpecialCatalogueMappings() {
        val all = loadCatalogue()
        if (all.none { it.code.equals("P-CB", true) }) {
            all += Mapping("P-CB", "NON-MERCHANDISE", "NONE")
            saveCatalogue(all)
        }
    }

    private fun loadCatalogue(): MutableList<Mapping> {
        val arr = JSONArray(prefs.getString("mappings", "[]") ?: "[]")
        val list = mutableListOf<Mapping>()
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            list += Mapping(o.optString("code").uppercase(Locale.ROOT), o.optString("category"), o.optString("root", "FASHION"))
        }
        return list
    }

    private fun saveCatalogue(list: List<Mapping>) {
        val arr = JSONArray()
        list.sortedBy { it.code }.forEach { m ->
            arr.put(JSONObject().apply { put("code", m.code); put("category", m.category); put("root", m.root) })
        }
        prefs.edit().putString("mappings", arr.toString()).apply()
    }

    private fun normalizeProductName(value: String): String =
        value.trim().replace(Regex("\\s+"), " ").uppercase(Locale.ROOT)

    private fun loadProductMappings(): MutableList<ProductMapping> {
        val arr = JSONArray(prefs.getString("product_mappings", "[]") ?: "[]")
        val list = mutableListOf<ProductMapping>()
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            val code = o.optString("code").trim().uppercase(Locale.ROOT)
            val product = o.optString("productName").trim()
            if (code.isNotBlank() && product.isNotBlank()) {
                list += ProductMapping(code, product, o.optString("category", "").let { if (it.equals("Uncategorised", true)) "" else it }, o.optString("root", "FASHION"))
            }
        }
        return list
    }

    private fun saveProductMappings(list: List<ProductMapping>) {
        val arr = JSONArray()
        list.distinctBy { "${it.code.uppercase(Locale.ROOT)}|${normalizeProductName(it.productName)}" }
            .sortedWith(compareBy({ it.code }, { normalizeProductName(it.productName) }))
            .forEach { m ->
                arr.put(JSONObject().apply {
                    put("code", m.code.uppercase(Locale.ROOT))
                    put("productName", m.productName.trim())
                    put("category", m.category)
                    put("root", m.root.uppercase(Locale.ROOT))
                })
            }
        prefs.edit().putString("product_mappings", arr.toString()).apply()
    }

    // Current-sheet mapping is a working copy initialized from the permanent
    // Product Master when a Details file is uploaded. Editing this layer does
    // not overwrite the permanent master unless the user explicitly changes
    // Product Master.
    private fun loadCurrentProductMappings(): MutableList<ProductMapping> {
        val arr = JSONArray(prefs.getString(PREF_CURRENT_PRODUCT_MAPPINGS, "[]") ?: "[]")
        val list = mutableListOf<ProductMapping>()
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            val code = o.optString("code").trim().uppercase(Locale.ROOT)
            val product = o.optString("productName").trim()
            if (code.isNotBlank() && product.isNotBlank()) {
                list += ProductMapping(code, product, o.optString("category", "").let { if (it.equals("Uncategorised", true)) "" else it }, o.optString("root", "FASHION"))
            }
        }
        return list
    }

    private fun saveCurrentProductMappings(list: List<ProductMapping>) {
        val arr = JSONArray()
        list.distinctBy { "${it.code.uppercase(Locale.ROOT)}|${normalizeProductName(it.productName)}" }
            .sortedWith(compareBy({ it.code }, { normalizeProductName(it.productName) }))
            .forEach { m ->
                arr.put(JSONObject().apply {
                    put("code", m.code.uppercase(Locale.ROOT))
                    put("productName", m.productName.trim())
                    put("category", m.category)
                    put("root", m.root.uppercase(Locale.ROOT))
                })
            }
        prefs.edit().putString(PREF_CURRENT_PRODUCT_MAPPINGS, arr.toString()).apply()
    }

    private fun loadReportProductMappings(): MutableList<ProductMapping> {
        // Product Master is the permanent source of truth. The current-file layer
        // is only a working copy and may be older than the Product Master if the
        // user changed a mapping from Full Mapping after uploading Details.
        // Merge both layers, with the permanent Product Master taking priority.
        val merged = linkedMapOf<String, ProductMapping>()
        fun key(m: ProductMapping): String =
            "${m.code.uppercase(Locale.ROOT)}|${normalizeProductName(m.productName)}"

        loadCurrentProductMappings().forEach { merged[key(it)] = it }
        loadProductMappings().forEach { merged[key(it)] = it }
        return merged.values.toMutableList()
    }

    private fun migrateCatalogueAndProductMappings() {
        // Catalogue is now ROOT-only. Preserve the existing CORE/FASHION/NONE
        // root values, but stop using the old code-level category as a report key.
        val current = loadCatalogue()
        if (current.isNotEmpty()) {
            val unique = linkedMapOf<String, Mapping>()
            current.forEach { m ->
                val root = when {
                    m.root.equals("CORE", true) -> "CORE"
                    m.root.equals("NONE", true) -> "NONE"
                    else -> "FASHION"
                }
                unique.putIfAbsent(m.code.uppercase(Locale.ROOT), Mapping(m.code.uppercase(Locale.ROOT), "", root))
            }
            saveCatalogue(unique.values.toList())
        }

        val catalogueRoots = loadCatalogue().associate { it.code.uppercase(Locale.ROOT) to it.root.uppercase(Locale.ROOT) }
        val products = loadProductMappings().toMutableList()
        fun add(code: String, product: String, category: String) {
            val root = if (category.equals("NON-MERCHANDISE", true)) "NONE"
            else catalogueRoots[code.uppercase(Locale.ROOT)] ?: "FASHION"
            if (products.none { it.code.equals(code, true) && normalizeProductName(it.productName) == normalizeProductName(product) }) {
                products += ProductMapping(code.uppercase(Locale.ROOT), product, category, root)
            }
        }
        // Known multi-category entries. More are discovered from the uploaded Details file.
        add("LPT8", "Ladies Jogger Pant", "PANTS")
        add("LPT8", "Suede Bell Bottom", "WINTER")
        add("LPT8", "Suede Bell Bottom (WINTER)", "WINTER")
        saveProductMappings(products.map { pm ->
            val root = if (pm.category.equals("NON-MERCHANDISE", true)) "NONE"
            else catalogueRoots[pm.code.uppercase(Locale.ROOT)] ?: pm.root
            pm.copy(root = root)
        })
    }

    private fun resolveMapping(
        code: String,
        productName: String,
        catalogue: Map<String, Mapping>,
        overrides: Map<String, List<ProductMapping>>
    ): Mapping? {
        val normalizedCode = code.trim().uppercase(Locale.ROOT)
        if (normalizedCode.isBlank()) return null
        val base = catalogue[normalizedCode] ?: return null
        val baseRoot = when {
            base.root.equals("CORE", true) -> "CORE"
            base.root.equals("NONE", true) -> "NONE"
            else -> "FASHION"
        }
        if (baseRoot == "NONE") return Mapping(normalizedCode, "NON-MERCHANDISE", "NONE")
        val exact = overrides[normalizedCode].orEmpty().firstOrNull {
            normalizeProductName(it.productName) == normalizeProductName(productName)
        } ?: return null
        val category = exact.category.trim()
        if (category.isBlank()) return null
        val root = if (category.equals("NON-MERCHANDISE", true)) "NONE" else baseRoot
        return Mapping(normalizedCode, category, root)
    }

    private fun isNonMerchandiseRow(
        headers: List<String>,
        values: List<String>,
        catalogue: Map<String, Mapping>,
        overrides: Map<String, List<ProductMapping>>
    ): Boolean {
        val code = resolveDetailsCode(headers, values, catalogue.keys).trim().uppercase(Locale.ROOT)
        if (code.isBlank()) return false
        val productName = field(values, fieldIndex(headers, "ProductName"))
        val mapping = resolveMapping(code, productName, catalogue, overrides)
        return mapping?.category?.equals("NON-MERCHANDISE", true) == true || mapping?.root.equals("NONE", true)
    }

    private fun showProductMappingManager() {
        val items = loadProductMappings().sortedWith(compareBy({ it.code }, { normalizeProductName(it.productName) })).toMutableList()
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(10), dp(4), dp(10), 0) }
        box.addView(TextView(this).apply {
            text = "Product-level overrides • used when one code belongs to multiple categories. Tap to edit; long press to delete."
            textSize = 12f; setTextColor(0xFF667085.toInt()); setPadding(dp(8), dp(4), dp(8), dp(8))
        })
        val listView = ListView(this).apply { divider = null; dividerHeight = 0; isFastScrollEnabled = true }
        val adapter = object : BaseAdapter() {
            override fun getCount() = items.size
            override fun getItem(position: Int) = items[position]
            override fun getItemId(position: Int) = position.toLong()
            override fun getView(position: Int, convertView: View?, parent: android.view.ViewGroup): View {
                val m = items[position]
                val row = LinearLayout(this@MainActivity).apply {
                    orientation = LinearLayout.VERTICAL; setPadding(dp(10), dp(8), dp(10), dp(8)); setBackgroundResource(android.R.drawable.list_selector_background)
                    setOnClickListener { showProductMappingEditor(m, items, null) }
                    setOnLongClickListener {
                        lightDialogBuilder().setTitle("Delete Product Mapping?")
                            .setMessage("Delete ${m.code} → ${m.productName}? The base code mapping will remain unchanged.")
                            .setNegativeButton("Cancel", null)
                            .setPositiveButton("Delete") { _, _ ->
                                items.removeAll { it.code.equals(m.code, true) && normalizeProductName(it.productName) == normalizeProductName(m.productName) }; saveProductMappings(items); notifyDataSetChanged(); Toast.makeText(this@MainActivity, "Product mapping deleted", Toast.LENGTH_SHORT).show()
                            }.show(); true
                    }
                }
                row.addView(TextView(this@MainActivity).apply { text = "${m.code}  •  ${m.productName}"; textSize = 14f; setTypeface(null, android.graphics.Typeface.BOLD); setTextColor(0xFF0B2545.toInt()) })
                row.addView(TextView(this@MainActivity).apply { text = "${m.category}  •  ${m.root}"; textSize = 11f; setTextColor(0xFF667085.toInt()); setPadding(0, dp(3), 0, 0) })
                return row
            }
        }
        listView.adapter = adapter
        box.addView(listView, LinearLayout.LayoutParams(-1, dp(390)))
        val actions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val add = Button(this).apply { text = "+ Add Mapping"; setAllCaps(false) }
        val close = Button(this).apply { text = "Close"; setAllCaps(false) }
        actions.addView(add, LinearLayout.LayoutParams(0, dp(48), 1f)); actions.addView(close, LinearLayout.LayoutParams(0, dp(48), 1f)); box.addView(actions)
        val dialog = lightDialogBuilder().setTitle("Product Mappings • ${items.size}").setView(box).create()
        add.setOnClickListener { showProductMappingEditor(null, items, adapter) }
        close.setOnClickListener { dialog.dismiss() }
        dialog.show()
    }

    private fun showProductMappingEditor(existing: ProductMapping?, items: MutableList<ProductMapping>, refresh: Any?) {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(8), dp(4), dp(8), 0) }
        val code = EditText(this).apply { hint = "ProductGroupCode"; setText(existing?.code ?: ""); isSingleLine = true; isEnabled = existing == null }
        val product = EditText(this).apply { hint = "Exact Product Name"; setText(existing?.productName ?: ""); isSingleLine = true }
        val cats = loadCategories().toMutableList(); if (existing != null && cats.none { it.equals(existing.category, true) }) cats += existing.category
        if (cats.none { it.equals("Uncategorised", true) }) cats += "Uncategorised"
        val cat = Spinner(this).apply { adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, cats); setSelection(cats.indexOfFirst { it.equals(existing?.category, true) }.coerceAtLeast(0)) }
        val roots = loadRoots().toTypedArray()
        val root = Spinner(this).apply { adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, roots); setSelection(roots.indexOfFirst { it.equals(existing?.root, true) }.coerceAtLeast(0)) }
        box.addView(code); box.addView(product); box.addView(cat); box.addView(root)
        lightDialogBuilder().setTitle(if (existing == null) "Add Product Mapping" else "Edit Product Mapping")
            .setView(box).setNegativeButton("Cancel", null).setPositiveButton("Save") { _, _ ->
                val c = code.text.toString().trim().uppercase(Locale.ROOT); val pn = product.text.toString().trim()
                if (c.isBlank() || pn.isBlank()) { Toast.makeText(this@MainActivity, "Enter code and product name", Toast.LENGTH_SHORT).show(); return@setPositiveButton }
                val m = ProductMapping(c, pn, cats[cat.selectedItemPosition], roots[root.selectedItemPosition])
                val idx = items.indexOfFirst { it.code.equals(c, true) && normalizeProductName(it.productName) == normalizeProductName(pn) }
                if (idx >= 0) items[idx] = m else items += m
                saveProductMappings(items)
                if (refresh is BaseAdapter) refresh.notifyDataSetChanged()
                Toast.makeText(this@MainActivity, "Product mapping saved", Toast.LENGTH_SHORT).show()
            }.show()
    }

    private fun showCatalogueManager() {
        val initialList = loadCatalogue().sortedBy { it.code }.toMutableList()
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(10), dp(4), dp(10), 0) }
        box.addView(TextView(this).apply {
            text = "Catalogue Master • code → CORE / FASHION / NONE only • category is managed in Product Mapping"
            textSize = 12f; setTextColor(0xFF667085.toInt()); setPadding(dp(8), dp(3), dp(8), dp(7))
        })
        val listView = ListView(this).apply { divider = null; dividerHeight = 0; isFastScrollEnabled = true }
        val rootChoices = loadRoots().toTypedArray()
        val adapter = object : BaseAdapter() {
            val items = initialList.toMutableList()
            override fun getCount() = items.size
            override fun getItem(position: Int) = items[position]
            override fun getItemId(position: Int) = position.toLong()
            override fun getView(position: Int, convertView: View?, parent: android.view.ViewGroup): View {
                val m = items[position]
                val row = LinearLayout(this@MainActivity).apply {
                    orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
                    setPadding(dp(10), dp(5), dp(6), dp(5)); setBackgroundResource(android.R.drawable.list_selector_background)
                    setOnLongClickListener {
                        lightDialogBuilder().setTitle("Delete Code?")
                            .setMessage("Delete ${m.code} and all product mappings for this code?")
                            .setNegativeButton("Cancel", null)
                            .setPositiveButton("Delete") { _, _ ->
                                saveCatalogue(loadCatalogue().filterNot { it.code.equals(m.code, true) })
                                saveProductMappings(loadProductMappings().filterNot { it.code.equals(m.code, true) })
                                items.removeAt(position); notifyDataSetChanged()
                            }.show(); true
                    }
                }
                row.addView(TextView(this@MainActivity).apply {
                    text = m.code; textSize = 14f; setTypeface(null, android.graphics.Typeface.BOLD); setTextColor(0xFF0B2545.toInt())
                }, LinearLayout.LayoutParams(0, dp(50), 1f))
                val root = Spinner(this@MainActivity).apply {
                    adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, rootChoices)
                    setSelection(rootChoices.indexOfFirst { it.equals(m.root, true) }.coerceAtLeast(0))
                }
                root.setOnItemSelectedListener(SimpleItemSelectedListener { pos ->
                    val value = rootChoices.getOrNull(pos) ?: return@SimpleItemSelectedListener
                    // ListView rows are recycled while scrolling. Keep the adapter's backing
                    // item in sync with the saved value, otherwise getView() binds the old root.
                    val current = items.getOrNull(position) ?: return@SimpleItemSelectedListener
                    if (!current.root.equals(value, true)) {
                        items[position] = current.copy(root = value)
                        val all = loadCatalogue()
                        val idx = all.indexOfFirst { it.code.equals(current.code, true) }
                        if (idx >= 0) {
                            all[idx] = all[idx].copy(root = value)
                            saveCatalogue(all)
                            val products = loadProductMappings().map { pm ->
                                if (pm.code.equals(current.code, true)) pm.copy(root = if (pm.category.equals("NON-MERCHANDISE", true)) "NONE" else value) else pm
                            }
                            saveProductMappings(products)
                        }
                    }
                })
                row.addView(root, LinearLayout.LayoutParams(dp(135), dp(48)))
                return row
            }
        }
        listView.adapter = adapter
        box.addView(listView, LinearLayout.LayoutParams(-1, dp(520)))
        val add = Button(this).apply { text = "+ Add Code"; setAllCaps(false); setOnClickListener { showMappingEditor("", null) } }
        box.addView(add)
        lightDialogBuilder().setTitle("Catalogue Master • ${initialList.size} codes").setView(box).setPositiveButton("Close", null).show()
    }

    private fun showProductMaster() {
        val items = loadProductMappings()
            .sortedWith(compareBy({ it.category.ifBlank { "UNMAPPED" } }, { normalizeProductName(it.productName) }, { it.code }))
            .toMutableList()
        val categories = loadCategories().toMutableList().apply {
            if (none { it.equals("NON-MERCHANDISE", true) }) add("NON-MERCHANDISE")
        }

        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(10), dp(4), dp(10), 0)
        }
        val info = TextView(this).apply {
            text = "Full Product Master • ${items.size} saved products"
            textSize = 12f
            setTextColor(0xFF667085.toInt())
            setPadding(dp(8), dp(3), dp(8), dp(8))
        }
        box.addView(info)

        // Same category-section behaviour as Quick Mapping:
        // every product is shown under its current category, and selecting
        // another category immediately moves that product to the new section.
        val rows = mutableListOf<Any>()
        fun rebuildRows() {
            rows.clear()
            items.groupBy { it.category.ifBlank { "UNMAPPED" } }
                .toSortedMap(String.CASE_INSENSITIVE_ORDER)
                .forEach { (category, list) ->
                    rows.add(category)
                    rows.addAll(list.sortedWith(compareBy({ normalizeProductName(it.productName) }, { it.code })))
                }
        }
        rebuildRows()

        val listView = ListView(this).apply {
            divider = null
            dividerHeight = 0
            isFastScrollEnabled = true
        }
        box.addView(listView, LinearLayout.LayoutParams(-1, dp(520)))

        lateinit var adapter: BaseAdapter

        fun refreshInfo() {
            info.text = "Full Product Master • ${items.size} saved products • ${items.count { it.category.isBlank() }} unmapped"
        }

        fun saveCategory(item: ProductMapping, newCategory: String) {
            val code = item.code.uppercase(Locale.ROOT)
            val catalogue = loadCatalogue().associateBy { it.code.uppercase(Locale.ROOT) }
            val baseRoot = when (catalogue[code]?.root?.uppercase(Locale.ROOT)) {
                "CORE" -> "CORE"
                "NONE" -> "NONE"
                else -> "FASHION"
            }
            val root = if (newCategory.equals("NON-MERCHANDISE", true)) "NONE" else baseRoot
            val idx = items.indexOfFirst {
                it.code.equals(item.code, true) &&
                    normalizeProductName(it.productName) == normalizeProductName(item.productName)
            }
            if (idx >= 0) {
                items[idx] = items[idx].copy(category = newCategory, root = root)
                saveProductMappings(items)
                rebuildRows()
                adapter.notifyDataSetChanged()
                refreshInfo()
                Toast.makeText(this, "$newCategory • product moved", Toast.LENGTH_SHORT).show()
            }
        }

        adapter = object : BaseAdapter() {
            override fun getCount() = rows.size
            override fun getItem(position: Int) = rows[position]
            override fun getItemId(position: Int) = position.toLong()
            override fun getViewTypeCount() = 2
            override fun getItemViewType(position: Int) = if (rows[position] is String) 0 else 1

            override fun getView(position: Int, convertView: View?, parent: android.view.ViewGroup): View {
                val data = rows[position]
                if (data is String) {
                    val tv = (convertView as? TextView) ?: TextView(this@MainActivity)
                    val count = items.count { it.category.ifBlank { "UNMAPPED" }.equals(data, true) }
                    tv.text = "${data.uppercase(Locale.ROOT)}   •   $count product${if (count == 1) "" else "s"}"
                    tv.textSize = 13f
                    tv.setTypeface(null, android.graphics.Typeface.BOLD)
                    tv.setTextColor(0xFF0B2545.toInt())
                    tv.setBackgroundColor(0xFFE3EAF6.toInt())
                    tv.setPadding(dp(12), dp(10), dp(12), dp(10))
                    return tv
                }

                val item = data as ProductMapping
                val row = (convertView as? LinearLayout) ?: LinearLayout(this@MainActivity).apply {
                    orientation = LinearLayout.HORIZONTAL
                    gravity = Gravity.CENTER_VERTICAL
                }
                row.removeAllViews()
                row.setPadding(dp(10), dp(5), dp(5), dp(5))

                val details = LinearLayout(this@MainActivity).apply { orientation = LinearLayout.VERTICAL }
                details.addView(TextView(this@MainActivity).apply {
                    text = item.productName
                    textSize = 13f
                    setTypeface(null, android.graphics.Typeface.BOLD)
                    setTextColor(0xFF344054.toInt())
                    maxLines = 2
                    ellipsize = android.text.TextUtils.TruncateAt.END
                })
                details.addView(TextView(this@MainActivity).apply {
                    text = "${item.code}  •  Root: ${item.root}"
                    textSize = 10f
                    setTextColor(0xFF667085.toInt())
                    setPadding(0, dp(2), 0, 0)
                })
                row.addView(details, LinearLayout.LayoutParams(0, dp(58), 1f))

                val drop = TextView(this@MainActivity).apply {
                    text = "${item.category.ifBlank { "Select Category" }}  ▼"
                    textSize = 10.5f
                    gravity = Gravity.CENTER
                    setTextColor(0xFF344054.toInt())
                    isClickable = true
                    isFocusable = true
                    background = android.graphics.drawable.GradientDrawable().apply {
                        setColor(0xFFF1F5FB.toInt())
                        cornerRadius = dp(10).toFloat()
                        setStroke(dp(1), 0xFFC3D0E6.toInt())
                    }
                }
                drop.setOnClickListener {
                    PopupMenu(this@MainActivity, drop).apply {
                        categories.forEachIndexed { i, category -> menu.add(0, i, i, category) }
                        setOnMenuItemClickListener { mi ->
                            saveCategory(item, categories[mi.itemId])
                            true
                        }
                        show()
                    }
                }
                row.addView(drop, LinearLayout.LayoutParams(dp(140), dp(44)))

                row.setOnLongClickListener {
                    lightDialogBuilder()
                        .setTitle("Delete Product Master entry?")
                        .setMessage("Delete ${item.productName} (${item.code})? This only removes the saved product mapping.")
                        .setNegativeButton("Cancel", null)
                        .setPositiveButton("Delete") { _, _ ->
                            items.removeAll {
                                it.code.equals(item.code, true) &&
                                    normalizeProductName(it.productName) == normalizeProductName(item.productName)
                            }
                            saveProductMappings(items)
                            rebuildRows()
                            adapter.notifyDataSetChanged()
                            refreshInfo()
                            Toast.makeText(this@MainActivity, "Product mapping deleted", Toast.LENGTH_SHORT).show()
                        }
                        .show()
                    true
                }
                return row
            }
        }
        listView.adapter = adapter
        refreshInfo()

        val add = Button(this).apply {
            text = "+ Add Product"
            setAllCaps(false)
        }
        val close = Button(this).apply {
            text = "Close"
            setAllCaps(false)
        }
        val actions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        actions.addView(add, LinearLayout.LayoutParams(0, dp(48), 1f))
        actions.addView(close, LinearLayout.LayoutParams(0, dp(48), 1f))
        box.addView(actions)

        val dialog = lightDialogBuilder()
            .setTitle("Product Master • ${items.size} products")
            .setView(box)
            .create()
        add.setOnClickListener { showProductMappingEditor(null, items, adapter) }
        close.setOnClickListener { dialog.dismiss() }
        dialog.show()
    }

    private fun showMappingPreview() {
        if (detailUri == null) {
            lightDialogBuilder().setTitle("Product Mapping")
                .setMessage("Please select the Sales Detail file first. This screen shows only products actually present in the uploaded file.")
                .setPositiveButton("Close", null).show()
            return
        }

        data class ProductItem(val code: String, val productName: String, var category: String, var root: String, var mapped: Boolean)
        val items = mutableListOf<ProductItem>()
        val rows = mutableListOf<Any>()
        val categories = loadCategories().toMutableList().apply { if (!contains("NON-MERCHANDISE")) add("NON-MERCHANDISE") }
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(10), dp(4), dp(10), 0) }
        val info = TextView(this).apply { text = "Reading current Details file…"; textSize = 12f; setTextColor(0xFF667085.toInt()); setPadding(dp(8), dp(2), dp(8), dp(8)) }
        box.addView(info)
        val listView = ListView(this).apply { divider = null; dividerHeight = 0; isFastScrollEnabled = true }
        box.addView(listView, LinearLayout.LayoutParams(-1, dp(520)))
        val dialog = lightDialogBuilder().setTitle("Product Mapping • Current File").setView(box).setPositiveButton("Close", null).create()
        lateinit var adapter: BaseAdapter
        fun rebuildRows() {
            rows.clear()
            items.groupBy { it.category.ifBlank { "UNMAPPED" } }.toSortedMap(String.CASE_INSENSITIVE_ORDER).forEach { (cat, list) ->
                rows.add(cat)
                rows.addAll(list.sortedWith(compareBy({ it.code }, { normalizeProductName(it.productName) })))
            }
        }
        fun saveItem(item: ProductItem, newCategory: String) {
            val catalogue = loadCatalogue().associateBy { it.code.uppercase(Locale.ROOT) }
            val base = catalogue[item.code.uppercase(Locale.ROOT)]
            val root = when {
                newCategory.equals("NON-MERCHANDISE", true) -> "NONE"
                base?.root.equals("CORE", true) -> "CORE"
                base?.root.equals("NONE", true) -> "NONE"
                else -> "FASHION"
            }
            val mappings = loadCurrentProductMappings()
            val idx = mappings.indexOfFirst { it.code.equals(item.code, true) && normalizeProductName(it.productName) == normalizeProductName(item.productName) }
            val pm = ProductMapping(item.code.uppercase(Locale.ROOT), item.productName, newCategory, root)
            if (idx >= 0) mappings[idx] = pm else mappings += pm
            saveCurrentProductMappings(mappings)
            // Mapping learned/changed from the current Details file is retained permanently.
            val master = loadProductMappings().toMutableList()
            val masterIndex = master.indexOfFirst {
                it.code.equals(item.code, true) && normalizeProductName(it.productName) == normalizeProductName(item.productName)
            }
            if (masterIndex >= 0) master[masterIndex] = pm else master += pm
            saveProductMappings(master)
            item.category = newCategory; item.root = root; item.mapped = true
            rebuildRows(); adapter.notifyDataSetChanged()
            val unmapped = items.count { !it.mapped }
            info.text = if (unmapped == 0) "All products in the current file are mapped • changes save instantly" else "⚠ $unmapped product(s) still need mapping"
        }
        adapter = object : BaseAdapter() {
            override fun getCount() = rows.size
            override fun getItem(position: Int) = rows[position]
            override fun getItemId(position: Int) = position.toLong()
            override fun getViewTypeCount() = 2
            override fun getItemViewType(position: Int) = if (rows[position] is String) 0 else 1
            override fun getView(position: Int, convertView: View?, parent: android.view.ViewGroup): View {
                val data = rows[position]
                if (data is String) {
                    val tv = (convertView as? TextView) ?: TextView(this@MainActivity)
                    val count = items.count { it.category.equals(data, true) }
                    tv.text = "${data.uppercase(Locale.ROOT)}   •   $count product${if (count == 1) "" else "s"}"
                    tv.textSize = 13f; tv.setTypeface(null, android.graphics.Typeface.BOLD); tv.setTextColor(0xFF0B2545.toInt()); tv.setBackgroundColor(0xFFE3EAF6.toInt()); tv.setPadding(dp(12), dp(10), dp(12), dp(10)); return tv
                }
                val item = data as ProductItem
                val row = (convertView as? LinearLayout) ?: LinearLayout(this@MainActivity).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
                row.removeAllViews(); row.setPadding(dp(10), dp(5), dp(5), dp(5))
                val detailsLayout = LinearLayout(this@MainActivity).apply { orientation = LinearLayout.VERTICAL }
                detailsLayout.addView(TextView(this@MainActivity).apply { text = item.productName; textSize = 13f; setTypeface(null, android.graphics.Typeface.BOLD); setTextColor(0xFF344054.toInt()); maxLines = 2; ellipsize = android.text.TextUtils.TruncateAt.END })
                detailsLayout.addView(TextView(this@MainActivity).apply { text = item.code + if (!item.mapped) "  •  ⚠ NEW" else ""; textSize = 10f; setTextColor(if (item.mapped) 0xFF667085.toInt() else 0xFFB42318.toInt()) })
                row.addView(detailsLayout, LinearLayout.LayoutParams(0, dp(56), 1f))
                val drop = TextView(this@MainActivity).apply {
                    text = "${item.category.ifBlank { "Select Category" }}  ▼"; textSize = 10.5f; gravity = Gravity.CENTER; setTextColor(0xFF344054.toInt()); isClickable = true; isFocusable = true
                    background = android.graphics.drawable.GradientDrawable().apply { setColor(0xFFF1F5FB.toInt()); cornerRadius = dp(10).toFloat(); setStroke(dp(1), 0xFFC3D0E6.toInt()) }
                }
                drop.setOnClickListener {
                    PopupMenu(this@MainActivity, drop).apply {
                        categories.forEachIndexed { i, c -> menu.add(0, i, i, c) }
                        setOnMenuItemClickListener { mi -> saveItem(item, categories[mi.itemId]); true }
                        show()
                    }
                }
                row.addView(drop, LinearLayout.LayoutParams(dp(132), dp(44)))
                return row
            }
        }
        listView.adapter = adapter
        dialog.show()
        lifecycleScope.launch {
            try {
                val catalogue = loadCatalogue().associateBy { it.code.uppercase(Locale.ROOT) }
                val saved = loadCurrentProductMappings().associateBy { "${it.code.uppercase(Locale.ROOT)}|${normalizeProductName(it.productName)}" }
                val unique = linkedMapOf<String, Pair<String, String>>()
                withContext(Dispatchers.IO) {
                    streamCsv(detailUri!!) { headers, values, _ ->
                        val code = resolveDetailsCode(headers, values, catalogue.keys).trim().uppercase(Locale.ROOT)
                        val name = field(values, fieldIndex(headers, "ProductName")).trim()
                        if (code.isNotBlank() && name.isNotBlank()) unique["$code|${normalizeProductName(name)}"] = code to name
                    }
                }
                items.clear()
                unique.values.forEach { (code, name) ->
                    val pm = saved["$code|${normalizeProductName(name)}"]
                    val root = catalogue[code]?.root ?: ""
                    items += ProductItem(code, name, pm?.category ?: "", if (pm != null) pm.root else root, pm != null)
                }
                rebuildRows(); adapter.notifyDataSetChanged()
                val newCount = items.count { !it.mapped }
                info.text = if (newCount == 0) "${items.size} product mappings loaded from current file • changes save instantly" else "⚠ $newCount new/unmapped product(s) found in current file"
            } catch (e: Exception) { info.text = "Could not read current Details file: ${e.message ?: "Unknown error"}" }
        }
    }

    private fun showMappingEditor(existingCode: String, existing: Mapping?) {
        val code = EditText(this).apply { hint = "ProductGroupCode / Style Code"; setText(existingCode); isSingleLine = true; isEnabled = existing == null }
        val roots = loadRoots().toTypedArray()
        val root = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, roots)
            setSelection(roots.indexOfFirst { it.equals(existing?.root, true) }.coerceAtLeast(0))
        }
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(8), dp(20), 0) }
        box.addView(TextView(this).apply { text = "Catalogue stores only the root. Category is assigned per Product Name in Product Mapping."; textSize = 12f; setTextColor(0xFF667085.toInt()); setPadding(0,0,0,dp(8)) })
        box.addView(code); box.addView(root)
        lightDialogBuilder().setTitle(if (existing == null) "Add Catalogue Code" else "Edit Catalogue Root")
            .setView(box).setNegativeButton("Cancel", null).setPositiveButton("Save") { _, _ ->
                val c = code.text.toString().trim().uppercase(Locale.ROOT)
                if (c.isBlank()) { Toast.makeText(this@MainActivity, "Enter code", Toast.LENGTH_SHORT).show(); return@setPositiveButton }
                val all = loadCatalogue(); val idx = all.indexOfFirst { it.code.equals(c, true) }
                val m = Mapping(c, "", roots[root.selectedItemPosition])
                if (idx >= 0) all[idx] = m else all += m
                saveCatalogue(all)
                val products = loadProductMappings().map { pm -> if (pm.code.equals(c, true)) pm.copy(root = if (pm.category.equals("NON-MERCHANDISE", true)) "NONE" else m.root) else pm }
                saveProductMappings(products)
                detailUri?.let { checkMasterIssues(it) }
                Toast.makeText(this@MainActivity, "$c saved", Toast.LENGTH_SHORT).show()
            }.show()
    }

    // ---------------- Processing / Sale Thru Report ----------------

    private data class ReportRow(
        val category: String,
        val root: String,
        val soldQty: Double,
        val saleValue: Double,
        val sohQty: Double,
        val sohValue: Double,
        val plusSoldQty: Double,
        val plusSaleValue: Double,
        val plusSohQty: Double,
        val plusSohValue: Double
    )

    private data class ProcessingResult(
        val detailRows: Int,
        val sohRows: Int,
        val missingCodes: List<String>,
        val missingSizes: List<String>,
        val reportRows: List<ReportRow>,
        val firstBillDate: LocalDate?,
        val lastBillDate: LocalDate?
    )

    private fun setProcessing(active: Boolean, message: String = "") {
        findViewById<View>(R.id.processingPanel).visibility = if (active) View.VISIBLE else View.GONE
        progressBar.visibility = if (active) View.VISIBLE else View.GONE
        progressBar.isIndeterminate = true
        processingStatus.visibility = if (active) View.VISIBLE else View.GONE
        processingStatus.text = message
    }

    private fun updateProcessing(message: String) {
        runOnUiThread {
            if (!isFinishing && !isDestroyed) processingStatus.text = message
        }
    }

    /**
     * Finds the real CSV header. Some Go Colors exports contain report metadata
     * lines before the header. The old reader assumed line 1 was the header.
     */
    /**
     * Go Colors exports can contain report-title/metadata lines before the real
     * CSV header. We deliberately inspect ONLY the first 10 physical lines.
     * This avoids scanning the entire file just to discover the header.
     *
     * Details header is identified by the presence of the core fields used by
     * the report: Size + Quantity + Amount, with ArticleNumber/ProductGroupCode
     * also accepted as supporting fields.
     *
     * SOH header is identified by Stock + ArticleNumber/ProductGroupCode, with
     * Stockvalueatsaleprice as the value field when available.
     */
    private fun readCsvHeader(br: BufferedReader): List<String> {
        // Go Colors CSV exports can contain report-title/metadata lines before
        // the real CSV header. Do not assume a fixed header line number.
        // Read line-by-line until the first row that actually looks like the
        // required Details or SOH header. This is streaming and does not load
        // the file into memory.
        var lineNumber = 0

        while (true) {
            val line = br.readLine() ?: break
            lineNumber++
            if (line.isBlank()) continue

            val headers = splitCsv(line)
                .map { it.trim().trim('"').trim('\uFEFF').trim() }

            fun normalize(name: String): String = name
                .trim()
                .trim('"')
                .trim('\uFEFF')
                .lowercase(Locale.ROOT)
                .filter { it.isLetterOrDigit() }

            val normalized = headers.map(::normalize).toSet()

            val hasSize = "size" in normalized
            val hasQuantity = "quantity" in normalized || "qty" in normalized
            val hasAmount = "amount" in normalized || "saleamount" in normalized
            val hasStock = "stock" in normalized || "stockqty" in normalized
            val hasArticle = "articlenumber" in normalized ||
                "article" in normalized ||
                "alternateproductcode" in normalized
            val hasCategory = "categorycode" in normalized ||
                "productgroupcode" in normalized ||
                "productgroup" in normalized
            val hasStockValue = normalized.any {
                it == "stockvalueatsaleprice" ||
                    it == "stockvalueatsalemrp" ||
                    it == "stockvalue" ||
                    it == "stockvalueatsale"
            }

            val looksLikeDetails = hasSize && hasQuantity && hasAmount && (hasArticle || hasCategory)
            val looksLikeSoh = hasStock && (hasArticle || hasCategory) && (hasStockValue || hasSize)

            if (looksLikeDetails || looksLikeSoh) {
                updateProcessing("Header found at line $lineNumber…")
                return headers
            }
        }

        throw IllegalArgumentException(
            "CSV header not found. The file was read until EOF, but no valid Details/SOH header was detected."
        )
    }

    private fun streamCsv(
        uri: Uri,
        onRow: (headers: List<String>, values: List<String>, rowNumber: Int) -> Unit
    ): Int {
        // Some Excel exports are saved with a .csv filename even though the
        // actual file is XLSX (ZIP container). Detect the real file format from
        // its magic bytes instead of trusting the filename/extension.
        val probe = contentResolver.openInputStream(uri)
            ?: throw IllegalArgumentException("Unable to open selected file")
        val isXlsx = probe.use { input ->
            val b = ByteArray(4)
            val n = input.read(b)
            n == 4 && b[0] == 'P'.code.toByte() && b[1] == 'K'.code.toByte() &&
                b[2] == 3.toByte() && b[3] == 4.toByte()
        }

        return if (isXlsx) {
            streamXlsx(uri, onRow)
        } else {
            streamPlainCsv(uri, onRow)
        }
    }

    private fun streamPlainCsv(
        uri: Uri,
        onRow: (headers: List<String>, values: List<String>, rowNumber: Int) -> Unit
    ): Int {
        val input = contentResolver.openInputStream(uri)
            ?: throw IllegalArgumentException("Unable to open selected CSV")
        input.use {
            BufferedReader(InputStreamReader(it, Charsets.UTF_8), 64 * 1024).use { br ->
                val headers = readCsvHeader(br)
                var rowNumber = 0
                while (true) {
                    val line = br.readLine() ?: break
                    if (line.isBlank()) continue
                    rowNumber++
                    onRow(headers, splitCsv(line), rowNumber)
                }
                return rowNumber
            }
        }
    }

    /**
     * Reads the first worksheet from an XLSX file. This intentionally uses the
     * Android platform XML parser and ZipInputStream, so no extra Excel library
     * is required and the app can also handle a file whose extension says .csv
     * but whose contents are actually XLSX.
     */
    private fun streamXlsx(
        uri: Uri,
        onRow: (headers: List<String>, values: List<String>, rowNumber: Int) -> Unit
    ): Int {
        val sharedStrings = readXlsxSharedStrings(uri)
        val sheetEntry = findFirstWorksheet(uri)
            ?: throw IllegalArgumentException("No worksheet found in Excel file")

        val input = contentResolver.openInputStream(uri)
            ?: throw IllegalArgumentException("Unable to open Excel file")
        input.use { raw ->
            ZipInputStream(raw.buffered(64 * 1024)).use { zip ->
                while (true) {
                    val entry = zip.nextEntry ?: break
                    if (entry.name != sheetEntry) continue

                    val parser = Xml.newPullParser().apply {
                        setInput(zip, null)
                    }
                    var header: List<String>? = null
                    var rowNumber = 0
                    var physicalRow = 0

                    while (true) {
                        val event = parser.next()
                        if (event == XmlPullParser.END_DOCUMENT) break

                        if (event == XmlPullParser.START_TAG && parser.name == "row") {
                            physicalRow++
                            val row = readXlsxRow(parser, sharedStrings)
                            if (row.isEmpty()) continue

                            if (header == null) {
                                if (looksLikeReportHeader(row)) {
                                    header = row.map { it.trim().trim('\uFEFF').trim() }
                                    updateProcessing("Excel header found at row $physicalRow…")
                                }
                            } else {
                                rowNumber++
                                onRow(header!!, row, rowNumber)
                            }
                        }
                    }

                    if (header == null) {
                        throw IllegalArgumentException(
                            "Excel header not found. The selected workbook does not contain a valid Details/SOH header."
                        )
                    }
                    return rowNumber
                }
            }
        }
        throw IllegalArgumentException("First worksheet could not be read from Excel file")
    }

    private fun looksLikeReportHeader(headers: List<String>): Boolean {
        fun normalize(name: String): String = name
            .trim().trim('"').trim('\uFEFF')
            .lowercase(Locale.ROOT)
            .filter { it.isLetterOrDigit() }

        val normalized = headers.map(::normalize).toSet()
        val hasSize = "size" in normalized
        val hasQuantity = "quantity" in normalized || "qty" in normalized
        val hasAmount = "amount" in normalized || "saleamount" in normalized
        val hasStock = "stock" in normalized || "stockqty" in normalized
        val hasArticle = "articlenumber" in normalized || "article" in normalized ||
            "alternateproductcode" in normalized
        val hasCategory = "categorycode" in normalized || "productgroupcode" in normalized ||
            "productgroup" in normalized
        val hasStockValue = normalized.any {
            it == "stockvalueatsaleprice" || it == "stockvalueatsalemrp" ||
                it == "stockvalue" || it == "stockvalueatsale"
        }
        return (hasSize && hasQuantity && hasAmount && (hasArticle || hasCategory)) ||
            (hasStock && (hasArticle || hasCategory) && (hasStockValue || hasSize))
    }

    private fun findFirstWorksheet(uri: Uri): String? {
        val input = contentResolver.openInputStream(uri) ?: return null
        input.use { raw ->
            ZipInputStream(raw.buffered(64 * 1024)).use { zip ->
                while (true) {
                    val entry = zip.nextEntry ?: break
                    val n = entry.name
                    if (!entry.isDirectory && n.startsWith("xl/worksheets/") && n.endsWith(".xml")) {
                        return n
                    }
                }
            }
        }
        return null
    }

    private fun readXlsxSharedStrings(uri: Uri): List<String> {
        val result = ArrayList<String>()
        val input = contentResolver.openInputStream(uri) ?: return result
        input.use { raw ->
            ZipInputStream(raw.buffered(64 * 1024)).use { zip ->
                while (true) {
                    val entry = zip.nextEntry ?: break
                    if (entry.name != "xl/sharedStrings.xml") continue

                    val parser = Xml.newPullParser().apply { setInput(zip, null) }
                    val text = StringBuilder()
                    var inSi = false
                    while (true) {
                        val event = parser.next()
                        if (event == XmlPullParser.END_DOCUMENT) break
                        when (event) {
                            XmlPullParser.START_TAG -> if (parser.name == "si") {
                                inSi = true
                                text.setLength(0)
                            }
                            XmlPullParser.TEXT -> if (inSi) text.append(parser.text)
                            XmlPullParser.END_TAG -> if (parser.name == "si" && inSi) {
                                result.add(text.toString())
                                inSi = false
                            }
                        }
                    }
                    break
                }
            }
        }
        return result
    }

    private fun readXlsxRow(parser: XmlPullParser, sharedStrings: List<String>): List<String> {
        val values = ArrayList<String>()
        var currentColumn = 0
        var cellType: String? = null
        var cellValue = StringBuilder()
        var cellRef: String? = null
        var inCell = false
        var inInlineText = false

        while (true) {
            val event = parser.next()
            if (event == XmlPullParser.END_DOCUMENT) break
            if (event == XmlPullParser.END_TAG && parser.name == "row") break

            when (event) {
                XmlPullParser.START_TAG -> when (parser.name) {
                    "c" -> {
                        inCell = true
                        cellValue.setLength(0)
                        cellType = parser.getAttributeValue(null, "t")
                        cellRef = parser.getAttributeValue(null, "r")
                        val refColumn = cellRef?.let { xlsxColumnIndex(it) } ?: currentColumn
                        while (values.size < refColumn) values.add("")
                        currentColumn = refColumn
                    }
                    "v", "t" -> if (inCell) {
                        inInlineText = true
                    }
                }
                XmlPullParser.TEXT -> if (inCell && inInlineText) cellValue.append(parser.text)
                XmlPullParser.END_TAG -> when (parser.name) {
                    "v" -> if (inCell) inInlineText = false
                    "t" -> if (inCell) inInlineText = false
                    "c" -> if (inCell) {
                        val raw = cellValue.toString()
                        val value = when (cellType) {
                            "s" -> raw.toIntOrNull()?.let { sharedStrings.getOrNull(it) ?: raw } ?: raw
                            "inlineStr", "str" -> raw
                            else -> raw
                        }
                        while (values.size <= currentColumn) values.add("")
                        values[currentColumn] = value
                        currentColumn++
                        inCell = false
                        cellType = null
                        cellRef = null
                    }
                }
            }
        }
        return values
    }

    private fun xlsxColumnIndex(cellRef: String): Int {
        var index = 0
        for (ch in cellRef) {
            if (!ch.isLetter()) break
            index = index * 26 + (ch.uppercaseChar() - 'A' + 1)
        }
        return (index - 1).coerceAtLeast(0)
    }

    private fun resolveDetailsCode(
        headers: List<String>,
        values: List<String>,
        catalogueCodes: Set<String>
    ): String {
        val articleNumber = field(values, fieldIndex(headers, "ArticleNumber")).uppercase(Locale.ROOT)
        val categoryCode = field(values, fieldIndex(headers, "CategoryCode")).uppercase(Locale.ROOT)
        val productGroupCode = field(values, fieldIndex(headers, "ProductGroupCode")).uppercase(Locale.ROOT)

        // In the supplied Go Colors exports, ArticleNumber and CategoryCode are
        // the same style code (for example LL07, LPZ8, EK72). ProductGroupCode
        // is a numeric division field (for example 2/3), so it is not the
        // catalogue key for Sale Thru.
        return when {
            articleNumber.isNotBlank() -> articleNumber
            categoryCode.isNotBlank() -> categoryCode
            productGroupCode in catalogueCodes -> productGroupCode
            else -> productGroupCode
        }
    }

    private suspend fun processFiles(detail: Uri, soh: Uri): ProcessingResult = withContext(Dispatchers.IO) {
        val catalogue = loadCatalogue().associateBy { it.code.uppercase(Locale.ROOT) }
        val overrides = loadReportProductMappings().groupBy { it.code.uppercase(Locale.ROOT) }
        val catalogueCodes = catalogue.keys
        val sizeTypes = loadSizeMaster().associate { it.size.uppercase(Locale.ROOT) to it.type }
        val missingCodes = mutableSetOf<String>()
        val missingSizes = mutableSetOf<String>()
        val articleToCode = HashMap<String, String>()
        val totals = HashMap<String, DoubleArray>()
        val categoryRoots = HashMap<String, String>()
        val detailCodeCategories = HashMap<String, MutableSet<String>>()

        var detailRows = 0
        var firstBillDate: LocalDate? = null
        var lastBillDate: LocalDate? = null
        updateProcessing("Reading Details…")
        streamCsv(detail) { headers, values, rowNumber ->
            val code = resolveDetailsCode(headers, values, catalogueCodes).trim().uppercase(Locale.ROOT)
            val productName = field(values, fieldIndex(headers, "ProductName")).trim()
            val billDate = parseBillDate(field(values, fieldIndex(headers, "BillDate")))
            if (billDate != null) {
                firstBillDate = if (firstBillDate == null || billDate.isBefore(firstBillDate)) billDate else firstBillDate
                lastBillDate = if (lastBillDate == null || billDate.isAfter(lastBillDate)) billDate else lastBillDate
            }
            val size = field(values, fieldIndex(headers, "Size")).uppercase(Locale.ROOT)
            val qty = number(field(values, fieldIndex(headers, "Quantity")))
            val amount = number(field(values, fieldIndex(headers, "Amount")))
            val article = field(values, fieldIndex(headers, "ArticleNumber")).uppercase(Locale.ROOT)

            if (code.isNotBlank()) {
                if (code !in catalogueCodes) missingCodes += code
                if (article.isNotBlank()) articleToCode[article] = code
                val mapping = resolveMapping(code, productName, catalogue, overrides)
                when {
                    mapping == null -> {
                        // Product-level mapping is now the category key. Keep unresolved rows
                        // visible as UNMAPPED rather than silently assigning the old code category.
                        val a = totals.getOrPut("UNMAPPED") { DoubleArray(8) }
                        a[0] += qty; a[1] += amount
                        if (sizeTypes[size] == "Plus Size") { a[4] += qty; a[5] += amount }
                    }
                    mapping.root.equals("NONE", true) || mapping.category.equals("NON-MERCHANDISE", true) -> {
                        // Intentionally excluded from every report total.
                    }
                    else -> {
                        val category = mapping.category.trim().ifBlank { "UNMAPPED" }
                        val key = category
                        categoryRoots[key] = mapping.root.uppercase(Locale.ROOT)
                        detailCodeCategories.getOrPut(code) { linkedSetOf() }.add(category)
                        val a = totals.getOrPut(key) { DoubleArray(8) }
                        a[0] += qty; a[1] += amount
                        if (sizeTypes[size] == "Plus Size") { a[4] += qty; a[5] += amount }
                    }
                }
            }
            if (size.isNotBlank() && sizeTypes[size] == null) missingSizes += size
            detailRows = rowNumber
            if (rowNumber % 2500 == 0) updateProcessing("Reading Details… $rowNumber rows")
        }

        var sohRows = 0
        updateProcessing("Reading SOH / Stock Value…")
        streamCsv(soh) { headers, values, rowNumber ->
            val article = field(values, fieldIndex(headers, "ArticleNumber", "ProductCode")).uppercase(Locale.ROOT)
            val productName = field(values, fieldIndex(headers, "ProductName", "ProductFullName")).trim()
            val size = field(values, fieldIndex(headers, "Size")).uppercase(Locale.ROOT)
            val stockQty = number(field(values, fieldIndex(headers, "Stock")))
            val stockValue = number(field(values, fieldIndex(headers, "Stockvalueatsaleprice", "StockValueAtSalePrice")))
            val code = if (article.isNotBlank()) article else field(values, fieldIndex(headers, "CategoryCode")).uppercase(Locale.ROOT)
            if (code.isNotBlank()) {
                if (code !in catalogueCodes) missingCodes += code
                val mappingCandidates = overrides[code].orEmpty()
                val mapping = if (productName.isNotBlank()) resolveMapping(code, productName, catalogue, overrides)
                else if (mappingCandidates.size == 1) resolveMapping(code, mappingCandidates.first().productName, catalogue, overrides)
                else if (catalogue[code]?.root.equals("NONE", true)) Mapping(code, "NON-MERCHANDISE", "NONE") else null
                when {
                    mapping == null -> {
                        val a = totals.getOrPut("UNMAPPED") { DoubleArray(8) }
                        a[2] += stockQty; a[3] += stockValue
                        if (sizeTypes[size] == "Plus Size") { a[6] += stockQty; a[7] += stockValue }
                    }
                    mapping.root.equals("NONE", true) || mapping.category.equals("NON-MERCHANDISE", true) -> {
                        // Excluded from SOH as well.
                    }
                    else -> {
                        val category = mapping.category.trim().ifBlank { "UNMAPPED" }
                        categoryRoots[category] = mapping.root.uppercase(Locale.ROOT)
                        val a = totals.getOrPut(category) { DoubleArray(8) }
                        a[2] += stockQty; a[3] += stockValue
                        if (sizeTypes[size] == "Plus Size") { a[6] += stockQty; a[7] += stockValue }
                    }
                }
            }
            if (size.isNotBlank() && sizeTypes[size] == null) missingSizes += size
            sohRows = rowNumber
            if (rowNumber % 5000 == 0) updateProcessing("Reading SOH… $rowNumber rows")
        }

        val reportRows = totals.entries
            .filter { (_, v) -> v.any { kotlin.math.abs(it) > 0.000001 } }
            .sortedWith(compareBy({ if (it.key.equals("UNMAPPED", true)) 1 else 0 }, { it.key.uppercase(Locale.ROOT) }))
            .map { (category, v) ->
                ReportRow(
                    category = category,
                    root = categoryRoots[category] ?: "UNMAPPED",
                    soldQty = v[0], saleValue = v[1], sohQty = v[2], sohValue = v[3],
                    plusSoldQty = v[4], plusSaleValue = v[5], plusSohQty = v[6], plusSohValue = v[7]
                )
            }

        ProcessingResult(detailRows = detailRows, sohRows = sohRows, missingCodes = missingCodes.sorted(), missingSizes = missingSizes.sorted(), reportRows = reportRows, firstBillDate = firstBillDate, lastBillDate = lastBillDate)
    }

    private fun parseBillDate(raw: String): LocalDate? {
        val value = raw.trim().trim('"')
        if (value.isBlank()) return null
        val formatters = listOf(
            DateTimeFormatter.ofPattern("d/M/uuuu", Locale.ENGLISH),
            DateTimeFormatter.ofPattern("d/MM/uuuu", Locale.ENGLISH),
            DateTimeFormatter.ofPattern("dd/MM/uuuu", Locale.ENGLISH),
            DateTimeFormatter.ofPattern("d-M-uuuu", Locale.ENGLISH),
            DateTimeFormatter.ofPattern("dd-MMM-uuuu", Locale.ENGLISH),
            DateTimeFormatter.ofPattern("d/MMM/uuuu", Locale.ENGLISH)
        )
        for (formatter in formatters) {
            try { return LocalDate.parse(value, formatter) } catch (_: DateTimeParseException) { }
        }
        return null
    }

    private fun formatDate(date: LocalDate?): String = date?.format(DateTimeFormatter.ofPattern("dd MMM yyyy", Locale.ENGLISH)) ?: "Unknown"

    private fun number(raw: String): Double =
        raw.replace(",", "").replace("₹", "").trim().toDoubleOrNull() ?: 0.0

    private fun money(value: Double): String =
        "₹" + String.format(Locale.US, "%,.0f", value)

    private fun qty(value: Double): String =
        if (kotlin.math.abs(value - value.toLong()) < 0.000001) value.toLong().toString()
        else String.format(Locale.US, "%.2f", value)

    private fun saleThru(sold: Double, soh: Double): Double =
        if (sold + soh <= 0.0) 0.0 else sold / (sold + soh) * 100.0

    private fun pct(value: Double): String = String.format(Locale.US, "%.2f%%", value)

    private fun generateMohReport() {
        val detail = detailUri
        val soh = sohUri
        if (detail == null || soh == null) {
            Toast.makeText(this@MainActivity, "Please select both Sales Detail and SOH files first", Toast.LENGTH_SHORT).show()
            return
        }
        mohReportButton.isEnabled = false
        generate.isEnabled = false
        setProcessing(true, "Calculating MOH…")
        lifecycleScope.launch {
            try {
                val processed = processFiles(detail, soh)
                updateMasterAlert(processed.missingCodes, processed.missingSizes)
                showMohReport(processed)
                result.text = buildString {
                    append("MOH REPORT READY\n\n")
                    append("Sales period: ${formatDate(processed.firstBillDate)} → ${formatDate(processed.lastBillDate)}\n")
                    append("Categories: ${processed.reportRows.size}\n")
                    if (processed.firstBillDate == null || processed.lastBillDate == null) append("⚠ Billing dates could not be detected from Details.\n")
                }
                Toast.makeText(this@MainActivity, "MOH report generated", Toast.LENGTH_SHORT).show()
            } catch (e: CancellationException) { throw e }
            catch (e: Exception) {
                result.text = "MOH report failed.\n\n${e.javaClass.simpleName}: ${e.message ?: "Unknown error"}"
                Toast.makeText(this@MainActivity, "MOH report failed", Toast.LENGTH_LONG).show()
            } finally {
                setProcessing(false)
                mohReportButton.isEnabled = detailUri != null && sohUri != null
                generate.isEnabled = detailUri != null && sohUri != null
            }
        }
    }

    private fun showMohReport(p: ProcessingResult) {
        val first = p.firstBillDate
        val last = p.lastBillDate
        val days = if (first != null && last != null) (java.time.temporal.ChronoUnit.DAYS.between(first, last) + 1).coerceAtLeast(1) else 0L
        val periodMonths = if (days > 0) (days.toDouble() / 30.0).coerceAtLeast(1.0) else 0.0

        val scroll = HorizontalScrollView(this).apply { setFillViewport(true) }
        val vertical = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(16, 8, 16, 16) }
        vertical.addView(TextView(this).apply {
            text = "MOH • Months on Hand"
            textSize = 18f; setTypeface(null, android.graphics.Typeface.BOLD); setTextColor(0xFF101828.toInt())
        })
        vertical.addView(TextView(this).apply {
            text = if (days > 0) "Sales period: ${formatDate(first)} → ${formatDate(last)} • $days day(s) • ${String.format(Locale.US, "%.2f", periodMonths)} month-equivalent" else "Billing period could not be detected from Details"
            textSize = 12f; setTextColor(0xFF667085.toInt()); setPadding(4, 4, 4, 12)
        })
        vertical.addView(TextView(this).apply {
            text = "MOH = SOH Qty ÷ Average Monthly Sold Qty"
            textSize = 12f; setTextColor(0xFF667085.toInt()); setPadding(4, 0, 4, 12)
        })
        val table = TableLayout(this)
        table.addView(makeTableRow(arrayOf("Category", "Sold Qty", "SOH Qty", "Avg/Month", "MOH"), true))
        var totalSold = 0.0; var totalSoh = 0.0
        p.reportRows.forEach { r ->
            totalSold += r.soldQty; totalSoh += r.sohQty
            val avgMonthly = if (periodMonths > 0) r.soldQty / periodMonths else 0.0
            val moh = if (avgMonthly > 0) r.sohQty / avgMonthly else 0.0
            table.addView(makeTableRow(arrayOf(r.category, qty(r.soldQty), qty(r.sohQty), qty(avgMonthly), if (avgMonthly > 0) String.format(Locale.US, "%.2f", moh) else "-"), false))
        }
        val totalAvg = if (periodMonths > 0) totalSold / periodMonths else 0.0
        val totalMoh = if (totalAvg > 0) totalSoh / totalAvg else 0.0
        table.addView(makeTableRow(arrayOf("TOTAL", qty(totalSold), qty(totalSoh), qty(totalAvg), if (totalAvg > 0) String.format(Locale.US, "%.2f", totalMoh) else "-"), true))
        vertical.addView(table)
        scroll.addView(vertical)
        lightDialogBuilder().setTitle("MOH Report").setView(scroll)
            .setNeutralButton("EXPORT AS CSV") { _, _ -> exportCsv("MOH_Report", buildMohCsv(p)) }
            .setPositiveButton("Close", null).show()
    }

    private fun generateReport() {
        val detail = detailUri
        val soh = sohUri
        if (detail == null || soh == null) {
            Toast.makeText(this@MainActivity, "Please select both files", Toast.LENGTH_SHORT).show()
            return
        }

        generate.isEnabled = false
        setProcessing(true, "Starting Sale Thru calculation…")
        result.text = "Reading Details and SOH…"

        lifecycleScope.launch {
            try {
                val processed = processFiles(detail, soh)
                updateMasterAlert(processed.missingCodes, processed.missingSizes)

                result.text = buildSummaryText(processed)
                showSaleThruReport(processed)

                Toast.makeText(this@MainActivity, "Sale Thru Report generated", Toast.LENGTH_SHORT).show()
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                result.text = "Report generation failed.\n\n${e.javaClass.simpleName}: ${e.message ?: "Unknown error"}"
                Toast.makeText(this@MainActivity, "Report generation failed", Toast.LENGTH_LONG).show()
            } finally {
                setProcessing(false)
                generate.isEnabled = detailUri != null && sohUri != null
            }
        }
    }

    private fun buildSummaryText(p: ProcessingResult): String = buildString {
        append("SALE THRU REPORT READY\n\n")
        append("Details rows: ${p.detailRows}\n")
        append("SOH rows: ${p.sohRows}\n")
        append("Categories: ${p.reportRows.size}\n")
        append("Sales period: ${formatDate(p.firstBillDate)} → ${formatDate(p.lastBillDate)}\n")
        append("Catalogue mapped: ${loadCatalogue().size}\n")
        if (p.missingCodes.isNotEmpty()) append("⚠ Missing catalogue codes: ${p.missingCodes.size}\n")
        if (p.missingSizes.isNotEmpty()) append("⚠ New/unconfirmed sizes: ${p.missingSizes.size}\n")
        append("\nTap Generate again after updating masters if anything is missing.")
    }

    private fun csvEscape(value: String): String =
        "\"" + value.replace("\"", "\"\"") + "\""

    private fun exportCsv(filename: String, content: String) {
        pendingCsvContent = content
        exportCsvLauncher.launch(if (filename.endsWith(".csv", true)) filename else "$filename.csv")
    }

    private fun buildSaleThruCsv(p: ProcessingResult): String = buildString {
        appendLine("Category,Root,Sold Qty,Sale Value,SOH Qty,SOH Value,Plus Sold,Plus Sale,Plus SOH,Sale Thru %")
        var totalSold=0.0; var totalSale=0.0; var totalSoh=0.0; var totalSohValue=0.0; var totalPlusSold=0.0; var totalPlusSale=0.0; var totalPlusSoh=0.0
        p.reportRows.forEach { r ->
            totalSold+=r.soldQty; totalSale+=r.saleValue; totalSoh+=r.sohQty; totalSohValue+=r.sohValue; totalPlusSold+=r.plusSoldQty; totalPlusSale+=r.plusSaleValue; totalPlusSoh+=r.plusSohQty
            appendLine(listOf(r.category,r.root,qty(r.soldQty),r.saleValue.toString(),qty(r.sohQty),r.sohValue.toString(),qty(r.plusSoldQty),r.plusSaleValue.toString(),qty(r.plusSohQty),saleThru(r.soldQty,r.sohQty).toString()).joinToString(",") { csvEscape(it) })
        }
        appendLine(listOf("TOTAL","",qty(totalSold),totalSale.toString(),qty(totalSoh),totalSohValue.toString(),qty(totalPlusSold),totalPlusSale.toString(),qty(totalPlusSoh),saleThru(totalSold,totalSoh).toString()).joinToString(",") { csvEscape(it) })
    }

    private fun buildMohCsv(p: ProcessingResult): String {
        val first=p.firstBillDate; val last=p.lastBillDate
        val days=if(first!=null&&last!=null)(java.time.temporal.ChronoUnit.DAYS.between(first,last)+1).coerceAtLeast(1) else 0L
        val months=if(days>0)(days.toDouble()/30.0).coerceAtLeast(1.0) else 0.0
        return buildString {
            appendLine("Category,Sold Qty,SOH Qty,Average Monthly Sold Qty,MOH")
            var sold=0.0; var soh=0.0
            p.reportRows.forEach { r -> val avg=if(months>0)r.soldQty/months else 0.0; val moh=if(avg>0)r.sohQty/avg else 0.0; sold+=r.soldQty; soh+=r.sohQty; appendLine(listOf(r.category,qty(r.soldQty),qty(r.sohQty),avg.toString(),if(avg>0)moh.toString() else "-").joinToString(",") { csvEscape(it) }) }
            val avg=if(months>0)sold/months else 0.0; val moh=if(avg>0)soh/avg else 0.0
            appendLine(listOf("TOTAL",qty(sold),qty(soh),avg.toString(),if(avg>0)moh.toString() else "-").joinToString(",") { csvEscape(it) })
        }
    }

    private fun showSaleThruReport(p: ProcessingResult) {
        val scroll = HorizontalScrollView(this).apply { setFillViewport(true) }
        val vertical = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(16, 8, 16, 16)
        }

        val title = TextView(this).apply {
            text = "Sale Thru • Category Review"
            textSize = 18f
            setTypeface(null, android.graphics.Typeface.BOLD)
            setTextColor(0xFF101828.toInt())
            setPadding(4, 4, 4, 4)
        }
        vertical.addView(title)

        val note = TextView(this).apply {
            text = "Sale Thru = Sold Qty ÷ (Sold Qty + SOH Qty) × 100"
            textSize = 12f
            setTextColor(0xFF667085.toInt())
            setPadding(4, 0, 4, 12)
        }
        vertical.addView(note)

        val table = TableLayout(this).apply {
            isStretchAllColumns = false
            isShrinkAllColumns = false
        }

        val header = arrayOf(
            "Category", "Sold Qty", "Sale Value", "SOH Qty", "SOH Value",
            "Plus Sold", "Plus Sale", "Plus SOH", "Sale Thru"
        )
        table.addView(makeTableRow(header, true))

        var totalSold = 0.0
        var totalSale = 0.0
        var totalSoh = 0.0
        var totalSohValue = 0.0
        var totalPlusSold = 0.0
        var totalPlusSale = 0.0
        var totalPlusSoh = 0.0
        var totalPlusSohValue = 0.0

        p.reportRows.forEach { r ->
            totalSold += r.soldQty
            totalSale += r.saleValue
            totalSoh += r.sohQty
            totalSohValue += r.sohValue
            totalPlusSold += r.plusSoldQty
            totalPlusSale += r.plusSaleValue
            totalPlusSoh += r.plusSohQty
            totalPlusSohValue += r.plusSohValue

            table.addView(
                makeTableRow(
                    arrayOf(
                        "${r.category}\n${r.root}",
                        qty(r.soldQty),
                        money(r.saleValue),
                        qty(r.sohQty),
                        money(r.sohValue),
                        qty(r.plusSoldQty),
                        money(r.plusSaleValue),
                        qty(r.plusSohQty),
                        pct(saleThru(r.soldQty, r.sohQty))
                    ),
                    false
                )
            )
        }

        table.addView(
            makeTableRow(
                arrayOf(
                    "TOTAL",
                    qty(totalSold),
                    money(totalSale),
                    qty(totalSoh),
                    money(totalSohValue),
                    qty(totalPlusSold),
                    money(totalPlusSale),
                    qty(totalPlusSoh),
                    pct(saleThru(totalSold, totalSoh))
                ),
                true
            )
        )

        vertical.addView(table)
        val verticalScroll = ScrollView(this).apply {
            addView(vertical)
        }
        scroll.addView(verticalScroll)

        lightDialogBuilder()
            .setTitle("Sale Thru Report")
            .setView(scroll)
            .setNeutralButton("EXPORT AS CSV") { _, _ -> exportCsv("Sale_Thru_Report", buildSaleThruCsv(p)) }
            .setPositiveButton("Close", null)
            .show()
    }

    private var tableZebra = 0

    private fun makeTableRow(values: Array<String>, bold: Boolean): TableRow {
        // UI only: header = navy band, TOTAL = tinted band, data rows = zebra stripes.
        val isTotal = bold && values.firstOrNull() == "TOTAL"
        val isHeader = bold && !isTotal
        if (isHeader) tableZebra = 0
        val rowBg = when {
            isHeader -> 0xFF0B2545.toInt()
            isTotal -> 0xFFE3EAF6.toInt()
            tableZebra % 2 == 0 -> 0xFFFFFFFF.toInt()
            else -> 0xFFF3F6FB.toInt()
        }
        if (!bold) tableZebra++
        val row = TableRow(this)
        row.setBackgroundColor(rowBg)
        values.forEachIndexed { index, value ->
            val tv = TextView(this).apply {
                text = value
                textSize = if (bold) 12f else 11.5f
                setTextColor(
                    when {
                        isHeader -> 0xFFFFFFFF.toInt()
                        isTotal -> 0xFF0B2545.toInt()
                        else -> 0xFF1D2939.toInt()
                    }
                )
                setPadding(12, 10, 12, 10)
                if (bold) setTypeface(null, android.graphics.Typeface.BOLD)
                gravity = if (index == 0) Gravity.START else Gravity.END
                minWidth = when (index) {
                    0 -> 170
                    2, 4, 6 -> 125
                    else -> 90
                }
            }
            row.addView(tv)
        }
        return row
    }

    private data class RootSale(
        val sale: Double,
        val qty: Double
    )

    private data class CategorySale(
        val category: String,
        val sale: Double,
        val qty: Double
    )

    private data class RootContributionResult(
        val detailRows: Int,
        val totalSale: Double,
        val totalQty: Double,
        val core: RootSale,
        val fashion: RootSale,
        val unmapped: RootSale,
        val noneArticles: Int,
        val coreCategories: List<CategorySale>,
        val fashionCategories: List<CategorySale>
    )

    private suspend fun processCoreFashionContribution(detail: Uri): RootContributionResult =
        withContext(Dispatchers.IO) {
            val catalogue = loadCatalogue().associateBy { it.code.uppercase(Locale.ROOT) }
            val productOverrides = loadReportProductMappings().groupBy { it.code.uppercase(Locale.ROOT) }
            var coreSale = 0.0
            var coreQty = 0.0
            var fashionSale = 0.0
            var fashionQty = 0.0
            var unmappedSale = 0.0
            var unmappedQty = 0.0
            val coreCategoryMap = linkedMapOf<String, DoubleArray>()
            val fashionCategoryMap = linkedMapOf<String, DoubleArray>()
            val noneArticles = linkedSetOf<String>()
            var rows = 0

            updateProcessing("Reading Details for CORE / FASHION contribution…")

            streamCsv(detail) { headers, values, rowNumber ->
                val rawCode = resolveDetailsCode(headers, values, catalogue.keys)
                val code = rawCode.trim().trim('"', '\'').uppercase(Locale.ROOT)
                val qtyValue = number(field(values, fieldIndex(headers, "Quantity")))
                val saleValue = number(field(values, fieldIndex(headers, "Amount")))
                val productName = field(values, fieldIndex(headers, "ProductName"))
                val mapping = resolveMapping(code, productName, catalogue, productOverrides)
                val root = mapping?.root?.trim()?.uppercase(Locale.ROOT)

                // IMPORTANT: a row can belong to exactly ONE bucket.
                // A mapped CORE/FASHION code is NEVER also UNMAPPED.
                // UNMAPPED means the catalogue has no entry for this exact code.
                when {
                    mapping == null -> {
                        if (code.isNotBlank()) {
                            unmappedQty += qtyValue
                            unmappedSale += saleValue
                        }
                    }
                    root == "NONE" -> {
                        if (code.isNotBlank()) noneArticles += code
                    }
                    root == "CORE" -> {
                        coreQty += qtyValue
                        coreSale += saleValue
                        val category = mapping.category.trim().ifBlank { "CORE" }
                        val bucket = coreCategoryMap.getOrPut(category) { DoubleArray(2) }
                        bucket[0] += saleValue
                        bucket[1] += qtyValue
                    }
                    root == "FASHION" -> {
                        fashionQty += qtyValue
                        fashionSale += saleValue
                        val category = mapping.category.trim().ifBlank { "Uncategorised" }
                        val bucket = fashionCategoryMap.getOrPut(category) { DoubleArray(2) }
                        bucket[0] += saleValue
                        bucket[1] += qtyValue
                    }
                    else -> {
                        // A catalogue entry exists but its Root is invalid/blank.
                        // Treat it as unmapped so it is visible for correction.
                        if (code.isNotBlank()) {
                            unmappedQty += qtyValue
                            unmappedSale += saleValue
                        }
                    }
                }

                rows = rowNumber
                if (rowNumber % 2500 == 0) {
                    updateProcessing("Reading Details… $rowNumber rows")
                }
            }

            // Build the report total from mutually exclusive buckets.
            // CORE + FASHION + UNMAPPED are the only included buckets.
            // NONE is intentionally excluded. This makes double-counting impossible.
            val includedTotalSale = coreSale + fashionSale + unmappedSale
            val includedTotalQty = coreQty + fashionQty + unmappedQty

            RootContributionResult(
                detailRows = rows,
                totalSale = includedTotalSale,
                totalQty = includedTotalQty,
                core = RootSale(coreSale, coreQty),
                fashion = RootSale(fashionSale, fashionQty),
                unmapped = RootSale(unmappedSale, unmappedQty),
                noneArticles = noneArticles.size,
                coreCategories = coreCategoryMap.map { CategorySale(it.key, it.value[0], it.value[1]) }
                    .sortedByDescending { it.sale },
                fashionCategories = fashionCategoryMap.map { CategorySale(it.key, it.value[0], it.value[1]) }
                    .sortedByDescending { it.sale }
            )
        }

    private fun generateCoreFashionReport() {
        val detail = detailUri
        if (detail == null) {
            Toast.makeText(this@MainActivity, "Please select the Sales Detail CSV first", Toast.LENGTH_SHORT).show()
            return
        }

        coreFashionButton.isEnabled = false
        staffReportButton.isEnabled = false
        sqbReportButton.isEnabled = false
        generate.isEnabled = false
        setProcessing(true, "Starting CORE / FASHION contribution…")
        result.text = "Calculating CORE and FASHION sales contribution…"

        lifecycleScope.launch {
            try {
                val report = processCoreFashionContribution(detail)
                showCoreFashionReport(report)

                result.text = buildString {
                    append("CORE / FASHION CONTRIBUTION READY\n\n")
                    append("Details rows: ${report.detailRows}\n")
                    append("Total Sale: ${money(report.totalSale)}\n")
                    append("CORE: ${money(report.core.sale)} • ${pct(contribution(report.core.sale, report.totalSale))}\n")
                    append("FASHION: ${money(report.fashion.sale)} • ${pct(contribution(report.fashion.sale, report.totalSale))}\n")
                    if (report.unmapped.sale > 0.0 || report.unmapped.qty > 0.0) {
                        append("Unmapped: ${money(report.unmapped.sale)} • ${pct(contribution(report.unmapped.sale, report.totalSale))}\n")
                    }
                    if (report.noneArticles > 0) {
                        append("NONE: ${report.noneArticles} article(s) excluded from Qty/Amount contribution.\n")
                    }
                }

                Toast.makeText(this@MainActivity, "CORE / FASHION report generated", Toast.LENGTH_SHORT).show()
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                result.text = "CORE / FASHION report failed.\n\n${e.javaClass.simpleName}: ${e.message ?: "Unknown error"}"
                Toast.makeText(this@MainActivity, "CORE / FASHION report failed", Toast.LENGTH_LONG).show()
            } finally {
                setProcessing(false)
                coreFashionButton.isEnabled = detailUri != null
                staffReportButton.isEnabled = true
                sqbReportButton.isEnabled = true
                generate.isEnabled = detailUri != null && sohUri != null
            }
        }
    }

    private fun contribution(value: Double, total: Double): Double =
        if (kotlin.math.abs(total) < 0.000001) 0.0 else value / total * 100.0

    private fun buildCoreFashionCsv(report: RootContributionResult): String = buildString {
        appendLine("Root,Category,Qty,Sale Value,Sale Contribution %")
        appendLine(listOf("CORE","TOTAL",qty(report.core.qty),report.core.sale.toString(),contribution(report.core.sale,report.totalSale).toString()).joinToString(",") { csvEscape(it) })
        report.coreCategories.forEach { appendLine(listOf("CORE",it.category,qty(it.qty),it.sale.toString(),contribution(it.sale,report.totalSale).toString()).joinToString(",") { csvEscape(it) }) }
        appendLine(listOf("FASHION","TOTAL",qty(report.fashion.qty),report.fashion.sale.toString(),contribution(report.fashion.sale,report.totalSale).toString()).joinToString(",") { csvEscape(it) })
        report.fashionCategories.forEach { appendLine(listOf("FASHION",it.category,qty(it.qty),it.sale.toString(),contribution(it.sale,report.totalSale).toString()).joinToString(",") { csvEscape(it) }) }
        if(report.unmapped.qty!=0.0||report.unmapped.sale!=0.0) appendLine(listOf("UNMAPPED","Needs Catalogue Mapping",qty(report.unmapped.qty),report.unmapped.sale.toString(),contribution(report.unmapped.sale,report.totalSale).toString()).joinToString(",") { csvEscape(it) })
        appendLine(listOf("TOTAL","ALL INCLUDED",qty(report.totalQty),report.totalSale.toString(),"100.00").joinToString(",") { csvEscape(it) })
    }

    private fun showCoreFashionReport(report: RootContributionResult) {
        val totalSale = report.totalSale
        val totalQty = report.totalQty

        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(20, 8, 20, 12)
        }

        val subtitle = TextView(this).apply {
            text = "Sales Detail • Root-level contribution"
            textSize = 12f
            setTextColor(0xFF667085.toInt())
            setPadding(0, 0, 0, 14)
        }
        box.addView(subtitle)

        fun addMetricCard(label: String, sale: Double, qtyValue: Double, contributionValue: Double, isTotal: Boolean = false) {
            val card = com.google.android.material.card.MaterialCardView(this).apply {
                radius = 18f
                cardElevation = 0f
                setCardBackgroundColor(if (isTotal) 0xFF0B2545.toInt() else 0xFFFFFFFF.toInt())
                setStrokeColor(if (isTotal) 0xFF0B2545.toInt() else 0xFFD5DCE8.toInt())
                strokeWidth = 1
                setContentPadding(16, 14, 16, 14)
            }

            val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
            val title = TextView(this).apply {
                text = label
                textSize = 13f
                setTypeface(null, android.graphics.Typeface.BOLD)
                setTextColor(if (isTotal) 0xFFD9E2F5.toInt() else 0xFF475467.toInt())
            }
            content.addView(title)

            val saleText = TextView(this).apply {
                text = money(sale)
                textSize = if (isTotal) 25f else 23f
                setTypeface(null, android.graphics.Typeface.BOLD)
                setTextColor(if (isTotal) 0xFFFFFFFF.toInt() else 0xFF101828.toInt())
                setPadding(0, 4, 0, 0)
            }
            content.addView(saleText)

            val details = TextView(this).apply {
                text = "Qty ${qty(qtyValue)}    •    Contribution ${pct(contributionValue)}"
                textSize = 12f
                setTextColor(if (isTotal) 0xFFB8C6E2.toInt() else 0xFF667085.toInt())
                setPadding(0, 2, 0, 0)
            }
            content.addView(details)
            card.addView(content)
            box.addView(card, LinearLayout.LayoutParams(-1, LinearLayout.LayoutParams.WRAP_CONTENT).apply {
                bottomMargin = 10
            })
        }

        fun addExpandableRootCard(
            label: String,
            rootSale: RootSale,
            categories: List<CategorySale>
        ) {
            val card = com.google.android.material.card.MaterialCardView(this).apply {
                radius = 18f
                cardElevation = 0f
                setCardBackgroundColor(0xFFFFFFFF.toInt())
                setStrokeColor(0xFFD5DCE8.toInt())
                strokeWidth = 1
                setContentPadding(16, 12, 16, 12)
                isClickable = true
                isFocusable = true
            }

            val header = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
            }

            val left = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            }

            val title = TextView(this).apply {
                text = label
                textSize = 13f
                setTypeface(null, android.graphics.Typeface.BOLD)
                setTextColor(0xFF475467.toInt())
            }
            left.addView(title)

            val saleText = TextView(this).apply {
                text = money(rootSale.sale)
                textSize = 23f
                setTypeface(null, android.graphics.Typeface.BOLD)
                setTextColor(0xFF101828.toInt())
                setPadding(0, 4, 0, 0)
            }
            left.addView(saleText)

            val details = TextView(this).apply {
                text = "Qty ${qty(rootSale.qty)}    •    Contribution ${pct(contribution(rootSale.sale, totalSale))}"
                textSize = 12f
                setTextColor(0xFF667085.toInt())
                setPadding(0, 2, 0, 0)
            }
            left.addView(details)
            header.addView(left)

            val arrow = TextView(this).apply {
                text = "▼"
                textSize = 18f
                setTypeface(null, android.graphics.Typeface.BOLD)
                setTextColor(0xFF667085.toInt())
                setPadding(12, 8, 2, 8)
            }
            header.addView(arrow)
            card.addView(header)

            val detailBox = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(4, 12, 4, 2)
                visibility = View.GONE
            }

            if (categories.isEmpty()) {
                detailBox.addView(TextView(this).apply {
                    text = "No category sales found."
                    textSize = 11f
                    setTextColor(0xFF667085.toInt())
                })
            } else {
                categories.forEach { category ->
                    val row = LinearLayout(this).apply {
                        orientation = LinearLayout.HORIZONTAL
                        gravity = Gravity.CENTER_VERTICAL
                        setPadding(0, 7, 0, 7)
                    }

                    val name = TextView(this).apply {
                        text = category.category
                        textSize = 12f
                        setTypeface(null, android.graphics.Typeface.BOLD)
                        setTextColor(0xFF344054.toInt())
                        layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
                    }
                    row.addView(name)

                    val values = TextView(this).apply {
                        text = "${money(category.sale)}\n${pct(contribution(category.sale, rootSale.sale))} of $label  •  ${pct(contribution(category.sale, totalSale))} of Total"
                        textSize = 10.5f
                        gravity = Gravity.END
                        setTextColor(0xFF667085.toInt())
                    }
                    row.addView(values)
                    detailBox.addView(row)
                }
            }

            val holder = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
            }
            holder.addView(card)
            holder.addView(detailBox)
            box.addView(holder, LinearLayout.LayoutParams(-1, LinearLayout.LayoutParams.WRAP_CONTENT).apply {
                bottomMargin = 10
            })

            fun toggle() {
                val expanded = detailBox.visibility == View.VISIBLE
                detailBox.visibility = if (expanded) View.GONE else View.VISIBLE
                arrow.text = if (expanded) "▼" else "▲"
            }
            card.setOnClickListener { toggle() }
            arrow.setOnClickListener { toggle() }
        }

        addMetricCard("TOTAL SALE", totalSale, totalQty, 100.0, true)
        addExpandableRootCard("CORE", report.core, report.coreCategories)
        addExpandableRootCard("FASHION", report.fashion, report.fashionCategories)

        if (report.unmapped.sale > 0.0 || report.unmapped.qty > 0.0) {
            addMetricCard(
                "UNMAPPED • Needs Catalogue Mapping",
                report.unmapped.sale,
                report.unmapped.qty,
                contribution(report.unmapped.sale, totalSale)
            )

            val note = TextView(this).apply {
                text = "⚠ Unmapped articles are included once in Total Sale, but are not assigned to CORE or FASHION until their Catalogue Root is set."
                textSize = 11f
                setTextColor(0xFFB54708.toInt())
                setPadding(4, 0, 4, 8)
            }
            box.addView(note)
        }

        if (report.noneArticles > 0) {
            val noneNote = TextView(this).apply {
                text = "NONE • ${report.noneArticles} article(s) excluded from Qty, Amount and Contribution."
                textSize = 10.5f
                setTextColor(0xFF667085.toInt())
                setPadding(4, 2, 4, 0)
            }
            box.addView(noneNote)
        }

        val dialogScroll = ScrollView(this).apply {
            isFillViewport = true
            addView(box)
        }

        lightDialogBuilder()
            .setTitle("CORE / FASHION Contribution")
            .setView(dialogScroll)
            .setNeutralButton("EXPORT AS CSV") { _, _ -> exportCsv("CORE_FASHION_Contribution", buildCoreFashionCsv(report)) }
            .setPositiveButton("Close", null)
            .show()
    }


    private data class SizeSale(val sale: Double, val qty: Double)

    private data class SizeContributionResult(
        val detailRows: Int,
        val normal: SizeSale,
        val plus: SizeSale,
        val sizesNormal: List<SizeSaleEntry>,
        val sizesPlus: List<SizeSaleEntry>,
        val excludedNoSizeRows: Int
    )

    private data class SizeSaleEntry(val size: String, val sale: Double, val qty: Double)

    private suspend fun processSizeContribution(detail: Uri): SizeContributionResult = withContext(Dispatchers.IO) {
        val sizeTypes = loadSizeMaster().associate {
            it.size.trim().uppercase(Locale.ROOT) to if (it.type.equals("Plus Size", true)) "Plus Size" else "Normal"
        }
        var normalSale = 0.0
        var normalQty = 0.0
        var plusSale = 0.0
        var plusQty = 0.0
        var rows = 0
        var noSizeRows = 0
        val normalMap = linkedMapOf<String, DoubleArray>()
        val plusMap = linkedMapOf<String, DoubleArray>()
        val reportCatalogue = loadCatalogue().associateBy { it.code.uppercase(Locale.ROOT) }
        val reportOverrides = loadReportProductMappings().groupBy { it.code.uppercase(Locale.ROOT) }

        updateProcessing("Reading Details for Size contribution…")
        streamCsv(detail) { headers, values, rowNumber ->
            if (isNonMerchandiseRow(headers, values, reportCatalogue, reportOverrides)) { rows = rowNumber; return@streamCsv }
            val size = field(values, fieldIndex(headers, "Size"))
                .trim().trim('"', '\'').uppercase(Locale.ROOT)
            val qtyValue = number(field(values, fieldIndex(headers, "Quantity")))
            val saleValue = number(field(values, fieldIndex(headers, "Amount")))

            if (size.isBlank()) {
                noSizeRows++
            } else if (sizeTypes[size] == "Plus Size") {
                plusSale += saleValue
                plusQty += qtyValue
                val bucket = plusMap.getOrPut(size) { DoubleArray(2) }
                bucket[0] += saleValue
                bucket[1] += qtyValue
            } else {
                normalSale += saleValue
                normalQty += qtyValue
                val bucket = normalMap.getOrPut(size) { DoubleArray(2) }
                bucket[0] += saleValue
                bucket[1] += qtyValue
            }
            rows = rowNumber
            if (rowNumber % 2500 == 0) updateProcessing("Reading Details… $rowNumber rows")
        }

        SizeContributionResult(
            detailRows = rows,
            normal = SizeSale(normalSale, normalQty),
            plus = SizeSale(plusSale, plusQty),
            sizesNormal = normalMap.map { SizeSaleEntry(it.key, it.value[0], it.value[1]) }.sortedByDescending { it.sale },
            sizesPlus = plusMap.map { SizeSaleEntry(it.key, it.value[0], it.value[1]) }.sortedByDescending { it.sale },
            excludedNoSizeRows = noSizeRows
        )
    }

    private fun generateSizeContributionReport() {
        val detail = detailUri ?: run {
            Toast.makeText(this@MainActivity, "Please select the Sales Detail CSV first", Toast.LENGTH_SHORT).show()
            return
        }
        sizeContributionButton.isEnabled = false
        coreFashionButton.isEnabled = false
        colorContributionButton.isEnabled = false
        staffReportButton.isEnabled = false
        sqbReportButton.isEnabled = false
        generate.isEnabled = false
        setProcessing(true, "Starting Size contribution…")
        result.text = "Calculating Normal and Plus Size contribution…"
        lifecycleScope.launch {
            try {
                val report = processSizeContribution(detail)
                showSizeContributionReport(report)
                val total = report.normal.sale + report.plus.sale
                result.text = buildString {
                    append("SIZE CONTRIBUTION READY\n\n")
                    append("Normal: ${money(report.normal.sale)} • ${pct(contribution(report.normal.sale, total))}\n")
                    append("Plus Size: ${money(report.plus.sale)} • ${pct(contribution(report.plus.sale, total))}\n")
                    append("Total: ${money(total)}\n")
                }
                Toast.makeText(this@MainActivity, "Size contribution report generated", Toast.LENGTH_SHORT).show()
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                result.text = "Size contribution report failed.\n\n${e.javaClass.simpleName}: ${e.message ?: "Unknown error"}"
                Toast.makeText(this@MainActivity, "Size contribution report failed", Toast.LENGTH_LONG).show()
            } finally {
                setProcessing(false)
                sizeContributionButton.isEnabled = detailUri != null
                coreFashionButton.isEnabled = detailUri != null
                colorContributionButton.isEnabled = detailUri != null
                staffReportButton.isEnabled = true
                sqbReportButton.isEnabled = true
                generate.isEnabled = detailUri != null && sohUri != null
            }
        }
    }

    private fun buildSizeContributionCsv(report: SizeContributionResult): String = buildString {
        appendLine("Type,Size,Qty,Sale Value,Sale Contribution %")
        report.sizesNormal.forEach { appendLine(listOf("NORMAL",it.size,qty(it.qty),it.sale.toString(),contribution(it.sale,report.normal.sale+report.plus.sale).toString()).joinToString(",") { csvEscape(it) }) }
        report.sizesPlus.forEach { appendLine(listOf("PLUS SIZE",it.size,qty(it.qty),it.sale.toString(),contribution(it.sale,report.normal.sale+report.plus.sale).toString()).joinToString(",") { csvEscape(it) }) }
        appendLine(listOf("NORMAL","TOTAL",qty(report.normal.qty),report.normal.sale.toString(),contribution(report.normal.sale,report.normal.sale+report.plus.sale).toString()).joinToString(",") { csvEscape(it) })
        appendLine(listOf("PLUS SIZE","TOTAL",qty(report.plus.qty),report.plus.sale.toString(),contribution(report.plus.sale,report.normal.sale+report.plus.sale).toString()).joinToString(",") { csvEscape(it) })
    }

    private fun showSizeContributionReport(report: SizeContributionResult) {
        val totalSale = report.normal.sale + report.plus.sale
        val totalQty = report.normal.qty + report.plus.qty
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(20, 8, 20, 12) }
        box.addView(TextView(this).apply {
            text = "Sales Detail • Size-level contribution"
            textSize = 12f
            setTextColor(0xFF667085.toInt())
            setPadding(0, 0, 0, 14)
        })

        fun addTotalCard() {
            val card = com.google.android.material.card.MaterialCardView(this).apply {
                radius = 18f; cardElevation = 0f; setCardBackgroundColor(0xFF0B2545.toInt())
                setStrokeColor(0xFF0B2545.toInt()); strokeWidth = 1; setContentPadding(16, 14, 16, 14)
            }
            val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
            content.addView(TextView(this).apply { text = "TOTAL SIZE SALE"; textSize = 13f; setTypeface(null, android.graphics.Typeface.BOLD); setTextColor(0xFFD9E2F5.toInt()) })
            content.addView(TextView(this).apply { text = money(totalSale); textSize = 25f; setTypeface(null, android.graphics.Typeface.BOLD); setTextColor(0xFFFFFFFF.toInt()); setPadding(0, 4, 0, 0) })
            content.addView(TextView(this).apply { text = "Qty ${qty(totalQty)}    •    Contribution 100.00%"; textSize = 12f; setTextColor(0xFFB8C6E2.toInt()); setPadding(0, 2, 0, 0) })
            card.addView(content)
            box.addView(card, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = 10 })
        }

        fun addExpandableSizeCard(label: String, rootSale: SizeSale, sizes: List<SizeSaleEntry>) {
            val card = com.google.android.material.card.MaterialCardView(this).apply {
                radius = 18f; cardElevation = 0f; setCardBackgroundColor(0xFFFFFFFF.toInt())
                setStrokeColor(0xFFD5DCE8.toInt()); strokeWidth = 1; setContentPadding(16, 12, 16, 12)
                isClickable = true; isFocusable = true
            }
            val header = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
            val left = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; layoutParams = LinearLayout.LayoutParams(0, -2, 1f) }
            left.addView(TextView(this).apply { text = label; textSize = 13f; setTypeface(null, android.graphics.Typeface.BOLD); setTextColor(0xFF475467.toInt()) })
            left.addView(TextView(this).apply { text = money(rootSale.sale); textSize = 23f; setTypeface(null, android.graphics.Typeface.BOLD); setTextColor(0xFF101828.toInt()); setPadding(0, 4, 0, 0) })
            left.addView(TextView(this).apply { text = "Qty ${qty(rootSale.qty)}    •    Contribution ${pct(contribution(rootSale.sale, totalSale))}"; textSize = 12f; setTextColor(0xFF667085.toInt()); setPadding(0, 2, 0, 0) })
            header.addView(left)
            val arrow = TextView(this).apply { text = "▼"; textSize = 18f; setTypeface(null, android.graphics.Typeface.BOLD); setTextColor(0xFF667085.toInt()); setPadding(12, 8, 2, 8) }
            header.addView(arrow)
            card.addView(header)

            val detailBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(4, 12, 4, 2); visibility = View.GONE }
            if (sizes.isEmpty()) {
                detailBox.addView(TextView(this).apply { text = "No sizes classified in this group."; textSize = 11f; setTextColor(0xFF667085.toInt()) })
            } else {
                sizes.forEach { entry ->
                    val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(0, 7, 0, 7) }
                    row.addView(TextView(this).apply { text = entry.size; textSize = 12f; setTypeface(null, android.graphics.Typeface.BOLD); setTextColor(0xFF344054.toInt()); layoutParams = LinearLayout.LayoutParams(0, -2, 1f) })
                    row.addView(TextView(this).apply {
                        text = "${money(entry.sale)}\n${pct(contribution(entry.sale, rootSale.sale))} of $label  •  ${pct(contribution(entry.sale, totalSale))} of Total"
                        textSize = 10.5f; gravity = Gravity.END; setTextColor(0xFF667085.toInt())
                    })
                    detailBox.addView(row)
                }
            }
            val holder = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
            holder.addView(card); holder.addView(detailBox)
            box.addView(holder, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = 10 })
            fun toggle() {
                val expanded = detailBox.visibility == View.VISIBLE
                detailBox.visibility = if (expanded) View.GONE else View.VISIBLE
                arrow.text = if (expanded) "▼" else "▲"
            }
            card.setOnClickListener { toggle() }
            arrow.setOnClickListener { toggle() }
        }

        addTotalCard()
        addExpandableSizeCard("NORMAL", report.normal, report.sizesNormal)
        addExpandableSizeCard("PLUS SIZE", report.plus, report.sizesPlus)
        if (report.excludedNoSizeRows > 0) {
            box.addView(TextView(this).apply {
                text = "ℹ ${report.excludedNoSizeRows} sale row(s) had no Size and were excluded from size contribution."
                textSize = 10.5f; setTextColor(0xFF667085.toInt()); setPadding(4, 0, 4, 0)
            })
        }
        val dialogScroll = ScrollView(this).apply { isFillViewport = true; addView(box) }
        lightDialogBuilder().setTitle("SIZE Contribution").setView(dialogScroll)
            .setNeutralButton("EXPORT AS CSV") { _, _ -> exportCsv("SIZE_Contribution", buildSizeContributionCsv(report)) }
            .setPositiveButton("Close", null).show()
    }




    // ---------------- NEW PRODUCT SALE REPORT ----------------

    private data class NewProductOption(
        val key: String,
        val code: String,
        val productName: String,
        val category: String
    )

    private data class NewProductSaleEntry(
        val code: String,
        val productName: String,
        val category: String,
        val qty: Double,
        val sale: Double,
        val categorySale: Double,
        val totalStoreSale: Double,
        val sohQty: Double?
    )

    private data class NewProductSaleReport(
        val entries: List<NewProductSaleEntry>,
        val totalSelectedQty: Double,
        val totalSelectedSale: Double,
        val totalStoreSale: Double
    )

    private fun normalizeProductKey(name: String): String = normalizeProductName(name)

    private fun showNewProductSalePicker() {
        val detail = detailUri ?: run {
            Toast.makeText(this, "Please select the Sales Detail CSV first", Toast.LENGTH_SHORT).show()
            return
        }

        setProcessing(true, "Reading products from Details…")
        lifecycleScope.launch {
            try {
                val options = loadNewProductOptions(detail)
                if (options.isEmpty()) {
                    Toast.makeText(this@MainActivity, "No products found in Details", Toast.LENGTH_SHORT).show()
                    return@launch
                }
                showNewProductSelectionDialog(detail, options)
            } catch (e: CancellationException) { throw e }
            catch (e: Exception) {
                Toast.makeText(this@MainActivity, "Unable to load products: ${e.message ?: "Unknown error"}", Toast.LENGTH_LONG).show()
            } finally {
                setProcessing(false)
            }
        }
    }

    private suspend fun loadNewProductOptions(detail: Uri): List<NewProductOption> = withContext(Dispatchers.IO) {
        val catalogue = loadCatalogue().associateBy { it.code.uppercase(Locale.ROOT) }
        val overrides = loadReportProductMappings().groupBy { it.code.uppercase(Locale.ROOT) }
        val byKey = linkedMapOf<String, NewProductOption>()
        streamCsv(detail) { headers, values, rowNumber ->
            val name = field(values, fieldIndex(headers, "ProductName", "ProductFullName")).trim()
            if (name.isBlank()) return@streamCsv
            val code = resolveDetailsCode(headers, values, catalogue.keys).trim().uppercase(Locale.ROOT)
            val mapping = resolveMapping(code, name, catalogue, overrides)
            val category = when {
                mapping == null -> "UNMAPPED"
                mapping.root.equals("NONE", true) || mapping.category.equals("NON-MERCHANDISE", true) -> "NON-MERCHANDISE"
                mapping.category.isBlank() -> "UNMAPPED"
                else -> mapping.category.trim()
            }
            if (category.equals("NON-MERCHANDISE", true)) return@streamCsv
            val key = "${code.uppercase(Locale.ROOT)}|${normalizeProductKey(name)}"
            byKey[key] = NewProductOption(key, code, name, category)
            if (rowNumber % 2500 == 0) updateProcessing("Reading products… $rowNumber rows")
        }
        byKey.values.sortedWith(compareBy({ it.productName.lowercase(Locale.ROOT) }, { it.code })).toList()
    }

    private fun showNewProductSelectionDialog(detail: Uri, options: List<NewProductOption>) {
        val selected = linkedSetOf<String>()
        val filtered = options.toMutableList()
        val selectionHeader = TextView(this).apply {
            text = "Select one or multiple products (0)"
            textSize = 11.5f
            setTextColor(0xFF667085.toInt())
            setPadding(0, dp(6), 0, dp(6))
        }
        val selectionError = TextView(this).apply {
            text = ""
            textSize = 12f
            setTextColor(0xFFB42318.toInt())
            setPadding(0, 0, 0, dp(4))
            visibility = View.GONE
        }
        fun refreshSelectionCount() {
            selectionHeader.text = "Select one or multiple products (${selected.size})"
            selectionError.visibility = View.GONE
            selectionError.text = ""
        }
        val adapter = object : BaseAdapter() {
            override fun getCount(): Int = filtered.size
            override fun getItem(position: Int): NewProductOption = filtered[position]
            override fun getItemId(position: Int): Long = position.toLong()
            override fun getView(position: Int, convertView: View?, parent: android.view.ViewGroup?): View {
                val row = convertView as? LinearLayout ?: LinearLayout(this@MainActivity).apply {
                    orientation = LinearLayout.HORIZONTAL
                    gravity = Gravity.CENTER_VERTICAL
                    setPadding(dp(8), dp(5), dp(8), dp(5))
                }
                row.removeAllViews()
                val option = filtered[position]
                val cb = CheckBox(this@MainActivity).apply {
                    isChecked = selected.contains(option.key)
                    text = "${option.productName}  •  ${option.code.ifBlank { "NO CODE" }}"
                    textSize = 13f
                    setTextColor(0xFF101828.toInt())
                    setOnClickListener {
                        if (isChecked) selected.add(option.key) else selected.remove(option.key)
                        refreshSelectionCount()
                    }
                }
                row.addView(cb, LinearLayout.LayoutParams(-1, dp(52)))
                return row
            }
        }

        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(4), dp(16), 0)
        }
        val search = EditText(this).apply {
            hint = "Search product name or code"
            isSingleLine = true
            setPadding(dp(12), 0, dp(12), 0)
        }
        box.addView(search, LinearLayout.LayoutParams(-1, dp(50)))
        box.addView(selectionHeader)
        box.addView(selectionError)
        val list = ListView(this).apply {
            dividerHeight = 1
            this.adapter = adapter
        }
        box.addView(list, LinearLayout.LayoutParams(-1, dp(430)))

        search.addTextChangedListener(object : android.text.TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) = Unit
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                val q = s?.toString()?.trim()?.lowercase(Locale.ROOT).orEmpty()
                filtered.clear()
                filtered.addAll(options.filter { it.productName.lowercase(Locale.ROOT).contains(q) || it.code.lowercase(Locale.ROOT).contains(q) })
                adapter.notifyDataSetChanged()
            }
            override fun afterTextChanged(s: android.text.Editable?) = Unit
        })

        val dialog = lightDialogBuilder().setTitle("NEW PRODUCT SALE • Select Products").setView(box)
            .setNegativeButton("Cancel", null)
            .setPositiveButton("Generate", null)
            .create()
        dialog.setOnShowListener {
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                if (selected.isEmpty()) {
                    selectionError.text = "Please select at least one product."
                    selectionError.visibility = View.VISIBLE
                    return@setOnClickListener
                }
                val chosen = options.filter { selected.contains(it.key) }
                dialog.dismiss()
                generateNewProductSaleReport(detail, chosen)
            }
        }
        dialog.show()
    }

    private fun generateNewProductSaleReport(detail: Uri, chosen: List<NewProductOption>) {
        newProductSaleButton.isEnabled = false
        generate.isEnabled = false
        setProcessing(true, "Calculating selected product sales…")
        lifecycleScope.launch {
            try {
                val report = processNewProductSaleReport(detail, chosen)
                showNewProductSaleReport(report)
                result.text = "NEW PRODUCT SALE REPORT READY\n\nSelected products: ${report.entries.size}\nSelected sale: ${money(report.totalSelectedSale)}"
                Toast.makeText(this@MainActivity, "New Product Sale report generated", Toast.LENGTH_SHORT).show()
            } catch (e: CancellationException) { throw e }
            catch (e: Exception) {
                result.text = "New Product Sale report failed.\n\n${e.javaClass.simpleName}: ${e.message ?: "Unknown error"}"
                Toast.makeText(this@MainActivity, "New Product Sale report failed", Toast.LENGTH_LONG).show()
            } finally {
                setProcessing(false)
                newProductSaleButton.isEnabled = detailUri != null
                generate.isEnabled = detailUri != null && sohUri != null
            }
        }
    }

    private suspend fun processNewProductSaleReport(detail: Uri, chosen: List<NewProductOption>): NewProductSaleReport = withContext(Dispatchers.IO) {
        val catalogue = loadCatalogue().associateBy { it.code.uppercase(Locale.ROOT) }
        val overrides = loadReportProductMappings().groupBy { it.code.uppercase(Locale.ROOT) }
        val selectedKeys = chosen.map { it.key }.toSet()
        val productTotals = linkedMapOf<String, DoubleArray>()
        val categoryTotals = linkedMapOf<String, Double>()
        var totalStoreSale = 0.0
        var rows = 0

        updateProcessing("Reading Details for selected products…")
        streamCsv(detail) { headers, values, rowNumber ->
            val name = field(values, fieldIndex(headers, "ProductName", "ProductFullName")).trim()
            if (name.isBlank()) return@streamCsv
            val code = resolveDetailsCode(headers, values, catalogue.keys).trim().uppercase(Locale.ROOT)
            val mapping = resolveMapping(code, name, catalogue, overrides)
            if (mapping != null && !(mapping.root.equals("NONE", true) || mapping.category.equals("NON-MERCHANDISE", true))) {
                val category = mapping.category.trim().ifBlank { "UNMAPPED" }
                val qty = number(field(values, fieldIndex(headers, "Quantity")))
                val sale = number(field(values, fieldIndex(headers, "Amount")))
                totalStoreSale += sale
                categoryTotals[category] = (categoryTotals[category] ?: 0.0) + sale
                val key = "${code}|${normalizeProductKey(name)}"
                if (selectedKeys.contains(key)) {
                    val a = productTotals.getOrPut(key) { DoubleArray(2) }
                    a[0] += qty
                    a[1] += sale
                }
            }
            rows = rowNumber
            if (rowNumber % 2500 == 0) updateProcessing("Reading Details… $rowNumber rows")
        }

        // If SOH is uploaded, aggregate current available stock for each selected
        // product. Match primarily by ProductGroupCode + ProductName, with a
        // product-name fallback when the code is unavailable in SOH.
        val sohTotals = linkedMapOf<String, Double>()
        val soh = sohUri
        if (soh != null) {
            updateProcessing("Reading SOH for selected products…")
            val chosenByKey = chosen.associateBy { it.key }
            val chosenByName = chosen.groupBy { normalizeProductKey(it.productName) }
            streamCsv(soh) { headers, values, rowNumber ->
                val sohName = field(values, fieldIndex(headers, "ProductName", "ProductFullName")).trim()
                if (sohName.isBlank()) return@streamCsv
                val sohCode = field(values, fieldIndex(headers, "ProductGroupCode", "ArticleNumber", "CategoryCode")).trim().uppercase(Locale.ROOT)
                val exactKey = "${sohCode}|${normalizeProductKey(sohName)}"
                val selected = chosenByKey[exactKey]
                    ?: chosenByName[normalizeProductKey(sohName)]?.singleOrNull()
                if (selected != null) {
                    val stock = number(field(values, fieldIndex(headers, "Stock")))
                    sohTotals[selected.key] = (sohTotals[selected.key] ?: 0.0) + stock
                }
                if (rowNumber % 5000 == 0) updateProcessing("Reading SOH… $rowNumber rows")
            }
        }

        val entries = chosen.map { option ->
            val totals = productTotals[option.key] ?: DoubleArray(2)
            val categorySale = categoryTotals[option.category] ?: 0.0
            NewProductSaleEntry(option.code, option.productName, option.category, totals[0], totals[1], categorySale, totalStoreSale, if (soh != null) sohTotals[option.key] ?: 0.0 else null)
        }
        NewProductSaleReport(entries, entries.sumOf { it.qty }, entries.sumOf { it.sale }, totalStoreSale)
    }

    private fun showNewProductSaleReport(report: NewProductSaleReport) {
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(16, 8, 16, 16) }
        root.addView(TextView(this).apply {
            text = "Selected products • Category contribution • Store contribution"
            textSize = 11.5f
            setTextColor(0xFF667085.toInt())
            setPadding(0, 0, 0, 12)
        })

        val summary = com.google.android.material.card.MaterialCardView(this).apply {
            radius = 18f; cardElevation = 0f; setCardBackgroundColor(0xFFFFFFFF.toInt()); setStrokeColor(0xFFD5DCE8.toInt()); strokeWidth = 1; setContentPadding(14, 12, 14, 12)
        }
        val sb = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        fun metric(label: String, value: String) {
            sb.addView(TextView(this).apply { text = "$label  $value"; textSize = 12.5f; setTextColor(0xFF344054.toInt()); setPadding(0, 3, 0, 3) })
        }
        metric("SELECTED PRODUCTS", report.entries.size.toString())
        metric("SELECTED SALE", money(report.totalSelectedSale))
        metric("SELECTED QTY", qty(report.totalSelectedQty))
        metric("TOTAL STORE SALE", money(report.totalStoreSale))
        summary.addView(sb)
        root.addView(summary, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = 12 })

        val table = TableLayout(this)
        table.addView(makeTableRow(arrayOf("Product", "Category", "Sold Qty", "SOH", "Sale Thru %", "Sale", "Category Cont.", "Store Cont."), true))
        report.entries.forEach { e ->
            val categoryPct = if (e.categorySale > 0) e.sale / e.categorySale * 100.0 else 0.0
            val storePct = if (e.totalStoreSale > 0) e.sale / e.totalStoreSale * 100.0 else 0.0
            val saleThruPct = e.sohQty?.let { saleThru(e.qty, it) }?.let { pct(it) } ?: "—"
            table.addView(makeTableRow(arrayOf("${e.productName}\n${e.code}", e.category, qty(e.qty), e.sohQty?.let { qty(it) } ?: "—", saleThruPct, money(e.sale), pct(categoryPct), pct(storePct)), false))
        }
        val totalSoh = report.entries.sumOf { it.sohQty ?: 0.0 }
        table.addView(makeTableRow(arrayOf("TOTAL SELECTED", "", qty(report.totalSelectedQty), if (report.entries.any { it.sohQty != null }) qty(totalSoh) else "—", if (report.entries.any { it.sohQty != null }) pct(saleThru(report.totalSelectedQty, totalSoh)) else "—", money(report.totalSelectedSale), "", if (report.totalStoreSale > 0) pct(report.totalSelectedSale / report.totalStoreSale * 100.0) else "0.00%"), true))
        root.addView(HorizontalScrollView(this).apply { addView(table) })

        val scroll = ScrollView(this).apply { isFillViewport = true; addView(root) }
        lightDialogBuilder().setTitle("NEW PRODUCT SALE").setView(scroll)
            .setNeutralButton("EXPORT AS CSV") { _, _ -> exportCsv("New_Product_Sale", buildNewProductSaleCsv(report)) }
            .setPositiveButton("Close", null).show()
    }

    private fun buildNewProductSaleCsv(report: NewProductSaleReport): String = buildString {
        appendLine("NEW PRODUCT SALE")
        appendLine("Product,Code,Category,Sold Qty,SOH Qty,Sale Thru %,Sale,Category Contribution %,Store Contribution %")
        report.entries.forEach { e ->
            val categoryPct = if (e.categorySale > 0) e.sale / e.categorySale * 100.0 else 0.0
            val storePct = if (e.totalStoreSale > 0) e.sale / e.totalStoreSale * 100.0 else 0.0
            val saleThruPct = e.sohQty?.let { saleThru(e.qty, it) } ?: ""
            appendLine(listOf(e.productName, e.code, e.category, e.qty, e.sohQty ?: "", saleThruPct, e.sale, categoryPct, storePct).joinToString(",") { csvEscape(it.toString()) })
        }
        val totalSoh = report.entries.sumOf { it.sohQty ?: 0.0 }
        appendLine(listOf("TOTAL SELECTED", "", "", report.totalSelectedQty, if (report.entries.any { it.sohQty != null }) totalSoh else "", if (report.entries.any { it.sohQty != null }) saleThru(report.totalSelectedQty, totalSoh) else "", report.totalSelectedSale, "", if (report.totalStoreSale > 0) report.totalSelectedSale / report.totalStoreSale * 100.0 else 0.0).joinToString(",") { csvEscape(it.toString()) })
        appendLine()
        appendLine("TOTAL STORE SALE,${report.totalStoreSale}")
    }

    // ---------------- PRODUCT WISE SALE REPORT ----------------

    private data class ProductWiseSaleEntry(
        val code: String,
        val productName: String,
        val category: String,
        val soldQty: Double,
        val saleAmount: Double,
        val sohQty: Double?
    )

    private data class ProductWiseSaleReport(
        val entries: List<ProductWiseSaleEntry>,
        val totalQty: Double,
        val totalSale: Double,
        val totalSoh: Double?,
        val totalStoreSale: Double
    )

    private fun generateProductWiseSaleReport() {
        val detail = detailUri
        if (detail == null) {
            Toast.makeText(this, "Please upload the Details file first", Toast.LENGTH_SHORT).show()
            return
        }
        productWiseSaleButton.isEnabled = false
        setProcessing(true, "Preparing Product Wise Sale Report…")
        lifecycleScope.launch {
            try {
                val report = processProductWiseSaleReport(detail, sohUri)
                if (report.entries.isEmpty()) {
                    Toast.makeText(this@MainActivity, "No eligible mapped product sales found", Toast.LENGTH_LONG).show()
                    return@launch
                }
                showProductWiseSaleReport(report)
                result.text = "PRODUCT WISE SALE REPORT READY\n\nProducts: ${report.entries.size}\nTotal sale: ${money(report.totalSale)}"
                Toast.makeText(this@MainActivity, "Product Wise Sale Report generated", Toast.LENGTH_SHORT).show()
            } catch (e: CancellationException) { throw e }
            catch (e: Exception) {
                result.text = "Product Wise Sale Report failed.\n\n${e.javaClass.simpleName}: ${e.message ?: "Unknown error"}"
                Toast.makeText(this@MainActivity, "Product Wise Sale Report failed", Toast.LENGTH_LONG).show()
            } finally {
                setProcessing(false)
                productWiseSaleButton.isEnabled = true
            }
        }
    }

    private suspend fun processProductWiseSaleReport(detail: Uri, soh: Uri?): ProductWiseSaleReport = withContext(Dispatchers.IO) {
        val catalogue = loadCatalogue().associateBy { it.code.uppercase(Locale.ROOT) }
        val overrides = loadReportProductMappings().groupBy { it.code.uppercase(Locale.ROOT) }
        val totals = linkedMapOf<String, DoubleArray>() // qty, sale
        val names = linkedMapOf<String, Pair<String, String>>() // code/name, category
        val categorySales = linkedMapOf<String, Double>()
        var totalStoreSale = 0.0
        var rows = 0
        updateProcessing("Reading Details and grouping products…")
        streamCsv(detail) { headers, values, rowNumber ->
            val name = field(values, fieldIndex(headers, "ProductName", "ProductFullName")).trim()
            if (name.isBlank()) return@streamCsv
            val code = resolveDetailsCode(headers, values, catalogue.keys).trim().uppercase(Locale.ROOT)
            val mapping = resolveMapping(code, name, catalogue, overrides)
            if (mapping != null && !mapping.root.equals("NONE", true) && !mapping.category.equals("NON-MERCHANDISE", true)) {
                val category = mapping.category.trim().ifBlank { "UNMAPPED" }
                val key = "$code|${normalizeProductKey(name)}"
                val a = totals.getOrPut(key) { DoubleArray(2) }
                a[0] += number(field(values, fieldIndex(headers, "Quantity")))
                val sale = number(field(values, fieldIndex(headers, "Amount")))
                a[1] += sale
                names[key] = name to category
                categorySales[category] = (categorySales[category] ?: 0.0) + sale
                totalStoreSale += sale
            }
            rows = rowNumber
            if (rowNumber % 2500 == 0) updateProcessing("Reading Details… $rowNumber rows")
        }

        val sohTotals = linkedMapOf<String, Double>()
        if (soh != null) {
            updateProcessing("Matching product stock from SOH…")
            val keysByName = names.keys.groupBy { it.substringAfter('|') }
            streamCsv(soh) { headers, values, rowNumber ->
                val name = field(values, fieldIndex(headers, "ProductName", "ProductFullName")).trim()
                if (name.isBlank()) return@streamCsv
                val code = field(values, fieldIndex(headers, "ProductGroupCode", "ArticleNumber", "CategoryCode")).trim().uppercase(Locale.ROOT)
                val exact = "$code|${normalizeProductKey(name)}"
                val key = if (exact in names) exact else keysByName[normalizeProductKey(name)]?.singleOrNull()
                if (key != null) sohTotals[key] = (sohTotals[key] ?: 0.0) + number(field(values, fieldIndex(headers, "Stock")))
                if (rowNumber % 5000 == 0) updateProcessing("Reading SOH… $rowNumber rows")
            }
        }

        val entries = names.keys.map { key ->
            val (name, category) = names.getValue(key)
            val amounts = totals.getValue(key)
            ProductWiseSaleEntry(key.substringBefore('|'), name, category, amounts[0], amounts[1], if (soh != null) sohTotals[key] ?: 0.0 else null)
        }.sortedWith(compareByDescending<ProductWiseSaleEntry> { it.saleAmount }.thenBy { it.productName.lowercase(Locale.ROOT) })
        ProductWiseSaleReport(entries, entries.sumOf { it.soldQty }, entries.sumOf { it.saleAmount }, if (soh != null) entries.sumOf { it.sohQty ?: 0.0 } else null, totalStoreSale)
    }

    private fun showProductWiseSaleReport(report: ProductWiseSaleReport) {
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(14, 8, 14, 14) }
        root.addView(TextView(this).apply {
            text = "All eligible sold products • Sorted by highest Sale Amount"
            textSize = 11.5f
            setTextColor(0xFF667085.toInt())
            setPadding(0, 0, 0, 10)
        })
        val summary = com.google.android.material.card.MaterialCardView(this).apply {
            radius = 16f; cardElevation = 0f; setCardBackgroundColor(0xFFFFFFFF.toInt()); setStrokeColor(0xFFD5DCE8.toInt()); strokeWidth = 1; setContentPadding(12, 10, 12, 10)
        }
        val metrics = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        listOf(
            "PRODUCTS" to report.entries.size.toString(),
            "TOTAL SOLD QTY" to qty(report.totalQty),
            "TOTAL SALE" to money(report.totalSale),
            "TOTAL SOH" to (report.totalSoh?.let { qty(it) } ?: "—")
        ).forEach { (label, value) ->
            metrics.addView(TextView(this).apply { text = "$label   $value"; textSize = 12.5f; setTextColor(0xFF344054.toInt()); setPadding(0, 2, 0, 2) })
        }
        summary.addView(metrics)
        root.addView(summary, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = 10 })

        val table = TableLayout(this)
        table.addView(makeTableRow(arrayOf("Product / Code", "Category", "Sold Qty", "Sale Amount", "SOH", "Sale Thru %", "Category Cont. %", "Store Cont. %"), true))
        val categoryTotals = report.entries.groupBy { it.category }.mapValues { (_, items) -> items.sumOf { it.saleAmount } }
        report.entries.forEach { e ->
            val categoryTotal = categoryTotals[e.category] ?: 0.0
            val categoryPct = if (categoryTotal > 0) e.saleAmount / categoryTotal * 100.0 else 0.0
            val storePct = if (report.totalStoreSale > 0) e.saleAmount / report.totalStoreSale * 100.0 else 0.0
            val sohText = e.sohQty?.let { qty(it) } ?: "—"
            val thruText = e.sohQty?.let { pct(saleThru(e.soldQty, it)) } ?: "—"
            table.addView(makeTableRow(arrayOf("${e.productName}\n${e.code}", e.category, qty(e.soldQty), money(e.saleAmount), sohText, thruText, pct(categoryPct), pct(storePct)), false))
        }
        table.addView(makeTableRow(arrayOf("TOTAL", "", qty(report.totalQty), money(report.totalSale), report.totalSoh?.let { qty(it) } ?: "—", report.totalSoh?.let { pct(saleThru(report.totalQty, it)) } ?: "—", "100.00%", if (report.totalStoreSale > 0) pct(report.totalSale / report.totalStoreSale * 100.0) else "0.00%"), true))
        root.addView(HorizontalScrollView(this).apply { addView(table) })
        val scroll = ScrollView(this).apply { isFillViewport = true; addView(root) }
        lightDialogBuilder().setTitle("PRODUCT WISE SALE REPORT").setView(scroll)
            .setNeutralButton("EXPORT AS CSV") { _, _ -> exportCsv("Product_Wise_Sale_Report", buildProductWiseSaleCsv(report)) }
            .setPositiveButton("Close", null).show()
    }

    private fun buildProductWiseSaleCsv(report: ProductWiseSaleReport): String = buildString {
        appendLine("PRODUCT WISE SALE REPORT")
        appendLine("Product,Code,Category,Sold Qty,Sale Amount,SOH Qty,Sale Thru %,Category Contribution %,Store Contribution %")
        val categoryTotals = report.entries.groupBy { it.category }.mapValues { (_, items) -> items.sumOf { it.saleAmount } }
        report.entries.forEach { e ->
            val categoryTotal = categoryTotals[e.category] ?: 0.0
            val categoryPct = if (categoryTotal > 0) e.saleAmount / categoryTotal * 100.0 else 0.0
            val storePct = if (report.totalStoreSale > 0) e.saleAmount / report.totalStoreSale * 100.0 else 0.0
            appendLine(listOf(e.productName, e.code, e.category, e.soldQty, e.saleAmount, e.sohQty ?: "", e.sohQty?.let { saleThru(e.soldQty, it) } ?: "", categoryPct, storePct).joinToString(",") { csvEscape(it.toString()) })
        }
        appendLine(listOf("TOTAL", "", "", report.totalQty, report.totalSale, report.totalSoh ?: "", report.totalSoh?.let { saleThru(report.totalQty, it) } ?: "", 100.0, if (report.totalStoreSale > 0) report.totalSale / report.totalStoreSale * 100.0 else 0.0).joinToString(",") { csvEscape(it.toString()) })
        appendLine()
        appendLine("TOTAL STORE SALE,${report.totalStoreSale}")
    }

    // ---------------- BIG BILL REPORT ----------------

    private data class BigBillStaffEntry(
        val staffId: String,
        val staffName: String,
        val bigBills: Int,
        val bigSale: Double,
        val smallBills: Int,
        val smallSale: Double
    )

    private data class BigBillReportResult(
        val smallThreshold: Double,
        val bigThreshold: Double,
        val storeBigBills: Int,
        val storeBigSale: Double,
        val storeSmallBills: Int,
        val storeSmallSale: Double,
        val staff: List<BigBillStaffEntry>,
        val ignoredBelowSmall: Int,
        val exchangeBillsExcluded: Int
    )

    private suspend fun processBigBillReport(detail: Uri, smallThreshold: Double, bigThreshold: Double): BigBillReportResult = withContext(Dispatchers.IO) {
        data class MutableBill(
            var amount: Double = 0.0,
            var staffId: String = "",
            var staffName: String = "",
            var exchange: Boolean = false
        )

        val bills = linkedMapOf<String, MutableBill>()
        val reportCatalogue = loadCatalogue().associateBy { it.code.uppercase(Locale.ROOT) }
        val reportOverrides = loadReportProductMappings().groupBy { it.code.uppercase(Locale.ROOT) }
        var rows = 0

        updateProcessing("Reading Details for Big Bill Report…")
        streamCsv(detail) { headers, values, rowNumber ->
            if (isNonMerchandiseRow(headers, values, reportCatalogue, reportOverrides)) {
                rows = rowNumber
                return@streamCsv
            }
            val billNo = field(values, fieldIndex(headers, "BillNumber")).trim()
            if (billNo.isBlank()) {
                rows = rowNumber
                return@streamCsv
            }

            val bill = bills.getOrPut(billNo) { MutableBill() }
            val staffId = field(values, fieldIndex(headers, "SalesmanCode", "StaffCode", "EmployeeCode")).trim()
            val staffName = field(values, fieldIndex(headers, "SalesmanName", "StaffName", "EmployeeName"))
                .replace(Regex("\\s+"), " ").trim()
            if (bill.staffId.isBlank() && staffId.isNotBlank()) bill.staffId = staffId
            if (bill.staffName.isBlank() && staffName.isNotBlank()) bill.staffName = staffName

            bill.amount += number(field(values, fieldIndex(headers, "Amount")))
            val exchangeRef = field(values, fieldIndex(headers, "ExchangeBillNumber")).trim()
            val exchangeDate = field(values, fieldIndex(headers, "ExchangeBillDate")).trim()
            bill.exchange = bill.exchange || exchangeRef.isNotBlank() || exchangeDate.isNotBlank() || billNo.uppercase(Locale.ROOT).startsWith("SR")

            rows = rowNumber
            if (rowNumber % 2500 == 0) updateProcessing("Reading Details for Big Bill Report… $rowNumber rows")
        }

        var storeBigBills = 0
        var storeSmallBills = 0
        var storeBigSale = 0.0
        var storeSmallSale = 0.0
        var ignoredBelowSmall = 0
        var exchangeBillsExcluded = 0

        data class MutableStaff(var id: String, var name: String, var bigBills: Int = 0, var bigSale: Double = 0.0, var smallBills: Int = 0, var smallSale: Double = 0.0)
        val staffMap = linkedMapOf<String, MutableStaff>()

        bills.forEach { (_, bill) ->
            if (bill.exchange) {
                exchangeBillsExcluded++
                return@forEach
            }
            val amount = bill.amount
            if (amount < smallThreshold) {
                ignoredBelowSmall++
                return@forEach
            }

            val identity = when {
                bill.staffId.isNotBlank() -> bill.staffId
                bill.staffName.isNotBlank() -> bill.staffName.uppercase(Locale.ROOT)
                else -> ""
            }

            when {
                amount >= bigThreshold -> {
                    storeBigBills++
                    storeBigSale += amount
                    if (identity.isNotBlank()) {
                        val staff = staffMap.getOrPut(identity) { MutableStaff(identity, bill.staffName.ifBlank { identity }) }
                        if (staff.name.isBlank() && bill.staffName.isNotBlank()) staff.name = bill.staffName
                        staff.bigBills++
                        staff.bigSale += amount
                    }
                }
                else -> {
                    storeSmallBills++
                    storeSmallSale += amount
                    if (identity.isNotBlank()) {
                        val staff = staffMap.getOrPut(identity) { MutableStaff(identity, bill.staffName.ifBlank { identity }) }
                        if (staff.name.isBlank() && bill.staffName.isNotBlank()) staff.name = bill.staffName
                        staff.smallBills++
                        staff.smallSale += amount
                    }
                }
            }
        }

        BigBillReportResult(
            smallThreshold = smallThreshold,
            bigThreshold = bigThreshold,
            storeBigBills = storeBigBills,
            storeBigSale = storeBigSale,
            storeSmallBills = storeSmallBills,
            storeSmallSale = storeSmallSale,
            staff = staffMap.values
                .filter { it.bigBills > 0 || it.smallBills > 0 }
                .map { BigBillStaffEntry(it.id, it.name.ifBlank { it.id }, it.bigBills, it.bigSale, it.smallBills, it.smallSale) }
                .sortedWith(compareByDescending<BigBillStaffEntry> { it.bigBills }.thenByDescending { it.bigSale }.thenBy { it.staffName.lowercase(Locale.ROOT) }),
            ignoredBelowSmall = ignoredBelowSmall,
            exchangeBillsExcluded = exchangeBillsExcluded
        )
    }

    private fun showBigBillThresholdDialog() {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(4), dp(20), 0)
        }
        val smallInput = EditText(this).apply {
            hint = "Example: 5000"
            inputType = android.text.InputType.TYPE_CLASS_NUMBER or android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL
            setText("5000")
            selectAll()
        }
        val bigInput = EditText(this).apply {
            hint = "Example: 10000"
            inputType = android.text.InputType.TYPE_CLASS_NUMBER or android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL
            setText("10000")
            selectAll()
        }
        box.addView(TextView(this).apply {
            text = "Small Bill From"
            textSize = 13f
            setTextColor(0xFF344054.toInt())
            setPadding(0, dp(8), 0, dp(4))
        })
        box.addView(smallInput, LinearLayout.LayoutParams(-1, dp(52)))
        box.addView(TextView(this).apply {
            text = "Big Bill From"
            textSize = 13f
            setTextColor(0xFF344054.toInt())
            setPadding(0, dp(12), 0, dp(4))
        })
        box.addView(bigInput, LinearLayout.LayoutParams(-1, dp(52)))
        box.addView(TextView(this).apply {
            text = "Below Small Bill amount will be ignored. Big Bill threshold is inclusive."
            textSize = 11f
            setTextColor(0xFF667085.toInt())
            setPadding(0, dp(8), 0, dp(4))
        })

        lightDialogBuilder().setTitle("BIG BILL REPORT • Set Limits").setView(box)
            .setNegativeButton("Cancel", null)
            .setPositiveButton("Generate") { _, _ ->
                val small = number(smallInput.text.toString())
                val big = number(bigInput.text.toString())
                if (small < 0 || big <= small) {
                    Toast.makeText(this, "Big Bill From must be greater than Small Bill From", Toast.LENGTH_LONG).show()
                    return@setPositiveButton
                }
                generateBigBillReport(small, big)
            }.show()
    }

    private fun generateBigBillReport(smallThreshold: Double, bigThreshold: Double) {
        val detail = detailUri ?: run {
            Toast.makeText(this@MainActivity, "Please select the Sales Detail CSV first", Toast.LENGTH_SHORT).show()
            return
        }
        bigBillReportButton.isEnabled = false
        generate.isEnabled = false
        setProcessing(true, "Starting Big Bill Report…")
        result.text = "Checking every bill amount and classifying Small / Big bills…"
        lifecycleScope.launch {
            try {
                val report = processBigBillReport(detail, smallThreshold, bigThreshold)
                showBigBillReport(report)
                result.text = buildString {
                    append("BIG BILL REPORT READY\n\n")
                    append("Small Bill: ${money(report.smallThreshold)}–${money(report.bigThreshold - 0.01)}\n")
                    append("Big Bill: ${money(report.bigThreshold)}+\n")
                    append("Big Bills: ${report.storeBigBills} • ${money(report.storeBigSale)}\n")
                    append("Small Bills: ${report.storeSmallBills} • ${money(report.storeSmallSale)}\n")
                }
                Toast.makeText(this@MainActivity, "Big Bill report generated", Toast.LENGTH_SHORT).show()
            } catch (e: CancellationException) { throw e }
            catch (e: Exception) {
                result.text = "Big Bill report failed.\n\n${e.javaClass.simpleName}: ${e.message ?: "Unknown error"}"
                Toast.makeText(this@MainActivity, "Big Bill report failed", Toast.LENGTH_LONG).show()
            } finally {
                setProcessing(false)
                bigBillReportButton.isEnabled = detailUri != null
                generate.isEnabled = detailUri != null && sohUri != null
            }
        }
    }

    private fun showBigBillReport(report: BigBillReportResult) {
        val eligibleBills = report.storeBigBills + report.storeSmallBills
        val eligibleSale = report.storeBigSale + report.storeSmallSale
        val bigBillPct = if (eligibleBills > 0) report.storeBigBills.toDouble() / eligibleBills * 100.0 else 0.0
        val bigSalePct = if (eligibleSale > 0) report.storeBigSale / eligibleSale * 100.0 else 0.0
        val avgBig = if (report.storeBigBills > 0) report.storeBigSale / report.storeBigBills else 0.0
        val avgSmall = if (report.storeSmallBills > 0) report.storeSmallSale / report.storeSmallBills else 0.0

        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(16, 8, 16, 16) }
        root.addView(TextView(this).apply {
            text = "₹${money(report.smallThreshold).removePrefix("₹")}–${money(report.bigThreshold - 0.01).removePrefix("₹")} = SMALL BILL   •   ${money(report.bigThreshold)}+ = BIG BILL"
            textSize = 11.5f; setTextColor(0xFF667085.toInt()); setPadding(0, 0, 0, 12)
        })

        val summary = com.google.android.material.card.MaterialCardView(this).apply {
            radius = 18f; cardElevation = 0f; setCardBackgroundColor(0xFFFFFFFF.toInt()); setStrokeColor(0xFFD5DCE8.toInt()); strokeWidth = 1; setContentPadding(14, 12, 14, 12)
        }
        val sb = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        fun metric(label: String, value: String) {
            sb.addView(TextView(this).apply { text = "$label  $value"; textSize = 12.5f; setTextColor(0xFF344054.toInt()); setPadding(0, 3, 0, 3) })
        }
        metric("BIG BILLS", "${report.storeBigBills}  •  ${money(report.storeBigSale)}")
        metric("SMALL BILLS", "${report.storeSmallBills}  •  ${money(report.storeSmallSale)}")
        metric("AVERAGE BIG BILL", money(avgBig))
        metric("AVERAGE SMALL BILL", money(avgSmall))
        metric("BIG BILL % OF TOTAL BILLS", pct(bigBillPct))
        metric("BIG BILL % OF TOTAL SALE", pct(bigSalePct))
        summary.addView(sb); root.addView(summary, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = 12 })

        root.addView(TextView(this).apply { text = "STORE LEVEL"; textSize = 13f; setTypeface(null, android.graphics.Typeface.BOLD); setTextColor(0xFF101828.toInt()); setPadding(2, 0, 0, 7) })
        val table = TableLayout(this)
        table.addView(makeTableRow(arrayOf("Type", "Bills", "Sale", "Average"), true))
        table.addView(makeTableRow(arrayOf("BIG BILL", report.storeBigBills.toString(), money(report.storeBigSale), money(avgBig)), false))
        table.addView(makeTableRow(arrayOf("SMALL BILL", report.storeSmallBills.toString(), money(report.storeSmallSale), money(avgSmall)), false))
        table.addView(makeTableRow(arrayOf("TOTAL", eligibleBills.toString(), money(eligibleSale), if (eligibleBills > 0) money(eligibleSale / eligibleBills) else money(0.0)), true))
        root.addView(table)

        root.addView(TextView(this).apply { text = "STAFF LEVEL • BIG BILL COUNT HIGH → LOW"; textSize = 13f; setTypeface(null, android.graphics.Typeface.BOLD); setTextColor(0xFF101828.toInt()); setPadding(2, 18, 0, 7) })
        val staffTable = TableLayout(this)
        staffTable.addView(makeTableRow(arrayOf("Staff", "Big", "Big Sale", "Avg Big", "Small", "Small Sale", "Avg Small"), true))
        report.staff.forEach { e ->
            val ab = if (e.bigBills > 0) e.bigSale / e.bigBills else 0.0
            val asmall = if (e.smallBills > 0) e.smallSale / e.smallBills else 0.0
            staffTable.addView(makeTableRow(arrayOf(e.staffName, e.bigBills.toString(), money(e.bigSale), money(ab), e.smallBills.toString(), money(e.smallSale), money(asmall)), false))
        }
        root.addView(HorizontalScrollView(this).apply { addView(staffTable) })
        root.addView(TextView(this).apply {
            text = "Below ${money(report.smallThreshold)} bills are excluded: ${report.ignoredBelowSmall} • Exchange bills excluded: ${report.exchangeBillsExcluded}"
            textSize = 10.5f; setTextColor(0xFF667085.toInt()); setPadding(2, 12, 2, 0)
        })

        val scroll = ScrollView(this).apply { isFillViewport = true; addView(root) }
        lightDialogBuilder().setTitle("BIG BILL REPORT").setView(scroll)
            .setNeutralButton("EXPORT AS CSV") { _, _ -> exportCsv("Big_Bill_Report", buildBigBillCsv(report)) }
            .setPositiveButton("Close", null).show()
    }

    private fun buildBigBillCsv(report: BigBillReportResult): String = buildString {
        val eligibleBills = report.storeBigBills + report.storeSmallBills
        val eligibleSale = report.storeBigSale + report.storeSmallSale
        val bigBillPct = if (eligibleBills > 0) report.storeBigBills.toDouble() / eligibleBills * 100.0 else 0.0
        val bigSalePct = if (eligibleSale > 0) report.storeBigSale / eligibleSale * 100.0 else 0.0
        val avgBig = if (report.storeBigBills > 0) report.storeBigSale / report.storeBigBills else 0.0
        val avgSmall = if (report.storeSmallBills > 0) report.storeSmallSale / report.storeSmallBills else 0.0
        appendLine("BIG BILL REPORT")
        appendLine("Small Bill From,${report.smallThreshold}")
        appendLine("Big Bill From,${report.bigThreshold}")
        appendLine()
        appendLine("STORE LEVEL")
        appendLine("Metric,Big Bill,Small Bill")
        appendLine("Bills,${report.storeBigBills},${report.storeSmallBills}")
        appendLine("Sale,${report.storeBigSale},${report.storeSmallSale}")
        appendLine("Average Bill,$avgBig,$avgSmall")
        appendLine("Big Bill % of Total Bills,$bigBillPct,")
        appendLine("Big Bill % of Total Sale,$bigSalePct,")
        appendLine("Total Eligible Bills,$eligibleBills,")
        appendLine("Total Eligible Sale,$eligibleSale,")
        appendLine()
        appendLine("STAFF LEVEL")
        appendLine("Staff Name,Staff ID,Big Bills,Big Sale,Average Big Bill,Small Bills,Small Sale,Average Small Bill")
        report.staff.forEach { e ->
            val ab=if(e.bigBills>0)e.bigSale/e.bigBills else 0.0
            val asmall=if(e.smallBills>0)e.smallSale/e.smallBills else 0.0
            appendLine(listOf(e.staffName,e.staffId,e.bigBills,e.bigSale,ab,e.smallBills,e.smallSale,asmall).joinToString(",") { csvEscape(it.toString()) })
        }
        appendLine()
        appendLine("Excluded Below Small Threshold,${report.ignoredBelowSmall}")
        appendLine("Exchange Bills Excluded,${report.exchangeBillsExcluded}")
    }

    // ---------------- STAFF REPORT ----------------

    private data class StaffReportEntry(
        val staffId: String,
        val staffName: String,
        val sale: Double,
        val qty: Double,
        val bills: Int,
        val exchangeAdjustment: Double,
        val exchangeBills: Int
    )

    private data class StaffReportResult(
        val mainStaff: List<StaffReportEntry>,
        val otherStoreStaff: List<StaffReportEntry>,
        val totalBills: Int,
        val totalSale: Double,
        val transferredExchange: Double,
        val ambiguousExchangeBills: Int
    )

    private suspend fun processStaffReport(detail: Uri): StaffReportResult = withContext(Dispatchers.IO) {
        data class MutableStaff(
            val id: String,
            var name: String,
            var regularSale: Double = 0.0,
            var regularQty: Double = 0.0,
            val bills: MutableSet<String> = linkedSetOf(),
            var ownExchangeAdjustment: Double = 0.0,
            val ownExchangeBills: MutableSet<String> = linkedSetOf(),
            val exchangeBillNumbers: MutableSet<String> = linkedSetOf()
        )
        data class BillInfo(
            val billNo: String,
            var date: String = "",
            var time: String = "",
            var customerId: String = "",
            var staffId: String = "",
            var staffName: String = "",
            var amount: Double = 0.0,
            var isExchange: Boolean = false
        )
        data class ExchangeInfo(
            val billNo: String,
            val date: String,
            val time: String,
            val customerId: String,
            val staffId: String,
            val staffName: String,
            val amount: Double,
            val exchangeReference: String
        )

        val staffMap = linkedMapOf<String, MutableStaff>()
        val bills = linkedMapOf<String, BillInfo>()
        val reportCatalogue = loadCatalogue().associateBy { it.code.uppercase(Locale.ROOT) }
        val reportOverrides = loadReportProductMappings().groupBy { it.code.uppercase(Locale.ROOT) }
        val exchanges = mutableListOf<ExchangeInfo>()
        var rows = 0

        fun identity(id: String, name: String): String =
            if (id.isNotBlank()) id else name.uppercase(Locale.ROOT)

        updateProcessing("Reading Details for Staff Report…")
        streamCsv(detail) { headers, values, rowNumber ->
            if (isNonMerchandiseRow(headers, values, reportCatalogue, reportOverrides)) { rows = rowNumber; return@streamCsv }
            val staffId = field(values, fieldIndex(headers, "SalesmanCode", "StaffCode", "EmployeeCode"))
                .trim()
            val staffName = field(values, fieldIndex(headers, "SalesmanName", "StaffName", "EmployeeName"))
                .replace(Regex("\\s+"), " ").trim()
            val bill = field(values, fieldIndex(headers, "BillNumber")).trim()
            if (bill.isBlank()) return@streamCsv

            val amount = number(field(values, fieldIndex(headers, "Amount")))
            val rawQty = number(field(values, fieldIndex(headers, "Quantity")))
            val exchangeRef = field(values, fieldIndex(headers, "ExchangeBillNumber")).trim()
            val exchangeDate = field(values, fieldIndex(headers, "ExchangeBillDate")).trim()
            val isExchange = exchangeRef.isNotBlank() || exchangeDate.isNotBlank() || bill.uppercase(Locale.ROOT).startsWith("SR")
            val customerId = field(values, fieldIndex(headers, "CustomerCode", "CustomerID", "CustomerId")).trim()
            val billDate = field(values, fieldIndex(headers, "BillDate")).trim()
            val billTime = field(values, fieldIndex(headers, "BillTime")).trim()

            val billInfo = bills.getOrPut(bill) { BillInfo(billNo = bill) }
            if (billInfo.date.isBlank()) billInfo.date = billDate
            if (billInfo.time.isBlank()) billInfo.time = billTime
            if (billInfo.customerId.isBlank()) billInfo.customerId = customerId
            if (billInfo.staffId.isBlank()) billInfo.staffId = staffId
            if (billInfo.staffName.isBlank()) billInfo.staffName = staffName
            billInfo.amount += amount
            billInfo.isExchange = billInfo.isExchange || isExchange

            if (staffId.isBlank() && staffName.isBlank()) return@streamCsv
            val key = identity(staffId, staffName)
            val staff = staffMap.getOrPut(key) { MutableStaff(key, staffName.ifBlank { key }) }
            if (staff.name.isBlank() && staffName.isNotBlank()) staff.name = staffName

            val article = field(values, fieldIndex(headers, "ArticleNumber", "CategoryCode"))
            val productName = field(values, fieldIndex(headers, "ProductName"))
            val isCarryBag = article.equals("P-CB", true) || productName.contains("carry bag", true)

            if (isExchange) {
                staff.ownExchangeAdjustment += kotlin.math.abs(amount)
                staff.exchangeBillNumbers += bill
            } else {
                staff.regularSale += amount
                if (!isCarryBag) staff.regularQty += rawQty
                staff.bills += bill
            }

            rows = rowNumber
            if (rowNumber % 2500 == 0) updateProcessing("Reading Details… $rowNumber rows")
        }

        // Build one exchange record per exchange bill from the aggregated bill data.
        bills.values.filter { it.isExchange }.forEach { b ->
            exchanges += ExchangeInfo(
                billNo = b.billNo,
                date = b.date,
                time = b.time,
                customerId = b.customerId,
                staffId = b.staffId,
                staffName = b.staffName,
                amount = b.amount,
                exchangeReference = ""
            )
        }
        // Recover ExchangeBillNumber from the first matching CSV row without storing all rows.
        // The reference is used only as supporting information; amount is NEVER a match requirement.
        streamCsv(detail) { headers, values, _ ->
            val bill = field(values, fieldIndex(headers, "BillNumber")).trim()
            if (bill.isBlank()) return@streamCsv
            val ref = field(values, fieldIndex(headers, "ExchangeBillNumber")).trim()
            if (ref.isNotBlank()) {
                val i = exchanges.indexOfFirst { it.billNo == bill }
                if (i >= 0 && exchanges[i].exchangeReference.isBlank()) {
                    val e = exchanges[i]
                    exchanges[i] = e.copy(exchangeReference = ref)
                }
            }
        }

        // First calculate each staff's sale after their own-store exchanges.
        val ownNet = staffMap.values.associateBy({ it.id }) { it.regularSale - it.ownExchangeAdjustment }
        val otherStoreIds = staffMap.values
            .filter { (ownNet[it.id] ?: 0.0) < 0.0 }
            .map { it.id }
            .toSet()

        // External-store exchange staff are not displayed in the main table.
        // Their exchange amount is reassigned to the same-store staff whose positive
        // purchase occurred on the SAME DATE for the SAME CUSTOMER. Exchange amount is
        // deliberately NOT used as a matching condition because the new purchase can
        // be higher or lower than the exchanged value.
        val transferred = linkedMapOf<String, Double>()
        var ambiguous = 0
        exchanges.filter { it.staffId in otherStoreIds || (it.staffId.isBlank() && otherStoreIds.contains(identity(it.staffId, it.staffName))) }
            .filter { it.amount < 0.0 && it.customerId.isNotBlank() && it.date.isNotBlank() }
            .forEach { ex ->
                val candidates = bills.values.filter { b ->
                    !b.isExchange && b.amount > 0.0 &&
                        b.date == ex.date && b.customerId == ex.customerId &&
                        b.staffId.isNotBlank() && b.staffId !in otherStoreIds
                }
                val candidateStaffIds = candidates.map { it.staffId }.filter { it.isNotBlank() }.toSet()
                val targetId = when {
                    candidateStaffIds.size == 1 -> candidateStaffIds.first()
                    candidateStaffIds.isEmpty() -> null
                    else -> {
                        // If several staff sold to the same customer on the same date,
                        // use bill time only as a tie-breaker. Amount is never compared.
                        fun minutes(t: String): Int {
                            val m = Regex("(\\d{1,2}):(\\d{2})(AM|PM)", RegexOption.IGNORE_CASE).find(t) ?: return Int.MAX_VALUE
                            var h = m.groupValues[1].toInt(); val min = m.groupValues[2].toInt(); val ap = m.groupValues[3].uppercase(Locale.ROOT)
                            if (ap == "PM" && h < 12) h += 12
                            if (ap == "AM" && h == 12) h = 0
                            return h * 60 + min
                        }
                        candidates.minByOrNull { kotlin.math.abs(minutes(it.time) - minutes(ex.time)) }?.staffId
                    }
                }
                if (targetId != null) transferred[targetId] = (transferred[targetId] ?: 0.0) + kotlin.math.abs(ex.amount)
                else ambiguous++
            }

        val main = staffMap.values.mapNotNull { s ->
            if (s.id in otherStoreIds) return@mapNotNull null
            val sale = (ownNet[s.id] ?: 0.0) - (transferred[s.id] ?: 0.0)
            StaffReportEntry(
                staffId = s.id,
                staffName = s.name,
                sale = sale,
                qty = s.regularQty,
                bills = s.bills.size,
                exchangeAdjustment = s.ownExchangeAdjustment + (transferred[s.id] ?: 0.0),
                exchangeBills = s.ownExchangeBills.size
            )
        }.filter { it.sale > 0.0 }.sortedByDescending { it.sale }

        val other = staffMap.values.mapNotNull { s ->
            if (s.id !in otherStoreIds) return@mapNotNull null
            StaffReportEntry(
                staffId = s.id,
                staffName = s.name,
                sale = ownNet[s.id] ?: 0.0,
                qty = 0.0,
                bills = 0,
                exchangeAdjustment = s.ownExchangeAdjustment,
                exchangeBills = s.ownExchangeBills.size
            )
        }.sortedBy { it.staffName.lowercase(Locale.ROOT) }

        val totalBills = main.sumOf { it.bills }
        val totalSale = main.sumOf { it.sale }
        StaffReportResult(main, other, totalBills, totalSale, transferred.values.sum(), ambiguous)
    }

    private fun generateStaffReport() {
        val detail = detailUri ?: run {
            Toast.makeText(this@MainActivity, "Please select the Sales Detail CSV first", Toast.LENGTH_SHORT).show()
            return
        }
        staffReportButton.isEnabled = false
        sqbReportButton.isEnabled = false
        generate.isEnabled = false
        coreFashionButton.isEnabled = false
        sizeContributionButton.isEnabled = false
        colorContributionButton.isEnabled = false
        setProcessing(true, "Starting Staff Report…")
        result.text = "Calculating staff-wise sale, qty, bills and exchange mapping…"
        lifecycleScope.launch {
            try {
                val report = processStaffReport(detail)
                showStaffReport(report)
                result.text = buildString {
                    append("STAFF REPORT READY\\n\\n")
                    append("Main staff: ${report.mainStaff.size}\\n")
                    append("Bills: ${report.totalBills}\\n")
                    append("Staff net sale: ${money(report.totalSale)}\\n")
                    append("Other-store exchange transferred: ${money(report.transferredExchange)}\\n")
                    if (report.ambiguousExchangeBills > 0) append("Unresolved exchange matches: ${report.ambiguousExchangeBills}\\n")
                }
                Toast.makeText(this@MainActivity, "Staff report generated", Toast.LENGTH_SHORT).show()
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                result.text = "Staff report failed.\\n\\n${e.javaClass.simpleName}: ${e.message ?: "Unknown error"}"
                Toast.makeText(this@MainActivity, "Staff report failed", Toast.LENGTH_LONG).show()
            } finally {
                setProcessing(false)
                staffReportButton.isEnabled = true
                sqbReportButton.isEnabled = true
                colorContributionButton.isEnabled = detailUri != null
                coreFashionButton.isEnabled = detailUri != null
                sizeContributionButton.isEnabled = detailUri != null
                generate.isEnabled = detailUri != null && sohUri != null
            }
        }
    }

    private fun buildStaffCsv(report: StaffReportResult): String = buildString {
        appendLine("Section,Staff Name,Staff ID,Sale,Qty,Bills,Exchange Adjustment,Exchange Bills,ATV,ASP,UPT")
        report.mainStaff.forEach { e -> val atv=if(e.bills>0)e.sale/e.bills else 0.0; val asp=if(e.qty!=0.0)e.sale/e.qty else 0.0; val upt=if(e.bills>0)e.qty/e.bills else 0.0; appendLine(listOf("MAIN",e.staffName,e.staffId,e.sale.toString(),qty(e.qty),e.bills.toString(),e.exchangeAdjustment.toString(),e.exchangeBills.toString(),atv.toString(),asp.toString(),upt.toString()).joinToString(",") { csvEscape(it) }) }
        report.otherStoreStaff.forEach { e -> appendLine(listOf("OTHER STORE / EXCHANGE",e.staffName,e.staffId,e.sale.toString(),qty(e.qty),e.bills.toString(),e.exchangeAdjustment.toString(),e.exchangeBills.toString(),"","","").joinToString(",") { csvEscape(it) }) }
        appendLine(listOf("TOTAL","","",report.totalSale.toString(),"",report.totalBills.toString(),report.transferredExchange.toString(),"","","","").joinToString(",") { csvEscape(it) })
    }

    private fun showStaffReport(report: StaffReportResult) {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(18, 8, 18, 8)
        }
        root.addView(TextView(this).apply {
            text = "Sales Detail • Staff-wise performance • Exchange-adjusted"
            textSize = 12f
            setTextColor(0xFF667085.toInt())
            setPadding(0, 0, 0, 10)
        })

        val summary = com.google.android.material.card.MaterialCardView(this).apply {
            radius = 18f; cardElevation = 0f
            setCardBackgroundColor(0xFFFFFFFF.toInt())
            setStrokeColor(0xFFD5DCE8.toInt()); strokeWidth = 1
            setContentPadding(16, 14, 16, 14)
        }
        val sb = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        sb.addView(TextView(this).apply { text = "STAFF NET SALE"; textSize = 12f; setTypeface(null, android.graphics.Typeface.BOLD); setTextColor(0xFF475467.toInt()) })
        sb.addView(TextView(this).apply { text = money(report.totalSale); textSize = 25f; setTypeface(null, android.graphics.Typeface.BOLD); setTextColor(0xFF101828.toInt()); setPadding(0,4,0,0) })
        sb.addView(TextView(this).apply { text = "Bills ${report.totalBills}  •  Main staff ${report.mainStaff.size}"; textSize = 12f; setTextColor(0xFF667085.toInt()); setPadding(0,2,0,0) })
        if (report.transferredExchange > 0.0) sb.addView(TextView(this).apply { text = "Other-store exchange transferred −${money(report.transferredExchange)}"; textSize = 10.5f; setTextColor(0xFFB54708.toInt()); setPadding(0,5,0,0) })
        if (report.ambiguousExchangeBills > 0) sb.addView(TextView(this).apply { text = "⚠ ${report.ambiguousExchangeBills} exchange bill(s) could not be uniquely matched"; textSize = 10.5f; setTextColor(0xFFB42318.toInt()); setPadding(0,3,0,0) })
        summary.addView(sb)
        root.addView(summary, LinearLayout.LayoutParams(-1,-2).apply { bottomMargin=10 })

        if (report.mainStaff.isEmpty()) {
            root.addView(TextView(this).apply { text = "No positive staff sale records were found."; textSize=13f; setTextColor(0xFF667085.toInt()) })
        } else {
            report.mainStaff.forEach { e ->
                val row = LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(12,12,12,12); setBackgroundResource(android.R.drawable.list_selector_background) }
                row.addView(TextView(this).apply { text="${e.staffName}  •  ID ${e.staffId}"; textSize=14f; setTypeface(null,android.graphics.Typeface.BOLD); setTextColor(0xFF101828.toInt()) })
                val atv=if(e.bills>0)e.sale/e.bills else 0.0; val asp=if(e.qty!=0.0)e.sale/e.qty else 0.0; val upt=if(e.bills>0)e.qty/e.bills else 0.0
                row.addView(TextView(this).apply { text="Sale ${money(e.sale)}  •  Qty ${qty(e.qty)}  •  Bills ${e.bills}\nATV ${money(atv)}  •  ASP ${money(asp)}  •  UPT ${String.format(Locale.US,"%.2f",upt)}"; textSize=11f; setTextColor(0xFF667085.toInt()); setPadding(0,5,0,0) })
                if(e.exchangeAdjustment>0.0) row.addView(TextView(this).apply { text="Exchange-adjusted −${money(e.exchangeAdjustment)}"; textSize=10.5f; setTextColor(0xFFB54708.toInt()); setPadding(0,3,0,0) })
                root.addView(row,LinearLayout.LayoutParams(-1,-2))
            }
        }

        if (report.otherStoreStaff.isNotEmpty()) {
            val header = TextView(this).apply {
                text = "OTHER STORE / EXCHANGE STAFF  ▼"
                textSize = 12f; setTypeface(null,android.graphics.Typeface.BOLD); setTextColor(0xFF475467.toInt())
                setPadding(10,14,10,10); isClickable=true
            }
            val otherBox=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; visibility=View.GONE }
            report.otherStoreStaff.forEach { e ->
                otherBox.addView(TextView(this).apply { text="${e.staffName}  •  ID ${e.staffId}\nExchange / Negative Sale  ${money(e.sale)}  •  ${e.exchangeBills} exchange bill(s)"; textSize=11.5f; setTextColor(0xFF667085.toInt()); setPadding(12,9,12,9) })
            }
            header.setOnClickListener { val open=otherBox.visibility==View.VISIBLE; otherBox.visibility=if(open)View.GONE else View.VISIBLE; header.text=if(open)"OTHER STORE / EXCHANGE STAFF  ▼" else "OTHER STORE / EXCHANGE STAFF  ▲" }
            root.addView(header); root.addView(otherBox)
        }

        val scroll=ScrollView(this).apply{isFillViewport=true;addView(root)}
        lightDialogBuilder().setTitle("STAFF REPORT • ${report.mainStaff.size} STAFF").setView(scroll)
            .setNeutralButton("EXPORT AS CSV") { _, _ -> exportCsv("Staff_Report", buildStaffCsv(report)) }
            .setPositiveButton("Close",null).show()
    }

    // ---------------- SQB (SINGLE QTY BILL) REPORT ----------------

    private data class SqbStaffEntry(
        val staffId: String,
        val staffName: String,
        val totalBills: Int,
        val sqbBills: Int
    )

    private data class SqbReportResult(
        val storeBills: Int,
        val storeSqbBills: Int,
        val staff: List<SqbStaffEntry>,
        val exchangeBillsExcluded: Int
    )

    private suspend fun processSqbReport(detail: Uri): SqbReportResult = withContext(Dispatchers.IO) {
        // Bill-level aggregation is necessary because a Details CSV has multiple
        // rows per bill. A bill is SQB when its eligible quantity is exactly 1.
        data class MutableBill(
            var staffId: String = "",
            var staffName: String = "",
            var qty: Double = 0.0,
            var carryBagQty: Double = 0.0,
            var exchange: Boolean = false
        )

        val bills = linkedMapOf<String, MutableBill>()
        val reportCatalogue = loadCatalogue().associateBy { it.code.uppercase(Locale.ROOT) }
        val reportOverrides = loadReportProductMappings().groupBy { it.code.uppercase(Locale.ROOT) }
        var rows = 0
        updateProcessing("Reading Details for SQB Report…")

        streamCsv(detail) { headers, values, rowNumber ->
            if (isNonMerchandiseRow(headers, values, reportCatalogue, reportOverrides)) { rows = rowNumber; return@streamCsv }
            val billNo = field(values, fieldIndex(headers, "BillNumber")).trim()
            if (billNo.isBlank()) return@streamCsv

            val bill = bills.getOrPut(billNo) { MutableBill() }
            val staffId = field(values, fieldIndex(headers, "SalesmanCode", "StaffCode", "EmployeeCode")).trim()
            val staffName = field(values, fieldIndex(headers, "SalesmanName", "StaffName", "EmployeeName"))
                .replace(Regex("\\s+"), " ").trim()
            if (staffId.isNotBlank()) bill.staffId = staffId
            if (staffName.isNotBlank()) bill.staffName = staffName

            bill.qty += number(field(values, fieldIndex(headers, "Quantity")))
            val article = field(values, fieldIndex(headers, "ArticleNumber", "CategoryCode")).trim()
            val productName = field(values, fieldIndex(headers, "ProductName"))
            val isCarryBag = article.equals("P-CB", true) || productName.contains("carry bag", true)
            if (isCarryBag) bill.carryBagQty += number(field(values, fieldIndex(headers, "Quantity")))

            // Exchange bills are removed completely from SQB calculations.
            // ExchangeBillNumber is the primary marker; SR-series bills are also
            // retained as a fallback for the known Go Colors exchange pattern.
            val exchangeRef = field(values, fieldIndex(headers, "ExchangeBillNumber")).trim()
            val exchangeDate = field(values, fieldIndex(headers, "ExchangeBillDate")).trim()
            if (exchangeRef.isNotBlank() || exchangeDate.isNotBlank() || billNo.equals("SR199", true)) {
                bill.exchange = true
            }

            rows = rowNumber
            if (rowNumber % 2500 == 0) updateProcessing("Reading Details… $rowNumber rows")
        }

        val validBills = bills.filter { (billNo, bill) -> !bill.exchange && billNo.isNotBlank() }
        val storeSqb = validBills.count { (_, b) -> kotlin.math.abs((b.qty - b.carryBagQty) - 1.0) < 0.000001 }

        data class StaffMutable(var id: String = "", var name: String = "", var bills: Int = 0, var sqb: Int = 0)
        val staffMap = linkedMapOf<String, StaffMutable>()
        validBills.forEach { (_, b) ->
            val identity = when {
                b.staffId.isNotBlank() -> b.staffId
                b.staffName.isNotBlank() -> b.staffName.uppercase(Locale.ROOT)
                else -> return@forEach
            }
            val staff = staffMap.getOrPut(identity) { StaffMutable(identity, b.staffName.ifBlank { identity }) }
            if (staff.name.isBlank() && b.staffName.isNotBlank()) staff.name = b.staffName
            staff.bills++
            if (kotlin.math.abs((b.qty - b.carryBagQty) - 1.0) < 0.000001) staff.sqb++
        }

        SqbReportResult(
            storeBills = validBills.size,
            storeSqbBills = storeSqb,
            staff = staffMap.values
                .filter { it.bills > 0 }
                .map { SqbStaffEntry(it.id, it.name.ifBlank { it.id }, it.bills, it.sqb) }
                .sortedWith(compareByDescending<SqbStaffEntry> { it.sqbBills }.thenBy { it.staffName.lowercase(Locale.ROOT) }),
            exchangeBillsExcluded = bills.count { it.value.exchange }
        )
    }

    private fun generateSqbReport() {
        val detail = detailUri ?: run {
            Toast.makeText(this@MainActivity, "Please select the Sales Detail CSV first", Toast.LENGTH_SHORT).show()
            return
        }
        sqbReportButton.isEnabled = false
        staffReportButton.isEnabled = false
        generate.isEnabled = false
        coreFashionButton.isEnabled = false
        sizeContributionButton.isEnabled = false
        colorContributionButton.isEnabled = false
        setProcessing(true, "Starting SQB Report…")
        result.text = "Calculating single-quantity bills store-wise and staff-wise…"
        lifecycleScope.launch {
            try {
                val report = processSqbReport(detail)
                showSqbReport(report)
                result.text = buildString {
                    append("SQB REPORT READY\\n\\n")
                    append("Store SQB: ${report.storeSqbBills} / ${report.storeBills} bills\\n")
                    append("SQB Contribution: ${pct(contribution(report.storeSqbBills.toDouble(), report.storeBills.toDouble()))}\\n")
                    append("Exchange bills excluded: ${report.exchangeBillsExcluded}\\n")
                }
                Toast.makeText(this@MainActivity, "SQB report generated", Toast.LENGTH_SHORT).show()
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                result.text = "SQB report failed.\\n\\n${e.javaClass.simpleName}: ${e.message ?: "Unknown error"}"
                Toast.makeText(this@MainActivity, "SQB report failed", Toast.LENGTH_LONG).show()
            } finally {
                setProcessing(false)
                sqbReportButton.isEnabled = true
                staffReportButton.isEnabled = true
                colorContributionButton.isEnabled = detailUri != null
                coreFashionButton.isEnabled = detailUri != null
                sizeContributionButton.isEnabled = detailUri != null
                generate.isEnabled = detailUri != null && sohUri != null
            }
        }
    }

    private fun buildSqbCsv(report: SqbReportResult): String = buildString {
        appendLine("Staff Name,Staff ID,Total Bills,SQB Bills,Store SQB Contribution %,Own Bill SQB %")
        report.staff.forEach { e -> appendLine(listOf(e.staffName,e.staffId,e.totalBills.toString(),e.sqbBills.toString(),contribution(e.sqbBills.toDouble(),report.storeSqbBills.toDouble()).toString(),contribution(e.sqbBills.toDouble(),e.totalBills.toDouble()).toString()).joinToString(",") { csvEscape(it) }) }
        appendLine(listOf("STORE TOTAL","",report.storeBills.toString(),report.storeSqbBills.toString(),contribution(report.storeSqbBills.toDouble(),report.storeBills.toDouble()).toString(),"").joinToString(",") { csvEscape(it) })
    }

    private fun showSqbReport(report: SqbReportResult) {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(18, 8, 18, 8)
        }

        box.addView(TextView(this).apply {
            text = "Single Quantity Bills • Exchange excluded • Carry Bag excluded from Qty"
            textSize = 11.5f
            setTextColor(0xFF667085.toInt())
            setPadding(0, 0, 0, 10)
        })

        val storePct = contribution(report.storeSqbBills.toDouble(), report.storeBills.toDouble())
        // Keep SQB summary card in the same bright/light UI system as the report.
        // Dark background + dark text is intentionally avoided here.
        val storeCard = com.google.android.material.card.MaterialCardView(this).apply {
            radius = 18f
            cardElevation = 0f
            setCardBackgroundColor(0xFFFFFFFF.toInt())
            setStrokeColor(0xFFD5DCE8.toInt())
            strokeWidth = 1
            setContentPadding(16, 14, 16, 14)
        }
        val storeBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        storeBox.addView(TextView(this).apply {
            text = "STORE TOTAL SQB"
            textSize = 12f
            setTypeface(null, android.graphics.Typeface.BOLD)
            setTextColor(0xFF475467.toInt())
        })
        storeBox.addView(TextView(this).apply {
            text = "${report.storeSqbBills} SQB"
            textSize = 26f
            setTypeface(null, android.graphics.Typeface.BOLD)
            setTextColor(0xFF101828.toInt())
            setPadding(0, 4, 0, 0)
        })
        storeBox.addView(TextView(this).apply {
            text = "${report.storeSqbBills} / ${report.storeBills} total bills  •  ${pct(storePct)} SQB %"
            textSize = 11.5f
            setTextColor(0xFF667085.toInt())
            setPadding(0, 2, 0, 0)
        })
        storeBox.addView(TextView(this).apply {
            text = "${report.exchangeBillsExcluded} exchange bill(s) excluded"
            textSize = 10.5f
            setTextColor(0xFFB54708.toInt())
            setPadding(0, 5, 0, 0)
        })
        storeCard.addView(storeBox)
        box.addView(storeCard, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = 12 })

        box.addView(TextView(this).apply {
            text = "STAFF WISE SQB"
            textSize = 11f
            setTypeface(null, android.graphics.Typeface.BOLD)
            setTextColor(0xFF667085.toInt())
            setPadding(2, 2, 2, 7)
        })

        report.staff.forEach { e ->
            val storeContribution = contribution(e.sqbBills.toDouble(), report.storeSqbBills.toDouble())
            val ownContribution = contribution(e.sqbBills.toDouble(), e.totalBills.toDouble())
            val row = com.google.android.material.card.MaterialCardView(this).apply {
                radius = 15f
                cardElevation = 0f
                setCardBackgroundColor(0xFFFFFFFF.toInt())
                setStrokeColor(0xFFD5DCE8.toInt())
                strokeWidth = 1
                setContentPadding(14, 12, 14, 12)
            }
            val rbox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
            rbox.addView(TextView(this).apply {
                text = "${e.staffName}  •  ID ${e.staffId}"
                textSize = 14f
                setTypeface(null, android.graphics.Typeface.BOLD)
                setTextColor(0xFF101828.toInt())
            })
            rbox.addView(TextView(this).apply {
                text = "SQB ${e.sqbBills}  •  Total Bills ${e.totalBills}"
                textSize = 12f
                setTextColor(0xFF344054.toInt())
                setPadding(0, 5, 0, 0)
            })
            rbox.addView(TextView(this).apply {
                text = "Store SQB Contribution  ${pct(storeContribution)}   •   Own Bill SQB %  ${pct(ownContribution)}"
                textSize = 10.8f
                setTypeface(null, android.graphics.Typeface.BOLD)
                setTextColor(0xFF475467.toInt())
                setPadding(0, 4, 0, 0)
            })
            row.addView(rbox)
            box.addView(row, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = 8 })
        }

        val scroll = ScrollView(this).apply { isFillViewport = true; addView(box) }
        lightDialogBuilder()
            .setTitle("SQB REPORT • Single Qty Bills")
            .setView(scroll)
            .setNeutralButton("EXPORT AS CSV") { _, _ -> exportCsv("SQB_Report", buildSqbCsv(report)) }
            .setPositiveButton("Close", null)
            .show()
    }

    // ---------------- COLOR CONTRIBUTION ----------------

    private data class ColorSaleEntry(val color: String, val sale: Double, val qty: Double)

    private data class ColorContributionResult(
        val detailRows: Int,
        val totalSale: Double,
        val totalQty: Double,
        val colors: List<ColorSaleEntry>,
        val excludedNoColorRows: Int
    )

    private suspend fun processColorContribution(detail: Uri): ColorContributionResult = withContext(Dispatchers.IO) {
        var rows = 0
        var totalSale = 0.0
        var totalQty = 0.0
        var noColorRows = 0
        val colorMap = linkedMapOf<String, DoubleArray>()
        val displayNames = linkedMapOf<String, String>()
        val reportCatalogue = loadCatalogue().associateBy { it.code.uppercase(Locale.ROOT) }
        val reportOverrides = loadReportProductMappings().groupBy { it.code.uppercase(Locale.ROOT) }

        updateProcessing("Reading Details for Color contribution…")
        streamCsv(detail) { headers, values, rowNumber ->
            if (isNonMerchandiseRow(headers, values, reportCatalogue, reportOverrides)) { rows = rowNumber; return@streamCsv }
            val rawColor = field(values, fieldIndex(headers, "Color"))
                .trim().trim('"', '\'')
            val color = rawColor.replace(Regex("\\s+"), " ").trim()
            val colorKey = color.uppercase(Locale.ROOT)
            val qtyValue = number(field(values, fieldIndex(headers, "Quantity")))
            val saleValue = number(field(values, fieldIndex(headers, "Amount")))

            if (color.isBlank()) {
                noColorRows++
            } else {
                totalSale += saleValue
                totalQty += qtyValue
                displayNames.putIfAbsent(colorKey, color)
                val bucket = colorMap.getOrPut(colorKey) { DoubleArray(2) }
                bucket[0] += saleValue
                bucket[1] += qtyValue
            }
            rows = rowNumber
            if (rowNumber % 2500 == 0) updateProcessing("Reading Details… $rowNumber rows")
        }

        ColorContributionResult(
            detailRows = rows,
            totalSale = totalSale,
            totalQty = totalQty,
            colors = colorMap.map { ColorSaleEntry(displayNames[it.key] ?: it.key, it.value[0], it.value[1]) }
                .sortedWith(compareByDescending<ColorSaleEntry> { it.sale }.thenByDescending { it.qty }.thenBy { it.color.lowercase(Locale.ROOT) }),
            excludedNoColorRows = noColorRows
        )
    }

    private fun generateColorContributionReport() {
        val detail = detailUri ?: run {
            Toast.makeText(this@MainActivity, "Please select the Sales Detail CSV first", Toast.LENGTH_SHORT).show()
            return
        }
        colorContributionButton.isEnabled = false
        coreFashionButton.isEnabled = false
        sizeContributionButton.isEnabled = false
        staffReportButton.isEnabled = false
        sqbReportButton.isEnabled = false
        generate.isEnabled = false
        setProcessing(true, "Starting Color contribution…")
        result.text = "Calculating color sales contribution…"
        lifecycleScope.launch {
            try {
                val report = processColorContribution(detail)
                showColorContributionReport(report)
                result.text = buildString {
                    append("COLOR CONTRIBUTION READY\n\n")
                    append("Unique colors: ${report.colors.size}\n")
                    append("Total colored sale: ${money(report.totalSale)}\n")
                    append("Total colored qty: ${qty(report.totalQty)}\n")
                    if (report.excludedNoColorRows > 0) append("Rows without Color excluded: ${report.excludedNoColorRows}\n")
                }
                Toast.makeText(this@MainActivity, "Color contribution report generated", Toast.LENGTH_SHORT).show()
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                result.text = "Color contribution report failed.\n\n${e.javaClass.simpleName}: ${e.message ?: "Unknown error"}"
                Toast.makeText(this@MainActivity, "Color contribution report failed", Toast.LENGTH_LONG).show()
            } finally {
                setProcessing(false)
                colorContributionButton.isEnabled = detailUri != null
                coreFashionButton.isEnabled = detailUri != null
                sizeContributionButton.isEnabled = detailUri != null
                staffReportButton.isEnabled = true
                sqbReportButton.isEnabled = true
                generate.isEnabled = detailUri != null && sohUri != null
            }
        }
    }

    private fun buildColorContributionCsv(report: ColorContributionResult): String = buildString {
        appendLine("Color,Sale Value,Sale Contribution %,Qty,Qty Contribution %")
        report.colors.forEach { appendLine(listOf(it.color,it.sale.toString(),contribution(it.sale,report.totalSale).toString(),qty(it.qty),contribution(it.qty,report.totalQty).toString()).joinToString(",") { csvEscape(it) }) }
        appendLine(listOf("TOTAL",report.totalSale.toString(),"100.00",qty(report.totalQty),"100.00").joinToString(",") { csvEscape(it) })
    }

    private fun showColorContributionReport(report: ColorContributionResult) {
        val dialogRoot = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(18, 8, 18, 8)
        }

        dialogRoot.addView(TextView(this).apply {
            text = "Sales Detail • Color-level contribution"
            textSize = 12f
            setTextColor(0xFF667085.toInt())
            setPadding(0, 0, 0, 10)
        })

        val totalCard = com.google.android.material.card.MaterialCardView(this).apply {
            radius = 18f
            cardElevation = 0f
            setCardBackgroundColor(0xFF0B2545.toInt())
            setStrokeColor(0xFF0B2545.toInt())
            strokeWidth = 1
            setContentPadding(16, 14, 16, 14)
        }
        val totalContent = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        totalContent.addView(TextView(this).apply {
            text = "TOTAL COLOR SALE"
            textSize = 13f
            setTypeface(null, android.graphics.Typeface.BOLD)
            setTextColor(0xFFD9E2F5.toInt())
        })
        totalContent.addView(TextView(this).apply {
            text = money(report.totalSale)
            textSize = 25f
            setTypeface(null, android.graphics.Typeface.BOLD)
            setTextColor(0xFFFFFFFF.toInt())
            setPadding(0, 4, 0, 0)
        })
        totalContent.addView(TextView(this).apply {
            text = "Qty ${qty(report.totalQty)}    •    Contribution 100.00%"
            textSize = 12f
            setTextColor(0xFFB8C6E2.toInt())
            setPadding(0, 2, 0, 0)
        })
        totalCard.addView(totalContent)
        dialogRoot.addView(totalCard, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = 10 })

        if (report.colors.isEmpty()) {
            dialogRoot.addView(TextView(this).apply {
                text = "No non-blank colors were found in the Details report."
                textSize = 12f
                setTextColor(0xFF667085.toInt())
                setPadding(4, 8, 4, 12)
            })
        } else {
            val list = ListView(this).apply {
                divider = null
                dividerHeight = 0
                isVerticalScrollBarEnabled = true
                isFastScrollEnabled = true
                setPadding(0, 0, 0, 4)
            }

            val adapter = object : BaseAdapter() {
                override fun getCount(): Int = report.colors.size
                override fun getItem(position: Int): ColorSaleEntry = report.colors[position]
                override fun getItemId(position: Int): Long = position.toLong()

                override fun getView(position: Int, convertView: View?, parent: android.view.ViewGroup?): View {
                    val row = (convertView as? LinearLayout) ?: LinearLayout(this@MainActivity).apply {
                        orientation = LinearLayout.HORIZONTAL
                        gravity = Gravity.CENTER_VERTICAL
                        setPadding(10, 10, 10, 10)
                        minimumHeight = 58
                        setBackgroundResource(android.R.drawable.list_selector_background)

                        val name = TextView(this@MainActivity).apply {
                            tag = "colorName"
                            textSize = 13f
                            setTypeface(null, android.graphics.Typeface.BOLD)
                            setTextColor(0xFF344054.toInt())
                            layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
                        }
                        addView(name)

                        val metrics = TextView(this@MainActivity).apply {
                            tag = "colorMetrics"
                            textSize = 10.5f
                            gravity = Gravity.END
                            setTextColor(0xFF667085.toInt())
                        }
                        addView(metrics, LinearLayout.LayoutParams(180, -2))
                    }

                    val entry = report.colors[position]
                    row.findViewWithTag<TextView>("colorName").text = entry.color
                    row.findViewWithTag<TextView>("colorMetrics").text = buildString {
                        append(money(entry.sale))
                        append("\n")
                        append("Sale ${pct(contribution(entry.sale, report.totalSale))} • ")
                        append("Qty ${qty(entry.qty)} / ${pct(contribution(entry.qty, report.totalQty))}")
                    }
                    return row
                }
            }
            list.adapter = adapter

            dialogRoot.addView(TextView(this).apply {
                text = "${report.colors.size} unique colors • sorted by sale (highest first)"
                textSize = 10.5f
                setTextColor(0xFF667085.toInt())
                setPadding(4, 2, 4, 6)
            })
            dialogRoot.addView(list, LinearLayout.LayoutParams(-1, 0, 1f))
        }

        if (report.excludedNoColorRows > 0) {
            dialogRoot.addView(TextView(this).apply {
                text = "ℹ ${report.excludedNoColorRows} sale row(s) had no Color and were excluded from color contribution."
                textSize = 10.5f
                setTextColor(0xFF667085.toInt())
                setPadding(4, 6, 4, 2)
            })
        }

        lightDialogBuilder()
            .setTitle("COLOR Contribution")
            .setView(dialogRoot)
            .setNeutralButton("EXPORT AS CSV") { _, _ -> exportCsv("COLOR_Contribution", buildColorContributionCsv(report)) }
            .setPositiveButton("Close", null)
            .show()
    }

}

