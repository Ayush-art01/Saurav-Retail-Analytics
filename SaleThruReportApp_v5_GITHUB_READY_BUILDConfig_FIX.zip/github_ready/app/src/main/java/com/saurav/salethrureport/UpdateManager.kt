package com.saurav.salethrureport

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.core.content.FileProvider
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

/** GitHub Releases updater. Configure GITHUB_OWNER and GITHUB_REPO before publishing. */
internal object UpdateManager {
    // TODO: Replace these two values with the public GitHub repository that hosts app releases.
    private const val GITHUB_OWNER = "YOUR_GITHUB_USERNAME"
    private const val GITHUB_REPO = "YOUR_REPOSITORY_NAME"
    private const val RELEASE_API = "https://api.github.com/repos/$GITHUB_OWNER/$GITHUB_REPO/releases/latest"
    private const val CONNECT_TIMEOUT_MS = 10_000
    private const val READ_TIMEOUT_MS = 15_000

    fun checkAndPrompt(activity: MainActivity) {
        if (GITHUB_OWNER.startsWith("YOUR_") || GITHUB_REPO.startsWith("YOUR_")) return
        activity.lifecycleScope.launch {
            val release = withContext(Dispatchers.IO) { fetchLatestRelease() } ?: return@launch
            if (activity.isFinishing || activity.isDestroyed) return@launch
            if (release.versionCode <= BuildConfig.VERSION_CODE) return@launch

            AlertDialog.Builder(activity)
                .setTitle("Update available")
                .setMessage(
                    "Saurav Retail Analytics ${release.versionName} is available.\n\n" +
                        (release.notes.takeIf { it.isNotBlank() } ?: "Install the latest version to get the newest improvements.")
                )
                .setNegativeButton("Later", null)
                .setPositiveButton("Update") { _, _ -> downloadAndInstall(activity, release.apkUrl, release.versionName) }
                .show()
        }
    }

    private data class ReleaseInfo(val versionCode: Int, val versionName: String, val apkUrl: String, val notes: String)

    private fun fetchLatestRelease(): ReleaseInfo? {
        var connection: HttpURLConnection? = null
        return try {
            connection = (URL(RELEASE_API).openConnection() as HttpURLConnection).apply {
                requestMethod = "GET"
                connectTimeout = CONNECT_TIMEOUT_MS
                readTimeout = READ_TIMEOUT_MS
                setRequestProperty("Accept", "application/vnd.github+json")
                setRequestProperty("X-GitHub-Api-Version", "2022-11-28")
                setRequestProperty("User-Agent", "Saurav-Retail-Analytics-Android")
            }
            if (connection.responseCode !in 200..299) return null
            val json = connection.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
            val release = JSONObject(json)
            val body = release.optString("body", "")
            // Release description must include: versionCode: 2 and versionName: 1.1
            val remoteCode = Regex("(?im)^\\s*versionCode\\s*[:=]\\s*(\\d+)\\s*$")
                .find(body)?.groupValues?.getOrNull(1)?.toIntOrNull() ?: return null
            val remoteName = Regex("(?im)^\\s*versionName\\s*[:=]\\s*([^\\r\\n]+)\\s*$")
                .find(body)?.groupValues?.getOrNull(1)?.trim().orEmpty()
                .ifBlank { release.optString("tag_name", "Latest") }
            val assets = release.optJSONArray("assets") ?: return null
            var apkUrl: String? = null
            for (i in 0 until assets.length()) {
                val asset = assets.optJSONObject(i) ?: continue
                val name = asset.optString("name", "")
                if (name.endsWith(".apk", ignoreCase = true)) {
                    apkUrl = asset.optString("browser_download_url").takeIf { it.startsWith("https://") }
                    if (apkUrl != null) break
                }
            }
            val url = apkUrl ?: return null
            ReleaseInfo(remoteCode, remoteName, url, body
                .lines()
                .filterNot { it.trim().matches(Regex("(?i)versionCode\\s*[:=].*")) || it.trim().matches(Regex("(?i)versionName\\s*[:=].*")) }
                .joinToString("\n").trim())
        } catch (_: Exception) {
            null
        } finally {
            connection?.disconnect()
        }
    }

    private fun downloadAndInstall(activity: MainActivity, apkUrl: String, versionName: String) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && !activity.packageManager.canRequestPackageInstalls()) {
            val settingsIntent = Intent(
                Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES,
                Uri.parse("package:${activity.packageName}")
            )
            activity.startActivity(settingsIntent)
            Toast.makeText(activity, "Allow installs from this app, then reopen the app and tap Update.", Toast.LENGTH_LONG).show()
            return
        }

        Toast.makeText(activity, "Downloading update…", Toast.LENGTH_SHORT).show()
        activity.lifecycleScope.launch {
            val apkFile = withContext(Dispatchers.IO) { downloadApk(activity, apkUrl) }
            if (activity.isFinishing || activity.isDestroyed) return@launch
            if (apkFile == null) {
                AlertDialog.Builder(activity)
                    .setTitle("Download failed")
                    .setMessage("Could not download the update. Please check your internet connection and try again.")
                    .setPositiveButton("OK", null)
                    .show()
                return@launch
            }
            try {
                val apkUri = FileProvider.getUriForFile(
                    activity,
                    "${activity.packageName}.fileprovider",
                    apkFile
                )
                val installIntent = Intent(Intent.ACTION_VIEW).apply {
                    setDataAndType(apkUri, "application/vnd.android.package-archive")
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                activity.startActivity(installIntent)
            } catch (_: Exception) {
                Toast.makeText(activity, "Could not open installer for version $versionName.", Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun downloadApk(context: Context, apkUrl: String): File? {
        var connection: HttpURLConnection? = null
        return try {
            connection = (URL(apkUrl).openConnection() as HttpURLConnection).apply {
                connectTimeout = CONNECT_TIMEOUT_MS
                readTimeout = 60_000
                instanceFollowRedirects = true
                setRequestProperty("User-Agent", "Saurav-Retail-Analytics-Android")
            }
            if (connection.responseCode !in 200..299) return null
            val file = File(context.cacheDir, "saurav-retail-analytics-update.apk")
            connection.inputStream.use { input -> file.outputStream().use { output -> input.copyTo(output) } }
            file.takeIf { it.exists() && it.length() > 0L }
        } catch (_: Exception) {
            null
        } finally {
            connection?.disconnect()
        }
    }
}
